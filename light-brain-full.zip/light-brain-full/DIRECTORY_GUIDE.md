# Light-Brain Scheme Directory Guide

This document helps you quickly understand the project structure of the Light-Brain Scheme full version and locate the code, configuration, or documentation you need.

---

## Root Directory

| File/Directory | Purpose |
| :--- | :--- |
| `README.md` | Project homepage with introduction, quick start, and documentation navigation. |
| `LICENSE` | Open source license (MIT). |
| `.gitignore` | Git ignore rules. |
| `目录导引.md` | Chinese version of this directory guide. |
| `DIRECTORY_GUIDE.md` | This document (English version). |

---

## Core Code

### `rust-core/` — Rust Core Engine
Implements underlying logic for symbolic reasoning, knowledge storage, memory management, and growth scheduling.

| Path | Purpose |
| :--- | :--- |
| `rust-core/src/lib.rs` | Library entry point, declaring all submodules and exporting the public interface. |
| `rust-core/src/thalamus/` | Thalamus module: prototype vector storage and symbol grounding layer. |
| `rust-core/src/prefrontal/` | Prefrontal module: decision table, fusion engine, creative controller, working memory. |
| `rust-core/src/amygdala/` | Amygdala module: rule engine for language style output. |
| `rust-core/src/cerebellum/` | Cerebellum module: knowledge graph storage, retrieval, decay, and three-tier memory flow. |
| `rust-core/src/hippocampus/` | Hippocampus module: episodic event storage, time-range retrieval, memory consolidation. |
| `rust-core/src/growth/` | Growth module: knowledge extraction, growth scheduling, conflict detection. |
| `rust-core/src/memory/` | Memory management subsystem: three-tier memory state machine and garbage collection. |
| `rust-core/src/utils/` | Utility module: timestamps, decay formulas, metrics collection, pluggable time provider. |
| `rust-core/tests/` | Rust integration tests. |

### `python-binding/` — Python Binding Layer
Compiles the Rust core into a native Python extension using PyO3.

| Path | Purpose |
| :--- | :--- |
| `python-binding/src/lib.rs` | Binding code exposing Rust types and methods to Python. |
| `python-binding/Cargo.toml` | Rust project configuration. |

### `python-ai/` — Python AI Interface Layer
Encapsulates neural network models (Thalamus perception, Broca language generation) and invokes Rust bindings for inference.

| Path | Purpose |
| :--- | :--- |
| `python-ai/light_brain/__init__.py` | Python package entry point. |
| `python-ai/light_brain/thalamus/` | Thalamus neural network: encoder, symbol grounding layer. |
| `python-ai/light_brain/broca/` | Broca area: semantic planning, SLM generation, constraint guidance. |
| `python-ai/light_brain/utils/` | Utilities: configuration loading, logging, schema validation, binding helpers. |
| `python-ai/requirements.txt` | Python dependency list. |

---

## Configuration and Data

### `config/` — Configuration Files (Chinese Version)
Contains runtime configurations for the Chinese version modules, all in JSON format.

| Path | Purpose |
| :--- | :--- |
| `config/zh/prefrontal_decisions.json` | Prefrontal decision table. |
| `config/zh/amygdala_rules.json` | Amygdala rules. |
| `config/zh/broca_templates.json` | Broca fallback templates. |
| `config/zh/creative_profiles.json` | Three-knob creative mode presets. |
| `config/zh/thalamus_prototypes.json` | Thalamus prototype vector initial values. |
| `config/schemas/` | Reserved directory: JSON Schema validation definition files (optional). |

### `data/` — Runtime Data
Stores persistent data and neural network model weights.

| Path | Purpose |
| :--- | :--- |
| `data/knowledge/` | Cerebellum knowledge graph persistence directory. The seed file `seed.json` is located here. |
| `data/hippocampus/` | Hippocampus SQLite database directory for storing conversational events. |
| `data/models/` | Neural network model weights directory, to be populated by contributors. |

### `scripts/` — Script Utilities

| Path | Purpose |
| :--- | :--- |
| `scripts/run.py` | Main entry script that orchestrates all modules for interactive inference. |
| `scripts/init_knowledge.py` | Seed knowledge base initialization script. |

---

## English Version Mirror

The complete English version code is located under the `en/` directory, with a structure fully mirroring the Chinese version.

| Path | Purpose |
| :--- | :--- |
| `en/rust-core/` | Rust core engine (English comments, English field names). |
| `en/python-binding/` | Python binding layer (English comments). |
| `en/python-ai/` | Python AI layer (English comments, English field names). |
| `en/config/` | English version configuration files (JSON files directly inside). |
| `en/scripts/` | English version script utilities. |
| `en/README.md` | English version project homepage. |
| `en/目录导引.md` | English version directory guide. |

---

## Documentation

| Path | Purpose |
| :--- | :--- |
| `docs/zh/完整架构说明.md` | Chinese full architecture documentation. |
| `docs/zh/实施路线图.md` | Chinese phased iteration roadmap. |
| `docs/zh/贡献指南.md` | Chinese contributing guide. |
| `docs/zh/种子库说明.md` | Chinese seed knowledge base explanation. |
| `docs/zh/模型下载指引.md` | Chinese pretrained model download guide. |
| `docs/zh/中英对照表.md` | Chinese-English glossary (Chinese index). |
| `docs/en/ARCHITECTURE.md` | English full architecture documentation. |
| `docs/en/IMPLEMENTATION_ROADMAP.md` | English phased iteration roadmap. |
| `docs/en/CONTRIBUTING.md` | English contributing guide. |
| `docs/en/SEED_KNOWLEDGE.md` | English seed knowledge base explanation. |
| `docs/en/MODEL_DOWNLOAD_GUIDE.md` | English pretrained model download guide. |
| `docs/en/GLOSSARY_EN_ZH.md` | English-Chinese glossary (English index). |

---

## Other Directories

| Path | Purpose |
| :--- | :--- |
| `proto/` | Reserved directory: Protocol Buffers definitions for gRPC service interfaces (optional). |
| `deployments/` | Reserved directory: containerized deployment configurations (Dockerfile, docker-compose.yml, etc.). |