#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
光脑方案完整版主入口
串联丘脑、前额叶、杏仁核、小脑、海马体、布罗卡区，实现端到端推理。
"""

import os
import sys
import json
import time
from typing import Dict, Any, Optional, List, Tuple

# 添加项目根目录到 Python 路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入光脑模块
from light_brain import Thalamus, Broca
from light_brain.utils.config import ConfigManager
from light_brain.utils.logger import setup_logger
from light_brain.utils.binding_helper import get_rust_binding

# 尝试导入 Rust 绑定
rust = get_rust_binding()
if rust is None:
    raise ImportError("Rust 绑定库 light_brain_binding 未找到，请先编译")

class LightBrain:
    """光脑方案主控制器"""

    def __init__(self, config_root: str):
        self.logger = setup_logger("light_brain")
        self.config = ConfigManager(config_root)

        # 加载配置
        self.prefrontal_decisions = self.config.load_prefrontal_decisions()
        self.amygdala_rules = self.config.load_amygdala_rules()
        self.broca_templates = self.config.load_broca_templates()
        self.creative_profiles = self.config.load_creative_profiles()
        self.thalamus_prototypes = self.config.load_thalamus_prototypes()

        # 初始化 Rust 核心模块
        self.graph_store = rust.PyGraphStore()
        self.amygdala = rust.PyAmygdala.from_file(
            os.path.join(config_root, "zh", "amygdala_rules.json")
        )
        self.decision_table = rust.PyDecisionTable.from_file(
            os.path.join(config_root, "zh", "prefrontal_decisions.json")
        )

        # 海马体事件存储
        db_path = os.path.join(os.path.dirname(__file__), "..", "data", "hippocampus", "events.db")
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.event_store = rust.PyEventStore.new(db_path)
        self.retrieval_engine = rust.PyRetrievalEngine.new(self.event_store)

        # 初始化 Python AI 模块
        self.thalamus = Thalamus(
            encoder_model_path=os.path.join(config_root, "..", "data", "models", "thalamus_encoder"),
            prototype_store=self.thalamus_prototypes
        )
        self.broca = Broca(
            slm_model_path=os.path.join(config_root, "..", "data", "models", "broca_slm"),
            templates_path=os.path.join(config_root, "zh", "broca_templates.json")
        )

        # 工作记忆缓冲区
        self.working_memory: List[Dict[str, Any]] = []

        # === 公库扩展预留接口 ===
        # 此处可初始化公库门面，例如：
        # self.public_kg_facade = self._init_public_kg_facade()
        # 若未配置公库或初始化失败，保持为 None
        self.public_kg_facade = None
        # ========================

        self.logger.info("光脑方案初始化完成")

    def _init_public_kg_facade(self):
        """
        公库扩展初始化方法（预留）。
        贡献者可在 extensions/public_kg/ 中实现并在此处调用。
        返回门面实例，若不可用则返回 None。
        """
        try:
            # 示例：动态导入公库模块
            # from extensions.public_kg import PublicKnowledgeFacade
            # return PublicKnowledgeFacade.from_config()
            return None
        except Exception:
            return None

    def perceive_time_hint(self, text: str) -> Optional[Tuple[int, int]]:
        """
        从用户输入中解析时间表达，返回 (since_timestamp, until_timestamp) 范围。
        """
        now = int(time.time())
        text_lower = text.lower()

        if "昨天" in text or "yesterday" in text_lower:
            since = now - 86400
            until = now
            return (since, until)
        elif "今天" in text or "today" in text_lower:
            since = now - 86400
            until = now + 86400
            return (since, until)
        elif "上周" in text or "last week" in text_lower:
            since = now - 7 * 86400
            until = now
            return (since, until)
        elif "最近" in text or "recent" in text_lower:
            since = now - 3 * 86400
            until = now
            return (since, until)
        else:
            return None

    def process_input(self, user_input: str) -> str:
        """处理单轮用户输入，返回系统回复"""
        self.logger.info(f"用户输入: {user_input}")

        # 1. 丘脑感知
        perception = self.thalamus.perceive(user_input)
        self.logger.debug(f"丘脑感知: {perception}")

        # 2. 解析时间提示
        time_range = self.perceive_time_hint(user_input)

        # 3. 前额叶调度决策
        intent = perception["intent"]
        domain = perception["domain"]
        polarity = perception["polarity"]
        keywords = perception["keywords"]

        schedule_json = self.decision_table.match_decision(intent, domain)
        schedule, fusion = json.loads(schedule_json)

        # 4. 调用下级模块
        fact = None
        style = "Normal"

        # 调用杏仁核
        if schedule["call_amygdala"]:
            style = self.amygdala.infer(intent, polarity)

        # 调用小脑
        if schedule["call_cerebellum"]:
            options = {"keywords": keywords, "limit": 1}
            results = self.graph_store.query(json.dumps(options))
            if results:
                fact = json.loads(results[0])
                self.graph_store.record_access(fact["id"])

        # === 公库补充检索（预留） ===
        # 当小脑无结果且公库门面可用时，从公库获取
        if fact is None and self.public_kg_facade is not None:
            try:
                pub_fact = self.public_kg_facade.query_one(keywords)
                if pub_fact:
                    fact = pub_fact
                    # 将公库知识写回小脑，使其成为生长知识
                    self.graph_store.upsert(json.dumps(fact))
            except Exception as e:
                self.logger.warning(f"公库检索失败: {e}")
        # ============================

        # 调用海马体（获取相关历史）
        if schedule.get("call_hippocampus", False):
            time_range_tuple = time_range if time_range else None
            history = self.retrieval_engine.search(keywords, time_range_tuple, 3)
            # 历史信息可用于增强上下文，当前版本暂未使用

        # 5. 融合生成决策包
        decision_package = {
            "intent": intent,
            "fact": fact,
            "style": style,
            "fallback_action": fusion.get("fallback") if not fact else None
        }

        # 6. 布罗卡区生成回复
        reply = self.broca.generate(decision_package)

        # 7. 存储情景事件至海马体
        event_id = f"evt_{int(time.time() * 1000)}"
        event = {
            "id": event_id,
            "timestamp": int(time.time()),
            "user_input": user_input,
            "intent": intent,
            "polarity": polarity,
            "domain": domain,
            "fact_id": fact["id"] if fact else None,
            "reply": reply,
            "access_count": 0
        }
        self.event_store.insert(json.dumps(event))

        # 8. 更新工作记忆
        self.working_memory.append({
            "intent": intent,
            "fact": fact,
            "style": style,
            "certainty": perception["certainty"]
        })
        if len(self.working_memory) > 10:
            self.working_memory.pop(0)

        self.logger.info(f"系统回复: {reply}")
        return reply

    def run_interactive(self):
        """交互式对话循环"""
        print("光脑方案交互模式 (输入 'exit' 退出)")
        while True:
            try:
                user_input = input("> ").strip()
                if user_input.lower() in ("exit", "quit", "退出"):
                    break
                if not user_input:
                    continue
                reply = self.process_input(user_input)
                print(f"光脑: {reply}")
            except KeyboardInterrupt:
                break
            except Exception as e:
                self.logger.error(f"处理输入时出错: {e}")
                print("抱歉，处理过程中出现错误。")


def main():
    """主函数"""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    config_root = os.path.join(script_dir, "..", "config")

    data_dir = os.path.join(script_dir, "..", "data")
    os.makedirs(os.path.join(data_dir, "knowledge"), exist_ok=True)
    os.makedirs(os.path.join(data_dir, "hippocampus"), exist_ok=True)
    os.makedirs(os.path.join(data_dir, "models"), exist_ok=True)

    lb = LightBrain(config_root)
    lb.run_interactive()


if __name__ == "__main__":
    main()