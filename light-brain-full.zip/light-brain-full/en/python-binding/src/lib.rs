use pyo3::prelude::*;
use std::sync::Arc;
use parking_lot::RwLock;
use serde_json;

use light_brain_core::cerebellum::{GraphStore, KnowledgeEntry, MemoryTier, QueryOptions, DecayConfig};
use light_brain_core::amygdala::{Amygdala, Intent, Polarity};
use light_brain_core::prefrontal::{DecisionTable, CreativeController, CreativeMode};
use light_brain_core::hippocampus::{EventStore, EpisodicEvent, RetrievalEngine};

#[pyclass]
struct PyGraphStore {
    inner: Arc<GraphStore>,
}

#[pymethods]
impl PyGraphStore {
    #[new]
    fn new() -> Self {
        PyGraphStore { inner: Arc::new(GraphStore::new()) }
    }

    fn upsert(&self, entry_json: &str) -> PyResult<()> {
        let entry: KnowledgeEntry = serde_json::from_str(entry_json).map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        self.inner.upsert(entry).map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e))?;
        Ok(())
    }

    fn query(&self, options_json: &str) -> PyResult<String> {
        let options: QueryOptions = serde_json::from_str(options_json).map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        let results = self.inner.query(&options);
        serde_json::to_string(&results).map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))
    }

    fn get_by_id(&self, id: &str) -> PyResult<Option<String>> {
        if let Some(entry) = self.inner.get_by_id(id) {
            Ok(Some(serde_json::to_string(&entry).unwrap()))
        } else {
            Ok(None)
        }
    }

    fn delete(&self, id: &str) -> bool {
        self.inner.delete(id)
    }

    fn count(&self) -> usize {
        self.inner.count()
    }
}

#[pyclass]
struct PyAmygdala {
    inner: Amygdala,
}

#[pymethods]
impl PyAmygdala {
    #[staticmethod]
    fn from_file(path: &str) -> PyResult<Self> {
        let inner = Amygdala::from_file(path).map_err(|e| PyErr::new::<pyo3::exceptions::PyIOError, _>(e.to_string()))?;
        Ok(PyAmygdala { inner })
    }

    fn infer(&self, intent: &str, polarity: &str) -> PyResult<String> {
        let style = self.inner.infer(
            match intent {
                "AskFact" => Intent::AskFact,
                "ExpressOpinion" => Intent::ExpressOpinion,
                "Chat" => Intent::Chat,
                "TestBoundary" => Intent::TestBoundary,
                _ => Intent::Unknown,
            },
            match polarity {
                "Positive" => Polarity::Positive,
                "Neutral" => Polarity::Neutral,
                "Negative" => Polarity::Negative,
                "Playful" => Polarity::Playful,
                "Aggressive" => Polarity::Aggressive,
                _ => Polarity::Any,
            }
        );
        Ok(format!("{:?}", style))
    }
}

#[pyclass]
struct PyDecisionTable {
    inner: DecisionTable,
}

#[pymethods]
impl PyDecisionTable {
    #[staticmethod]
    fn from_file(path: &str) -> PyResult<Self> {
        let inner = DecisionTable::from_file(path).map_err(|e| PyErr::new::<pyo3::exceptions::PyIOError, _>(e.to_string()))?;
        Ok(PyDecisionTable { inner })
    }

    fn match_decision(&self, intent: &str, domain: &str) -> PyResult<String> {
        let (schedule, fusion) = self.inner.match_decision(
            match intent {
                "AskFact" => light_brain_core::prefrontal::Intent::AskFact,
                "ExpressOpinion" => light_brain_core::prefrontal::Intent::ExpressOpinion,
                "Chat" => light_brain_core::prefrontal::Intent::Chat,
                "TestBoundary" => light_brain_core::prefrontal::Intent::TestBoundary,
                _ => light_brain_core::prefrontal::Intent::Unknown,
            },
            match domain {
                "InDomain" => light_brain_core::prefrontal::Domain::InDomain,
                "OutDomain" => light_brain_core::prefrontal::Domain::OutDomain,
                "Meta" => light_brain_core::prefrontal::Domain::Meta,
                "Daily" => light_brain_core::prefrontal::Domain::Daily,
                _ => light_brain_core::prefrontal::Domain::Any,
            }
        );
        serde_json::to_string(&(schedule, fusion)).map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))
    }
}

#[pyclass]
struct PyEventStore {
    inner: Arc<EventStore>,
}

#[pymethods]
impl PyEventStore {
    #[staticmethod]
    fn new(path: &str) -> PyResult<Self> {
        let inner = EventStore::new(path).map_err(|e| PyErr::new::<pyo3::exceptions::PyIOError, _>(e.to_string()))?;
        Ok(PyEventStore { inner: Arc::new(inner) })
    }

    fn insert(&self, event_json: &str) -> PyResult<()> {
        let event: EpisodicEvent = serde_json::from_str(event_json).map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        self.inner.insert(event).map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
        Ok(())
    }
}

#[pyclass]
struct PyRetrievalEngine {
    inner: RetrievalEngine,
}

#[pymethods]
impl PyRetrievalEngine {
    #[staticmethod]
    fn new(store: &PyEventStore) -> Self {
        PyRetrievalEngine { inner: RetrievalEngine::new((*store.inner).clone()) }
    }

    fn search(&self, keywords: Vec<String>, time_range: Option<(u64, u64)>, limit: usize) -> PyResult<String> {
        let results = self.inner.search(&keywords, time_range, limit);
        serde_json::to_string(&results).map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))
    }
}

#[pymodule]
fn light_brain_binding(_py: Python, m: &PyModule) -> PyResult<()> {
    m.add_class::<PyGraphStore>()?;
    m.add_class::<PyAmygdala>()?;
    m.add_class::<PyDecisionTable>()?;
    m.add_class::<PyEventStore>()?;
    m.add_class::<PyRetrievalEngine>()?;
    Ok(())
}