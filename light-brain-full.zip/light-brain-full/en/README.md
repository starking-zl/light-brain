# Light-Brain Scheme

The Light-Brain Scheme is a growth-based neuro-symbolic fusion architecture for general intelligence.

[中文版本](../README.md)

---

## Project Structure

This repository contains the full version code of the Light-Brain Scheme, including:
- Rust core engine (symbolic reasoning, knowledge storage, growth scheduling)
- Python AI layer (perception, language generation)
- PyO3 bindings for seamless integration

The MVP version is located in the sibling directory `光脑方案MVP/`.

---

## Quick Start

### Build the Rust core
```bash
cd rust-core
cargo build --release
```

Build Python bindings

```bash
cd python-binding
maturin develop
```

Run the main entry

```bash
cd scripts
python run.py
```

---

Documentation

· Architecture
· Implementation Roadmap
· Contributing Guide
· English-Chinese Glossary

---

License

This project is licensed under the MIT License.

```