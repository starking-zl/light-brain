#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
光脑方案种子知识库初始化脚本
将语言中立的抽象元知识导入小脑知识图谱。
"""

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from light_brain.utils.binding_helper import get_rust_binding

def init_knowledge():
    rust = get_rust_binding()
    if rust is None:
        print("错误：Rust 绑定库未找到，请先编译")
        return

    store = rust.PyGraphStore()
    seed_file = os.path.join(os.path.dirname(__file__), "..", "data", "knowledge", "seed.json")
    
    if not os.path.exists(seed_file):
        print(f"种子文件不存在: {seed_file}")
        return

    with open(seed_file, "r", encoding="utf-8") as f:
        seed_data = json.load(f)

    for entry in seed_data.get("entries", []):
        store.upsert(json.dumps(entry))
        print(f"已导入: {entry['id']}")

    print("种子知识库初始化完成")

if __name__ == "__main__":
    init_knowledge()