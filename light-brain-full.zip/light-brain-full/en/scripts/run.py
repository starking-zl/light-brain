#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Light-Brain Scheme Main Entry (English Version)
Orchestrates Thalamus, Prefrontal, Amygdala, Cerebellum, Hippocampus, and Broca.
"""

import os
import sys
import json
import time
from typing import Dict, Any, Optional, List, Tuple

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from light_brain import Thalamus, Broca
from light_brain.utils.config import ConfigManager
from light_brain.utils.logger import setup_logger
from light_brain.utils.binding_helper import get_rust_binding

rust = get_rust_binding()
if rust is None:
    raise ImportError("Rust binding library not found. Please compile first.")


class LightBrain:
    """Light-Brain Scheme Main Controller"""

    def __init__(self, config_root: str):
        self.logger = setup_logger("light_brain")
        self.config = ConfigManager(config_root)

        self.prefrontal_decisions = self.config.load_json("prefrontal_decisions.json")
        self.amygdala_rules = self.config.load_json("amygdala_rules.json")
        self.broca_templates = self.config.load_json("broca_templates.json")
        self.creative_profiles = self.config.load_json("creative_profiles.json")
        self.thalamus_prototypes = self.config.load_json("thalamus_prototypes.json")

        self.graph_store = rust.PyGraphStore()
        self.amygdala = rust.PyAmygdala.from_file(
            os.path.join(config_root, "amygdala_rules.json")
        )
        self.decision_table = rust.PyDecisionTable.from_file(
            os.path.join(config_root, "prefrontal_decisions.json")
        )

        db_path = os.path.join(os.path.dirname(__file__), "..", "data", "hippocampus", "events.db")
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.event_store = rust.PyEventStore.new(db_path)
        self.retrieval_engine = rust.PyRetrievalEngine.new(self.event_store)

        self.thalamus = Thalamus(
            encoder_model_path=os.path.join(config_root, "..", "data", "models", "thalamus_encoder"),
            prototype_store=self.thalamus_prototypes
        )
        self.broca = Broca(
            slm_model_path=os.path.join(config_root, "..", "data", "models", "broca_slm"),
            templates_path=os.path.join(config_root, "broca_templates.json")
        )

        self.working_memory: List[Dict[str, Any]] = []

        # === Public KG Extension Reserved Interface ===
        # Initialize public knowledge facade here if available, e.g.:
        # self.public_kg_facade = self._init_public_kg_facade()
        # Keep None if not configured or unavailable.
        self.public_kg_facade = None
        # ==============================================

        self.logger.info("Light-Brain initialized (English version)")

    def _init_public_kg_facade(self):
        """
        Public KG extension initialization method (reserved).
        Contributors may implement this in extensions/public_kg/ and call it here.
        Returns a facade instance, or None if unavailable.
        """
        try:
            # Example: dynamically import the public KG module
            # from extensions.public_kg import PublicKnowledgeFacade
            # return PublicKnowledgeFacade.from_config()
            return None
        except Exception:
            return None

    def perceive_time_hint(self, text: str) -> Optional[Tuple[int, int]]:
        """
        Parse time expressions from user input, returning (since, until) timestamp range.
        """
        now = int(time.time())
        text_lower = text.lower()

        if "yesterday" in text_lower:
            return (now - 86400, now)
        elif "today" in text_lower:
            return (now - 86400, now + 86400)
        elif "last week" in text_lower:
            return (now - 7 * 86400, now)
        elif "recent" in text_lower:
            return (now - 3 * 86400, now)
        return None

    def process_input(self, user_input: str) -> str:
        """Process a single turn of user input and return the system reply."""
        self.logger.info(f"User input: {user_input}")

        perception = self.thalamus.perceive(user_input)
        self.logger.debug(f"Thalamus perception: {perception}")

        time_range = self.perceive_time_hint(user_input)

        intent = perception["intent"]
        domain = perception["domain"]
        polarity = perception["polarity"]
        keywords = perception["keywords"]

        schedule_json = self.decision_table.match_decision(intent, domain)
        schedule, fusion = json.loads(schedule_json)

        fact = None
        style = "Normal"

        if schedule["call_amygdala"]:
            style = self.amygdala.infer(intent, polarity)

        if schedule["call_cerebellum"]:
            options = {"keywords": keywords, "limit": 1}
            results = self.graph_store.query(json.dumps(options))
            if results:
                fact = json.loads(results[0])
                self.graph_store.record_access(fact["id"])

        # === Public KG Supplemental Retrieval (Reserved) ===
        if fact is None and self.public_kg_facade is not None:
            try:
                pub_fact = self.public_kg_facade.query_one(keywords)
                if pub_fact:
                    fact = pub_fact
                    self.graph_store.upsert(json.dumps(fact))
            except Exception as e:
                self.logger.warning(f"Public KG retrieval failed: {e}")
        # ==================================================

        if schedule.get("call_hippocampus", False):
            time_range_tuple = time_range if time_range else None
            history = self.retrieval_engine.search(keywords, time_range_tuple, 3)

        decision_package = {
            "intent": intent,
            "fact": fact,
            "style": style,
            "fallback_action": fusion.get("fallback") if not fact else None
        }

        reply = self.broca.generate(decision_package)

        event_id = f"evt_{int(time.time() * 1000)}"
        event = {
            "id": event_id,
            "timestamp": int(time.time()),
            "user_input": user_input,
            "intent": intent,
            "polarity": polarity,
            "domain": domain,
            "fact_id": fact["id"] if fact else None,
            "reply": reply,
            "access_count": 0
        }
        self.event_store.insert(json.dumps(event))

        self.working_memory.append({
            "intent": intent,
            "fact": fact,
            "style": style,
            "certainty": perception["certainty"]
        })
        if len(self.working_memory) > 10:
            self.working_memory.pop(0)

        self.logger.info(f"Reply: {reply}")
        return reply

    def run_interactive(self):
        """Interactive conversation loop."""
        print("Light-Brain Interactive Mode (type 'exit' to quit)")
        while True:
            try:
                user_input = input("> ").strip()
                if user_input.lower() in ("exit", "quit"):
                    break
                if not user_input:
                    continue
                reply = self.process_input(user_input)
                print(f"Light-Brain: {reply}")
            except KeyboardInterrupt:
                break
            except Exception as e:
                self.logger.error(f"Error processing input: {e}")
                print("Sorry, an error occurred.")


def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    config_root = os.path.join(script_dir, "..", "config")

    data_dir = os.path.join(script_dir, "..", "data")
    os.makedirs(os.path.join(data_dir, "knowledge"), exist_ok=True)
    os.makedirs(os.path.join(data_dir, "hippocampus"), exist_ok=True)
    os.makedirs(os.path.join(data_dir, "models"), exist_ok=True)

    lb = LightBrain(config_root)
    lb.run_interactive()


if __name__ == "__main__":
    main()