// Light-Brain Scheme Rust Core Library
// Provides core functionality for symbolic reasoning, knowledge storage, growth scheduling, and memory management.

pub mod thalamus;
pub mod prefrontal;
pub mod amygdala;
pub mod cerebellum;
pub mod hippocampus;
pub mod growth;
pub mod memory;
pub mod utils;

// Re-export commonly used types for external convenience
pub use cerebellum::{GraphStore, KnowledgeEntry, MemoryTier, QueryOptions, DecayConfig};
pub use amygdala::{Amygdala, Style, Intent, Polarity};
pub use prefrontal::{DecisionTable, CreativeController, CreativeMode, WorkingMemory, FusionEngine};
pub use hippocampus::{EventStore, EpisodicEvent, RetrievalEngine, ConsolidationEngine};
pub use growth::{KnowledgeExtractor, GrowthScheduler, ConflictDetector};
pub use memory::{TierManager, GarbageCollector};
pub use thalamus::{PrototypeStore, grounding_layer};
pub use utils::time::{current_timestamp, days_between};