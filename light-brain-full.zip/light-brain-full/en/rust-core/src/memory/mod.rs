// Memory management subsystem - Three-tier memory state machine and garbage collection
// Manages the flow among Active, Dormant, and Garbage libraries and user interaction.

pub mod tier;
pub mod garbage;

pub use tier::TierManager;
pub use garbage::GarbageCollector;