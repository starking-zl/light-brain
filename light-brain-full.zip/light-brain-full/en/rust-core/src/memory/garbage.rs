// Garbage collector
// Manages the Garbage library and provides user-operable cleanup interfaces.

use crate::cerebellum::{GraphStore, KnowledgeEntry, MemoryTier, QueryOptions};
use crate::utils::time::current_timestamp;
use std::sync::Arc;

pub struct GarbageCollector {
    store: Arc<GraphStore>,
}

impl GarbageCollector {
    pub fn new(store: Arc<GraphStore>) -> Self {
        GarbageCollector { store }
    }

    pub fn list_garbage(&self) -> Vec<KnowledgeEntry> {
        let mut options = QueryOptions::default();
        options.tier = Some(MemoryTier::Garbage);
        options.limit = 10000;
        self.store.query(&options)
    }

    pub fn delete_by_id(&self, id: &str) -> bool {
        if let Some(entry) = self.store.get_by_id(id) {
            if entry.tier == MemoryTier::Garbage {
                return self.store.delete(id);
            }
        }
        false
    }

    pub fn purge_all(&self) -> usize {
        let garbage = self.list_garbage();
        let mut count = 0;
        for entry in garbage {
            if self.store.delete(&entry.id) {
                count += 1;
            }
        }
        count
    }

    pub fn restore(&self, id: &str) -> bool {
        if let Some(mut entry) = self.store.get_by_id(id) {
            if entry.tier == MemoryTier::Garbage {
                entry.tier = MemoryTier::Active;
                entry.certainty = 0.7;
                entry.last_accessed = current_timestamp();
                self.store.upsert(entry).is_ok()
            } else {
                false
            }
        } else {
            false
        }
    }
}