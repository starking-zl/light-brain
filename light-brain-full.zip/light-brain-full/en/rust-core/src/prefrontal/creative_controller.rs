// Creative controller - Three-knob linkage loop
// Temperature τ, Gate γ, Evaluation weight ε

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum CreativeMode {
    Rigorous,
    Daily,
    Creative,
    Counterfactual,
}

#[derive(Debug, Clone, Copy)]
pub struct KnobValues {
    pub temperature: f32,
    pub gate: f32,
    pub novelty_weight: f32,
}

impl Default for KnobValues {
    fn default() -> Self {
        KnobValues {
            temperature: 0.8,
            gate: 0.6,
            novelty_weight: 0.2,
        }
    }
}

pub struct CreativeController {
    mode: CreativeMode,
    baseline: KnobValues,
}

impl CreativeController {
    pub fn new(mode: CreativeMode) -> Self {
        let baseline = match mode {
            CreativeMode::Rigorous => KnobValues {
                temperature: 0.4,
                gate: 0.9,
                novelty_weight: 0.0,
            },
            CreativeMode::Daily => KnobValues {
                temperature: 0.8,
                gate: 0.6,
                novelty_weight: 0.2,
            },
            CreativeMode::Creative => KnobValues {
                temperature: 1.3,
                gate: 0.3,
                novelty_weight: 0.7,
            },
            CreativeMode::Counterfactual => KnobValues {
                temperature: 1.2,
                gate: 0.1,
                novelty_weight: 0.8,
            },
        };
        CreativeController { mode, baseline }
    }

    pub fn get_knobs(&self) -> KnobValues {
        self.baseline
    }

    pub fn adjust(&mut self, diversity: f32, conflict: f32) {
        if diversity < 0.3 {
            self.baseline.temperature = (self.baseline.temperature + 0.1).min(2.0);
        }
        if conflict > 0.7 {
            self.baseline.gate = (self.baseline.gate + 0.1).min(1.0);
        }
    }
}