// Prefrontal decision table
// Matches scheduling rules based on intent and domain from Thalamus output.

use serde::{Deserialize, Serialize};
use std::fs;
use std::path::Path;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Intent {
    AskFact,
    ExpressOpinion,
    Chat,
    TestBoundary,
    Unknown,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Domain {
    InDomain,
    OutDomain,
    Meta,
    Daily,
    Any,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Schedule {
    pub call_cerebellum: bool,
    pub call_amygdala: bool,
    pub call_hippocampus: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Fusion {
    pub fact_source: FactSource,
    pub style_source: StyleSource,
    pub fallback: FallbackAction,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum FactSource {
    Cerebellum,
    None,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum StyleSource {
    Amygdala,
    None,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum FallbackAction {
    UseFallback,
    UseConfused,
    UseDefensive,
    UseChat,
    OpinionOnly,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Decision {
    pub condition: DecisionCondition,
    pub schedule: Schedule,
    pub fusion: Fusion,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DecisionCondition {
    pub intent: Intent,
    pub domain: Domain,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct DecisionTableFile {
    decisions: Vec<Decision>,
    default: Decision,
}

pub struct DecisionTable {
    decisions: Vec<Decision>,
    default: Decision,
}

impl DecisionTable {
    pub fn from_file<P: AsRef<Path>>(path: P) -> Result<Self, Box<dyn std::error::Error>> {
        let content = fs::read_to_string(path)?;
        let file: DecisionTableFile = serde_json::from_str(&content)?;
        Ok(DecisionTable {
            decisions: file.decisions,
            default: file.default,
        })
    }

    pub fn match_decision(&self, intent: Intent, domain: Domain) -> (Schedule, Fusion) {
        for dec in &self.decisions {
            if dec.condition.intent == intent {
                if dec.condition.domain == domain || dec.condition.domain == Domain::Any {
                    return (dec.schedule.clone(), dec.fusion.clone());
                }
            }
        }
        (self.default.schedule.clone(), self.default.fusion.clone())
    }
}