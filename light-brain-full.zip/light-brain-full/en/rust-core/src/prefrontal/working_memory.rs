// Working memory - Temporary buffer
// Stores intermediate states during reasoning.

use std::collections::VecDeque;
use crate::cerebellum::KnowledgeEntry;
use super::decision_table::Intent;

#[derive(Debug, Clone)]
pub struct WorkingMemorySlot {
    pub intent: Intent,
    pub fact: Option<KnowledgeEntry>,
    pub style: String,
    pub certainty: f32,
}

pub struct WorkingMemory {
    slots: VecDeque<WorkingMemorySlot>,
    capacity: usize,
}

impl WorkingMemory {
    pub fn new(capacity: usize) -> Self {
        WorkingMemory {
            slots: VecDeque::new(),
            capacity,
        }
    }

    pub fn push(&mut self, slot: WorkingMemorySlot) {
        if self.slots.len() >= self.capacity {
            self.slots.pop_front();
        }
        self.slots.push_back(slot);
    }

    pub fn peek_recent(&self) -> Option<&WorkingMemorySlot> {
        self.slots.back()
    }

    pub fn clear(&mut self) {
        self.slots.clear();
    }

    pub fn all_slots(&self) -> Vec<WorkingMemorySlot> {
        self.slots.iter().cloned().collect()
    }
}