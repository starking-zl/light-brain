// Amygdala module - Emotion and style evaluation
pub mod rule_engine;

pub use rule_engine::{Amygdala, Rule, StyleOutput};