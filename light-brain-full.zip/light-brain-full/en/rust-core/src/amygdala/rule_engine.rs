// Amygdala rule engine
// Maps intent and polarity to language style modifiers based on preset rules.

use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs;
use std::path::Path;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Intent {
    AskFact,
    ExpressOpinion,
    Chat,
    TestBoundary,
    Unknown,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Polarity {
    Positive,
    Neutral,
    Negative,
    Playful,
    Aggressive,
    Any,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Style {
    Normal,
    Enthusiastic,
    Cautious,
    Playful,
    Defensive,
    Confused,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Rule {
    pub condition: RuleCondition,
    pub output: StyleOutput,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RuleCondition {
    pub intent: Intent,
    pub polarity: Polarity,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StyleOutput {
    pub style: Style,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct RulesFile {
    rules: Vec<Rule>,
    default: StyleOutput,
}

pub struct Amygdala {
    rules: Vec<Rule>,
    default_style: Style,
}

impl Amygdala {
    pub fn from_file<P: AsRef<Path>>(path: P) -> Result<Self, Box<dyn std::error::Error>> {
        let content = fs::read_to_string(path)?;
        let rules_file: RulesFile = serde_json::from_str(&content)?;
        Ok(Amygdala {
            rules: rules_file.rules,
            default_style: rules_file.default.style,
        })
    }

    pub fn new(rules: Vec<Rule>, default_style: Style) -> Self {
        Amygdala {
            rules,
            default_style,
        }
    }

    pub fn infer(&self, intent: Intent, polarity: Polarity) -> Style {
        for rule in &self.rules {
            if rule.condition.intent == intent {
                if rule.condition.polarity == polarity || rule.condition.polarity == Polarity::Any {
                    return rule.output.style;
                }
            }
        }
        self.default_style
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_rule_matching() {
        let rules = vec![
            Rule {
                condition: RuleCondition {
                    intent: Intent::AskFact,
                    polarity: Polarity::Positive,
                },
                output: StyleOutput { style: Style::Enthusiastic },
            },
            Rule {
                condition: RuleCondition {
                    intent: Intent::TestBoundary,
                    polarity: Polarity::Any,
                },
                output: StyleOutput { style: Style::Defensive },
            },
        ];
        let amygdala = Amygdala::new(rules, Style::Normal);

        assert_eq!(amygdala.infer(Intent::AskFact, Polarity::Positive), Style::Enthusiastic);
        assert_eq!(amygdala.infer(Intent::AskFact, Polarity::Negative), Style::Normal);
        assert_eq!(amygdala.infer(Intent::TestBoundary, Polarity::Aggressive), Style::Defensive);
        assert_eq!(amygdala.infer(Intent::TestBoundary, Polarity::Playful), Style::Defensive);
    }
}