// Symbol grounding layer
// Computes cosine similarity between input vector and all prototypes, outputs label probability distribution.

use super::prototype::PrototypeStore;
use std::collections::HashMap;

#[derive(Debug, Clone)]
pub struct GroundingResult {
    pub label: String,
    pub probability: f32,
}

fn cosine_similarity(a: &[f32], b: &[f32]) -> f32 {
    let dot: f32 = a.iter().zip(b).map(|(x, y)| x * y).sum();
    let norm_a: f32 = a.iter().map(|x| x * x).sum::<f32>().sqrt();
    let norm_b: f32 = b.iter().map(|y| y * y).sum::<f32>().sqrt();
    if norm_a > 0.0 && norm_b > 0.0 {
        dot / (norm_a * norm_b)
    } else {
        0.0
    }
}

pub fn grounding_layer(
    input_vector: Vec<f32>,
    store: &PrototypeStore,
) -> Vec<GroundingResult> {
    let prototypes = store.get_all();
    let mut similarities: Vec<(String, f32)> = prototypes
        .iter()
        .map(|p| (p.label.clone(), cosine_similarity(&input_vector, &p.vector)))
        .collect();

    let max_sim = similarities
        .iter()
        .map(|(_, s)| *s)
        .fold(f32::MIN, f32::max);
    let exp_sum: f32 = similarities
        .iter()
        .map(|(_, s)| ((s - max_sim).exp()))
        .sum();
    
    similarities
        .into_iter()
        .map(|(label, sim)| {
            let prob = ((sim - max_sim).exp()) / exp_sum;
            GroundingResult { label, probability: prob }
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_cosine() {
        let a = vec![1.0, 0.0];
        let b = vec![0.0, 1.0];
        assert!((cosine_similarity(&a, &b) - 0.0).abs() < 0.001);
    }

    #[test]
    fn test_grounding() {
        let mut store = PrototypeStore::new();
        store.upsert("A".to_string(), vec![1.0, 0.0]);
        store.upsert("B".to_string(), vec![0.0, 1.0]);
        let results = grounding_layer(vec![1.0, 0.1], &store);
        assert_eq!(results.len(), 2);
        assert!(results[0].probability > results[1].probability);
    }
}