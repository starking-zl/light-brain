// Prototype vector storage
// Manages the prototype vectors for each symbolic label.

use std::collections::HashMap;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PrototypeEntry {
    pub label: String,
    pub vector: Vec<f32>,
    pub certainty_threshold: f32,
}

pub struct PrototypeStore {
    prototypes: HashMap<String, PrototypeEntry>,
    default_threshold: f32,
}

impl PrototypeStore {
    pub fn new() -> Self {
        PrototypeStore {
            prototypes: HashMap::new(),
            default_threshold: 0.5,
        }
    }

    pub fn upsert(&mut self, label: String, vector: Vec<f32>) {
        let entry = PrototypeEntry {
            label: label.clone(),
            vector,
            certainty_threshold: self.default_threshold,
        };
        self.prototypes.insert(label, entry);
    }

    pub fn get_all(&self) -> Vec<PrototypeEntry> {
        self.prototypes.values().cloned().collect()
    }

    pub fn get(&self, label: &str) -> Option<Vec<f32>> {
        self.prototypes.get(label).map(|e| e.vector.clone())
    }

    pub fn load_from_json(&mut self, json_str: &str) -> Result<(), serde_json::Error> {
        let entries: Vec<PrototypeEntry> = serde_json::from_str(json_str)?;
        for entry in entries {
            self.prototypes.insert(entry.label.clone(), entry);
        }
        Ok(())
    }

    pub fn to_json(&self) -> Result<String, serde_json::Error> {
        let entries: Vec<_> = self.prototypes.values().collect();
        serde_json::to_string(&entries)
    }
}

impl Default for PrototypeStore {
    fn default() -> Self {
        Self::new()
    }
}