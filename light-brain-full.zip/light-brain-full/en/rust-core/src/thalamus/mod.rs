// Thalamus module - Perception and symbol grounding
// Provides prototype vector storage and grounding layer for mapping continuous neural representations to discrete symbolic labels.

pub mod prototype;
pub mod grounding;

pub use prototype::PrototypeStore;
pub use grounding::grounding_layer;