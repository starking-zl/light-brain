// Time utility module
// Provides unified timestamp retrieval and time difference calculation.

use std::time::{SystemTime, UNIX_EPOCH};

pub fn current_timestamp() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

pub fn current_timestamp_millis() -> u128 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis()
}

pub fn days_between(t1: u64, t2: u64) -> f32 {
    (t1 as i64 - t2 as i64).abs() as f32 / 86400.0
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_current_timestamp() {
        let ts = current_timestamp();
        assert!(ts > 0);
    }

    #[test]
    fn test_days_between() {
        let t1 = 86400;
        let t2 = 0;
        assert!((days_between(t1, t2) - 1.0).abs() < 0.001);
    }
}