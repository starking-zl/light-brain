// Utility module - Common functions and helper types
// Provides shared decay calculation, timestamp utilities, and metrics recording.

pub mod decay;
pub mod metrics;
pub mod time;
pub mod time_provider;

pub use decay::{compute_decay, DecayParams};
pub use metrics::{MetricsCollector, MetricEvent, MetricType};
pub use time::{current_timestamp, current_timestamp_millis, days_between};
pub use time_provider::{TimeProvider, SystemTimeProvider, init_time_provider};