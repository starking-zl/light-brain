// Time provider trait and global singleton
// Supports pluggable external calendar interfaces, defaulting to system time.

use std::sync::OnceLock;
use std::time::{SystemTime, UNIX_EPOCH};

pub trait TimeProvider: Send + Sync {
    fn current_timestamp(&self) -> u64;
}

pub struct SystemTimeProvider;

impl TimeProvider for SystemTimeProvider {
    fn current_timestamp(&self) -> u64 {
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs()
    }
}

static TIME_PROVIDER: OnceLock<Box<dyn TimeProvider>> = OnceLock::new();

pub fn init_time_provider(provider: Box<dyn TimeProvider>) {
    let _ = TIME_PROVIDER.set(provider);
}

pub fn current_timestamp() -> u64 {
    TIME_PROVIDER
        .get()
        .map(|p| p.current_timestamp())
        .unwrap_or_else(|| SystemTimeProvider.current_timestamp())
}