// Generic decay formula
// Computes weight decay factor based on time and access frequency.

#[derive(Debug, Clone, Copy)]
pub struct DecayParams {
    pub lambda: f32,
    pub epsilon: f32,
}

impl Default for DecayParams {
    fn default() -> Self {
        DecayParams {
            lambda: 0.01,
            epsilon: 0.001,
        }
    }
}

pub fn compute_decay(
    delta_t: f32,
    frequency: f32,
    certainty: f32,
    params: DecayParams,
) -> f32 {
    let effective_freq = frequency.max(params.epsilon);
    let decay_factor = (-params.lambda * delta_t / effective_freq).exp();
    certainty * decay_factor
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_compute_decay() {
        let params = DecayParams::default();
        let weight1 = compute_decay(0.0, 10.0, 1.0, params);
        assert!(weight1 > 0.9);
        let weight2 = compute_decay(100.0, 0.1, 0.5, params);
        assert!(weight2 < 0.1);
    }
}