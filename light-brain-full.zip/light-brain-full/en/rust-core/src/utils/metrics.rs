// Metrics collector
// Records runtime metrics such as growth logs, inference latency, and certainty distribution.

use std::collections::VecDeque;
use std::sync::{Arc, Mutex};
use super::time::current_timestamp;

#[derive(Debug, Clone)]
pub struct MetricEvent {
    pub timestamp: u64,
    pub event_type: MetricType,
    pub value: f32,
    pub label: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MetricType {
    InferenceLatency,
    CertaintyScore,
    GrowthAction,
    KnowledgeDecay,
    UserFeedback,
}

pub struct MetricsCollector {
    events: Arc<Mutex<VecDeque<MetricEvent>>>,
    capacity: usize,
}

impl MetricsCollector {
    pub fn new(capacity: usize) -> Self {
        MetricsCollector {
            events: Arc::new(Mutex::new(VecDeque::with_capacity(capacity))),
            capacity,
        }
    }

    pub fn record(&self, event_type: MetricType, value: f32, label: impl Into<String>) {
        let event = MetricEvent {
            timestamp: current_timestamp(),
            event_type,
            value,
            label: label.into(),
        };
        let mut events = self.events.lock().unwrap();
        if events.len() >= self.capacity {
            events.pop_front();
        }
        events.push_back(event);
    }

    pub fn recent_events(&self) -> Vec<MetricEvent> {
        self.events.lock().unwrap().iter().cloned().collect()
    }

    pub fn aggregate_by_type(&self, event_type: MetricType) -> Option<f32> {
        let events = self.events.lock().unwrap();
        let filtered: Vec<f32> = events
            .iter()
            .filter(|e| e.event_type == event_type)
            .map(|e| e.value)
            .collect();
        if filtered.is_empty() {
            None
        } else {
            Some(filtered.iter().sum::<f32>() / filtered.len() as f32)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_record_and_aggregate() {
        let collector = MetricsCollector::new(10);
        collector.record(MetricType::InferenceLatency, 120.0, "test");
        collector.record(MetricType::InferenceLatency, 80.0, "test");
        let avg = collector.aggregate_by_type(MetricType::InferenceLatency);
        assert_eq!(avg, Some(100.0));
    }
}