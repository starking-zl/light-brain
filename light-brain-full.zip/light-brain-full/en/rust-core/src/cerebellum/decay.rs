// Cerebellum module - Decay and memory flow
// Implements weight decay based on time and access frequency, managing Active -> Dormant -> Garbage flow.

use super::graph_store::{GraphStore, KnowledgeEntry, MemoryTier};
use crate::utils::time::current_timestamp;

pub struct DecayConfig {
    pub lambda: f32,
    pub epsilon: f32,
    pub dormant_threshold: f32,
    pub garbage_threshold: f32,
    pub dormant_capacity_ratio: f32,
}

impl Default for DecayConfig {
    fn default() -> Self {
        DecayConfig {
            lambda: 0.01,
            epsilon: 0.001,
            dormant_threshold: 0.1,
            garbage_threshold: 0.01,
            dormant_capacity_ratio: 2.0,
        }
    }
}

impl GraphStore {
    pub fn apply_decay_and_flow(&self, config: &DecayConfig) {
        let current_time = current_timestamp();

        let mut entries = self.entries.write();
        for entry in entries.values_mut() {
            if entry.tier == MemoryTier::Garbage {
                continue;
            }

            let delta_t = (current_time - entry.last_accessed) as f32 / 86400.0;
            let frequency = (entry.access_count as f32 / 30.0).max(config.epsilon);
            
            let decay_factor = (-config.lambda * delta_t / frequency).exp();
            let old_weight = if entry.tier == MemoryTier::Active { 1.0 } else { 0.5 };
            let new_weight = old_weight * decay_factor * entry.certainty;

            let new_tier = if new_weight < config.garbage_threshold {
                MemoryTier::Garbage
            } else if new_weight < config.dormant_threshold {
                MemoryTier::Dormant
            } else {
                MemoryTier::Active
            };

            entry.tier = new_tier;
            entry.access_count = 0;
        }

        let (active_count, dormant_count) = self.count_by_tier();
        let max_dormant = (active_count as f32 * config.dormant_capacity_ratio) as usize;
        if dormant_count > max_dormant {
            self.evict_dormant_entries(dormant_count - max_dormant);
        }
    }

    fn count_by_tier(&self) -> (usize, usize) {
        let entries = self.entries.read();
        let mut active = 0;
        let mut dormant = 0;
        for entry in entries.values() {
            match entry.tier {
                MemoryTier::Active => active += 1,
                MemoryTier::Dormant => dormant += 1,
                MemoryTier::Garbage => {}
            }
        }
        (active, dormant)
    }

    fn evict_dormant_entries(&self, count: usize) {
        let mut entries = self.entries.write();
        let mut dormant_entries: Vec<&mut KnowledgeEntry> = entries
            .values_mut()
            .filter(|e| e.tier == MemoryTier::Dormant)
            .collect();

        dormant_entries.sort_by(|a, b| {
            let weight_a = a.certainty * (1.0 / (a.last_accessed as f32 + 1.0));
            let weight_b = b.certainty * (1.0 / (b.last_accessed as f32 + 1.0));
            weight_a.partial_cmp(&weight_b).unwrap()
        });

        for entry in dormant_entries.iter_mut().take(count) {
            entry.tier = MemoryTier::Garbage;
        }
    }

    pub fn purge_garbage(&self) -> usize {
        let mut entries = self.entries.write();
        let before = entries.len();
        entries.retain(|_, entry| entry.tier != MemoryTier::Garbage);
        let after = entries.len();
        before - after
    }

    pub fn record_access(&self, id: &str) {
        let mut entries = self.entries.write();
        if let Some(entry) = entries.get_mut(id) {
            entry.last_accessed = current_timestamp();
            entry.access_count += 1;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cerebellum::graph_store::{GraphStore, KnowledgeEntry, MemoryTier};

    #[test]
    fn test_decay_flow() {
        let store = GraphStore::new();
        let mut entry = KnowledgeEntry {
            id: "test".to_string(),
            subject: "s".to_string(),
            attribute: "a".to_string(),
            value: "v".to_string(),
            description: "d".to_string(),
            tags: vec![],
            certainty: 1.0,
            created_at: 1000,
            last_accessed: 1000,
            access_count: 0,
            tier: MemoryTier::Active,
        };
        store.upsert(entry.clone()).unwrap();

        let config = DecayConfig::default();
        store.apply_decay_and_flow(&config);

        let updated = store.get_by_id("test").unwrap();
        assert!(updated.tier == MemoryTier::Dormant || updated.tier == MemoryTier::Garbage);
    }
}