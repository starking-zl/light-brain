// Cerebellum module - Structured semantic memory
// Responsible for knowledge graph storage, retrieval, decay, and three-tier memory flow.

pub mod graph_store;
pub mod query;
pub mod decay;

pub use graph_store::{GraphStore, KnowledgeEntry, MemoryTier, QueryOptions};
pub use decay::DecayConfig;