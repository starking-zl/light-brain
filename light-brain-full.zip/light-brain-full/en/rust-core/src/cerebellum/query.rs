// Cerebellum module - Multi-strategy retrieval
// Implements exact match, tag match, keyword match, and vector retrieval (future).

use super::graph_store::{GraphStore, KnowledgeEntry, MemoryTier, QueryOptions};
use std::collections::HashSet;

impl GraphStore {
    pub fn search(&self, options: &QueryOptions) -> Vec<KnowledgeEntry> {
        let mut results = Vec::new();
        let mut seen_ids = HashSet::new();

        if options.subject.is_some() && options.attribute.is_some() {
            let exact_results = self.query_exact(
                options.subject.as_ref().unwrap(),
                options.attribute.as_ref().unwrap(),
                options.tier,
                options.min_certainty,
            );
            for entry in exact_results {
                if seen_ids.insert(entry.id.clone()) {
                    results.push(entry);
                }
            }
        }

        if !options.tags.is_empty() && results.len() < options.limit {
            let tag_results = self.query_by_tags(
                &options.tags,
                options.tier,
                options.min_certainty,
            );
            for entry in tag_results {
                if seen_ids.insert(entry.id.clone()) {
                    results.push(entry);
                    if results.len() >= options.limit {
                        break;
                    }
                }
            }
        }

        if !options.keywords.is_empty() && results.len() < options.limit {
            let keyword_results = self.query_by_keywords(
                &options.keywords,
                options.tier,
                options.min_certainty,
            );
            for entry in keyword_results {
                if seen_ids.insert(entry.id.clone()) {
                    results.push(entry);
                    if results.len() >= options.limit {
                        break;
                    }
                }
            }
        }

        results
    }

    fn query_exact(
        &self,
        subject: &str,
        attribute: &str,
        tier: Option<MemoryTier>,
        min_certainty: Option<f32>,
    ) -> Vec<KnowledgeEntry> {
        let mut results = Vec::new();
        let entries = self.entries.read();

        for entry in entries.values() {
            if entry.subject == subject && entry.attribute == attribute {
                if let Some(t) = tier {
                    if entry.tier != t {
                        continue;
                    }
                }
                if let Some(min_cert) = min_certainty {
                    if entry.certainty < min_cert {
                        continue;
                    }
                }
                results.push(entry.clone());
            }
        }
        results
    }

    fn query_by_tags(
        &self,
        tags: &[String],
        tier: Option<MemoryTier>,
        min_certainty: Option<f32>,
    ) -> Vec<KnowledgeEntry> {
        let mut results = Vec::new();
        let tag_index = self.tag_index.read();

        for tag in tags {
            if let Some(ids) = tag_index.get(tag) {
                for id in ids {
                    if let Some(entry) = self.get_by_id(id) {
                        if let Some(t) = tier {
                            if entry.tier != t {
                                continue;
                            }
                        }
                        if let Some(min_cert) = min_certainty {
                            if entry.certainty < min_cert {
                                continue;
                            }
                        }
                        results.push(entry);
                    }
                }
            }
        }
        results
    }

    fn query_by_keywords(
        &self,
        keywords: &[String],
        tier: Option<MemoryTier>,
        min_certainty: Option<f32>,
    ) -> Vec<KnowledgeEntry> {
        let mut results = Vec::new();
        let entries = self.entries.read();

        for entry in entries.values() {
            if let Some(t) = tier {
                if entry.tier != t {
                    continue;
                }
            }
            if let Some(min_cert) = min_certainty {
                if entry.certainty < min_cert {
                    continue;
                }
            }

            let mut matched = false;
            for kw in keywords {
                if entry.subject.contains(kw)
                    || entry.attribute.contains(kw)
                    || entry.value.contains(kw)
                    || entry.description.contains(kw)
                {
                    matched = true;
                    break;
                }
            }
            if matched {
                results.push(entry.clone());
            }
        }
        results
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cerebellum::graph_store::{GraphStore, KnowledgeEntry, MemoryTier};

    #[test]
    fn test_search_strategies() {
        let store = GraphStore::new();
        
        let entry1 = KnowledgeEntry {
            id: "alpha".to_string(),
            subject: "subject_one".to_string(),
            attribute: "attr_one".to_string(),
            value: "val_one".to_string(),
            description: "Description containing keyword magic.".to_string(),
            tags: vec!["tag_a".to_string()],
            certainty: 0.9,
            created_at: 1000,
            last_accessed: 1000,
            access_count: 0,
            tier: MemoryTier::Active,
        };
        let entry2 = KnowledgeEntry {
            id: "beta".to_string(),
            subject: "subject_two".to_string(),
            attribute: "attr_two".to_string(),
            value: "val_two".to_string(),
            description: "Another generic description.".to_string(),
            tags: vec!["tag_b".to_string()],
            certainty: 0.8,
            created_at: 1000,
            last_accessed: 1000,
            access_count: 0,
            tier: MemoryTier::Active,
        };
        store.upsert(entry1).unwrap();
        store.upsert(entry2).unwrap();

        let mut options = QueryOptions::default();
        options.subject = Some("subject_one".to_string());
        options.attribute = Some("attr_one".to_string());
        options.limit = 10;
        let results = store.search(&options);
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].id, "alpha");

        let mut options = QueryOptions::default();
        options.keywords = vec!["magic".to_string()];
        options.limit = 10;
        let results = store.search(&options);
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].id, "alpha");
    }
}