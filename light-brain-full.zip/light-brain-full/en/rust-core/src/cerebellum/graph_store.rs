// Cerebellum module - Knowledge Graph Storage Wrapper
// This file provides encapsulation of the OverGraph database for CRUD operations on knowledge entries.
// Field names use English.

use std::collections::HashMap;
use std::path::Path;
use std::sync::Arc;
use parking_lot::RwLock;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct KnowledgeEntry {
    pub id: String,
    pub subject: String,
    pub attribute: String,
    pub value: String,
    pub description: String,
    pub tags: Vec<String>,
    pub certainty: f32,
    pub created_at: u64,
    pub last_accessed: u64,
    pub access_count: u64,
    pub tier: MemoryTier,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum MemoryTier {
    Active,
    Dormant,
    Garbage,
}

impl Default for MemoryTier {
    fn default() -> Self {
        MemoryTier::Active
    }
}

#[derive(Debug, Clone, Default)]
pub struct QueryOptions {
    pub subject: Option<String>,
    pub attribute: Option<String>,
    pub keywords: Vec<String>,
    pub tags: Vec<String>,
    pub tier: Option<MemoryTier>,
    pub min_certainty: Option<f32>,
    pub limit: usize,
}

pub struct GraphStore {
    entries: Arc<RwLock<HashMap<String, KnowledgeEntry>>>,
    subject_index: Arc<RwLock<HashMap<String, Vec<String>>>>,
    tag_index: Arc<RwLock<HashMap<String, Vec<String>>>>,
}

impl GraphStore {
    pub fn new() -> Self {
        GraphStore {
            entries: Arc::new(RwLock::new(HashMap::new())),
            subject_index: Arc::new(RwLock::new(HashMap::new())),
            tag_index: Arc::new(RwLock::new(HashMap::new())),
        }
    }

    pub fn load_from_path<P: AsRef<Path>>(path: P) -> Result<Self, Box<dyn std::error::Error>> {
        let path = path.as_ref();
        if path.exists() {
            let content = std::fs::read_to_string(path)?;
            let entries: HashMap<String, KnowledgeEntry> = serde_json::from_str(&content)?;
            let store = GraphStore::new();
            {
                let mut entries_guard = store.entries.write();
                *entries_guard = entries;
            }
            store.rebuild_indexes();
            Ok(store)
        } else {
            Ok(GraphStore::new())
        }
    }

    pub fn save_to_path<P: AsRef<Path>>(&self, path: P) -> Result<(), Box<dyn std::error::Error>> {
        let entries = self.entries.read();
        let content = serde_json::to_string_pretty(&*entries)?;
        std::fs::write(path, content)?;
        Ok(())
    }

    fn rebuild_indexes(&self) {
        let entries = self.entries.read();
        let mut subject_index = self.subject_index.write();
        let mut tag_index = self.tag_index.write();
        subject_index.clear();
        tag_index.clear();

        for (id, entry) in entries.iter() {
            subject_index
                .entry(entry.subject.clone())
                .or_insert_with(Vec::new)
                .push(id.clone());
            for tag in &entry.tags {
                tag_index
                    .entry(tag.clone())
                    .or_insert_with(Vec::new)
                    .push(id.clone());
            }
        }
    }

    pub fn upsert(&self, entry: KnowledgeEntry) -> Result<(), String> {
        let id = entry.id.clone();
        let subject = entry.subject.clone();
        let tags = entry.tags.clone();

        {
            let mut entries = self.entries.write();
            entries.insert(id.clone(), entry);
        }
        {
            let mut subject_index = self.subject_index.write();
            subject_index
                .entry(subject)
                .or_insert_with(Vec::new)
                .push(id.clone());
        }
        {
            let mut tag_index = self.tag_index.write();
            for tag in tags {
                tag_index
                    .entry(tag)
                    .or_insert_with(Vec::new)
                    .push(id.clone());
            }
        }
        Ok(())
    }

    pub fn get_by_id(&self, id: &str) -> Option<KnowledgeEntry> {
        let entries = self.entries.read();
        entries.get(id).cloned()
    }

    pub fn query(&self, options: &QueryOptions) -> Vec<KnowledgeEntry> {
        let entries = self.entries.read();
        let mut results = Vec::new();

        for entry in entries.values() {
            if let Some(tier) = &options.tier {
                if entry.tier != *tier {
                    continue;
                }
            }
            if let Some(min_cert) = options.min_certainty {
                if entry.certainty < min_cert {
                    continue;
                }
            }
            if let Some(subject) = &options.subject {
                if entry.subject != *subject {
                    continue;
                }
            }
            if let Some(attribute) = &options.attribute {
                if entry.attribute != *attribute {
                    continue;
                }
            }
            let mut keyword_match = options.keywords.is_empty();
            for kw in &options.keywords {
                if entry.description.contains(kw)
                    || entry.subject.contains(kw)
                    || entry.attribute.contains(kw)
                    || entry.value.contains(kw)
                {
                    keyword_match = true;
                    break;
                }
            }
            if !keyword_match {
                continue;
            }
            let mut tag_match = options.tags.is_empty();
            for tag in &options.tags {
                if entry.tags.contains(tag) {
                    tag_match = true;
                    break;
                }
            }
            if !tag_match {
                continue;
            }
            results.push(entry.clone());
            if results.len() >= options.limit {
                break;
            }
        }
        results
    }

    pub fn delete(&self, id: &str) -> bool {
        let mut entries = self.entries.write();
        if let Some(entry) = entries.remove(id) {
            let mut subject_index = self.subject_index.write();
            if let Some(list) = subject_index.get_mut(&entry.subject) {
                list.retain(|x| x != id);
            }
            let mut tag_index = self.tag_index.write();
            for tag in entry.tags {
                if let Some(list) = tag_index.get_mut(&tag) {
                    list.retain(|x| x != id);
                }
            }
            true
        } else {
            false
        }
    }

    pub fn count(&self) -> usize {
        self.entries.read().len()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_upsert_and_query() {
        let store = GraphStore::new();
        let entry = KnowledgeEntry {
            id: "test_001".to_string(),
            subject: "entity_alpha".to_string(),
            attribute: "property_beta".to_string(),
            value: "value_gamma".to_string(),
            description: "A generic description for testing purposes.".to_string(),
            tags: vec!["tag_one".to_string(), "tag_two".to_string()],
            certainty: 1.0,
            created_at: 1234567890,
            last_accessed: 1234567890,
            access_count: 0,
            tier: MemoryTier::Active,
        };
        store.upsert(entry).unwrap();

        let mut options = QueryOptions::default();
        options.keywords = vec!["entity_alpha".to_string()];
        options.limit = 10;
        let results = store.query(&options);
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].id, "test_001");
    }
}