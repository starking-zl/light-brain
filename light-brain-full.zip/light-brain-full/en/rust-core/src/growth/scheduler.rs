// Global growth scheduler
// Centrally manages growth requests from all modules, allocates resource quotas, and maintains growth logs.

use crate::cerebellum::{GraphStore, KnowledgeEntry};
use super::extractor::KnowledgeExtractor;
use super::conflict::ConflictDetector;
use crate::utils::time::current_timestamp;
use std::sync::{Arc, Mutex};

pub struct GrowthScheduler {
    graph_store: Arc<GraphStore>,
    extractor: KnowledgeExtractor,
    conflict_detector: ConflictDetector,
    log: Arc<Mutex<Vec<GrowthRecord>>>,
}

#[derive(Debug, Clone)]
pub struct GrowthRecord {
    pub timestamp: u64,
    pub action: GrowthAction,
    pub entry_id: String,
    pub reason: String,
}

#[derive(Debug, Clone)]
pub enum GrowthAction {
    Added,
    Rejected,
    Merged,
}

impl GrowthScheduler {
    pub fn new(graph_store: Arc<GraphStore>) -> Self {
        GrowthScheduler {
            graph_store,
            extractor: KnowledgeExtractor::new(),
            conflict_detector: ConflictDetector::new(),
            log: Arc::new(Mutex::new(Vec::new())),
        }
    }

    pub fn process_candidates(&self, text: &str) -> Vec<KnowledgeEntry> {
        let candidates = self.extractor.extract(text);
        let mut accepted = Vec::new();
        let now = current_timestamp();

        for mut candidate in candidates {
            let conflicts = self.conflict_detector.detect(&candidate, &self.graph_store);
            if conflicts.is_empty() {
                candidate.certainty = candidate.certainty.min(0.9);
                let _ = self.graph_store.upsert(candidate.clone());
                accepted.push(candidate.clone());
                self.log.lock().unwrap().push(GrowthRecord {
                    timestamp: now,
                    action: GrowthAction::Added,
                    entry_id: candidate.id.clone(),
                    reason: "no conflict".to_string(),
                });
            } else {
                self.log.lock().unwrap().push(GrowthRecord {
                    timestamp: now,
                    action: GrowthAction::Rejected,
                    entry_id: candidate.id,
                    reason: format!("conflicts: {:?}", conflicts),
                });
            }
        }
        accepted
    }

    pub fn get_log(&self) -> Vec<GrowthRecord> {
        self.log.lock().unwrap().clone()
    }

    pub fn rollback(&self, _record_id: &str) -> Result<(), String> {
        Err("rollback not implemented".to_string())
    }
}