// Growth module - Knowledge extraction, growth scheduling, and conflict detection
// Implements automatic knowledge extraction from dialogues, global growth scheduling, and conflict handling.

pub mod extractor;
pub mod scheduler;
pub mod conflict;

pub use extractor::KnowledgeExtractor;
pub use scheduler::GrowthScheduler;
pub use conflict::ConflictDetector;