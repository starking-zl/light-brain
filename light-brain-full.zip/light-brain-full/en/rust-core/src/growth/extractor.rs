// Knowledge extractor
// Identifies new entities, attributes, and relationships from dialogue text, generating candidate knowledge entries.

use crate::cerebellum::KnowledgeEntry;
use crate::utils::time::current_timestamp;
use regex::Regex;

pub struct KnowledgeExtractor {
    patterns: Vec<Regex>,
}

impl KnowledgeExtractor {
    pub fn new() -> Self {
        let patterns = vec![
            Regex::new(r"(\S+) is a kind of (\S+)").unwrap(),
            Regex::new(r"(\S+)'s (\S+) is (\S+)").unwrap(),
            Regex::new(r"(\S+) is used for (\S+)").unwrap(),
        ];
        KnowledgeExtractor { patterns }
    }

    pub fn extract(&self, text: &str) -> Vec<KnowledgeEntry> {
        let mut candidates = Vec::new();
        for pattern in &self.patterns {
            for caps in pattern.captures_iter(text) {
                if caps.len() >= 3 {
                    let subject = caps[1].to_string();
                    let attribute = caps[2].to_string();
                    let value = if caps.len() >= 4 {
                        caps[3].to_string()
                    } else {
                        attribute.clone()
                    };
                    let description = format!("{}'s {} is {}", subject, attribute, value);
                    
                    let id = format!("candidate_{:x}", md5::compute(&description));
                    
                    let entry = KnowledgeEntry {
                        id,
                        subject,
                        attribute,
                        value,
                        description,
                        tags: vec!["extracted".to_string()],
                        certainty: 0.6,
                        created_at: current_timestamp(),
                        last_accessed: 0,
                        access_count: 0,
                        tier: crate::cerebellum::MemoryTier::Active,
                    };
                    candidates.push(entry);
                }
            }
        }
        candidates
    }
}

impl Default for KnowledgeExtractor {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_extract_pattern() {
        let extractor = KnowledgeExtractor::new();
        let text = "alpha is a kind of beta, alpha's gamma is delta, alpha is used for epsilon";
        let candidates = extractor.extract(text);
        assert!(!candidates.is_empty());
    }
}