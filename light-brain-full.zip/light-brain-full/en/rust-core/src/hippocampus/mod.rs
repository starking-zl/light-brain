// Hippocampus module - Episodic memory and consolidation
// Responsible for recording conversational events, historical retrieval, and timed consolidation into Cerebellum.

pub mod event_store;
pub mod retrieval;
pub mod consolidation;

pub use event_store::{EventStore, EpisodicEvent};
pub use retrieval::RetrievalEngine;
pub use consolidation::ConsolidationEngine;