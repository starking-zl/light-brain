// Hippocampus retrieval engine
// Supports keyword search and time-range filtering, with ranking weighted by recency.

use super::event_store::{EpisodicEvent, EventStore};
use std::collections::HashSet;

pub struct RetrievalEngine {
    store: EventStore,
}

impl RetrievalEngine {
    pub fn new(store: EventStore) -> Self {
        RetrievalEngine { store }
    }

    pub fn search(
        &self,
        keywords: &[String],
        time_range: Option<(u64, u64)>,
        limit: usize,
    ) -> Vec<EpisodicEvent> {
        let candidates = if let Some((since, until)) = time_range {
            self.store.query_by_time_range(Some(since), Some(until), 1000).unwrap_or_default()
        } else {
            self.store.list_all(1000).unwrap_or_default()
        };

        let mut scored: Vec<(EpisodicEvent, f32)> = candidates
            .into_iter()
            .filter_map(|event| {
                let text = format!("{} {}", event.user_input, event.reply);
                let keyword_score = if keywords.is_empty() {
                    0.5
                } else {
                    let mut score = 0.0;
                    for kw in keywords {
                        if text.contains(kw) {
                            score += 1.0;
                        }
                    }
                    score / keywords.len() as f32
                };
                if keyword_score > 0.0 || keywords.is_empty() {
                    let now = crate::utils::time::current_timestamp();
                    let days_ago = (now - event.timestamp) as f32 / 86400.0;
                    let time_weight = 1.0 / (1.0 + days_ago * 0.1);
                    let final_score = keyword_score * 0.7 + time_weight * 0.3;
                    Some((event, final_score))
                } else {
                    None
                }
            })
            .collect();

        scored.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap());
        let mut results = Vec::new();
        let mut seen = HashSet::new();
        for (event, _) in scored {
            if results.len() >= limit {
                break;
            }
            if seen.insert(event.id.clone()) {
                let _ = self.store.increment_access(&event.id);
                results.push(event);
            }
        }
        results
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::hippocampus::event_store::{EpisodicEvent, EventStore};
    use tempfile::NamedTempFile;

    #[test]
    fn test_search_with_time() {
        let tmp = NamedTempFile::new().unwrap();
        let store = EventStore::new(tmp.path()).unwrap();
        let now = 2000;
        let event1 = EpisodicEvent {
            id: "e1".to_string(),
            timestamp: now - 86400 * 10,
            user_input: "test alpha".to_string(),
            intent: "AskFact".to_string(),
            polarity: "Neutral".to_string(),
            domain: "InDomain".to_string(),
            fact_id: None,
            reply: "reply".to_string(),
            access_count: 0,
        };
        let event2 = EpisodicEvent {
            id: "e2".to_string(),
            timestamp: now - 3600,
            user_input: "test beta".to_string(),
            intent: "AskFact".to_string(),
            polarity: "Neutral".to_string(),
            domain: "InDomain".to_string(),
            fact_id: None,
            reply: "reply".to_string(),
            access_count: 0,
        };
        store.insert(event1).unwrap();
        store.insert(event2).unwrap();

        let engine = RetrievalEngine::new(store);
        let results = engine.search(&["test".to_string()], None, 10);
        assert_eq!(results[0].id, "e2");
    }
}