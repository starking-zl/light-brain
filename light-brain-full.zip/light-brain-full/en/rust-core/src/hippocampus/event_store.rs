// Hippocampus event store
// Uses SQLite to persist conversational events, supports time-range queries.

use rusqlite::{Connection, params, Result as SqliteResult};
use serde::{Deserialize, Serialize};
use std::path::Path;
use std::sync::{Arc, Mutex};
use crate::utils::time::current_timestamp;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EpisodicEvent {
    pub id: String,
    pub timestamp: u64,
    pub user_input: String,
    pub intent: String,
    pub polarity: String,
    pub domain: String,
    pub fact_id: Option<String>,
    pub reply: String,
    pub access_count: u32,
}

pub struct EventStore {
    conn: Arc<Mutex<Connection>>,
}

impl EventStore {
    pub fn new<P: AsRef<Path>>(db_path: P) -> SqliteResult<Self> {
        let conn = Connection::open(db_path)?;
        conn.execute(
            "CREATE TABLE IF NOT EXISTS events (
                id TEXT PRIMARY KEY,
                timestamp INTEGER NOT NULL,
                user_input TEXT NOT NULL,
                intent TEXT NOT NULL,
                polarity TEXT NOT NULL,
                domain TEXT NOT NULL,
                fact_id TEXT,
                reply TEXT NOT NULL,
                access_count INTEGER DEFAULT 0
            )",
            [],
        )?;
        conn.execute("CREATE INDEX IF NOT EXISTS idx_timestamp ON events (timestamp)", [])?;
        Ok(EventStore {
            conn: Arc::new(Mutex::new(conn)),
        })
    }

    pub fn insert(&self, mut event: EpisodicEvent) -> SqliteResult<()> {
        if event.timestamp == 0 {
            event.timestamp = current_timestamp();
        }
        let conn = self.conn.lock().unwrap();
        conn.execute(
            "INSERT INTO events 
            (id, timestamp, user_input, intent, polarity, domain, fact_id, reply, access_count)
            VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9)",
            params![
                event.id,
                event.timestamp,
                event.user_input,
                event.intent,
                event.polarity,
                event.domain,
                event.fact_id,
                event.reply,
                event.access_count,
            ],
        )?;
        Ok(())
    }

    pub fn get_by_id(&self, id: &str) -> SqliteResult<Option<EpisodicEvent>> {
        let conn = self.conn.lock().unwrap();
        let mut stmt = conn.prepare(
            "SELECT id, timestamp, user_input, intent, polarity, domain, fact_id, reply, access_count
            FROM events WHERE id = ?",
        )?;
        let mut rows = stmt.query(params![id])?;
        if let Some(row) = rows.next()? {
            Ok(Some(EpisodicEvent {
                id: row.get(0)?,
                timestamp: row.get(1)?,
                user_input: row.get(2)?,
                intent: row.get(3)?,
                polarity: row.get(4)?,
                domain: row.get(5)?,
                fact_id: row.get(6)?,
                reply: row.get(7)?,
                access_count: row.get(8)?,
            }))
        } else {
            Ok(None)
        }
    }

    pub fn increment_access(&self, id: &str) -> SqliteResult<()> {
        let conn = self.conn.lock().unwrap();
        conn.execute(
            "UPDATE events SET access_count = access_count + 1 WHERE id = ?",
            params![id],
        )?;
        Ok(())
    }

    pub fn query_by_time_range(
        &self,
        since: Option<u64>,
        until: Option<u64>,
        limit: usize,
    ) -> SqliteResult<Vec<EpisodicEvent>> {
        let conn = self.conn.lock().unwrap();
        let mut sql = "SELECT id, timestamp, user_input, intent, polarity, domain, fact_id, reply, access_count
                      FROM events WHERE 1=1".to_string();
        let mut params_vec: Vec<Box<dyn rusqlite::ToSql>> = Vec::new();

        if let Some(s) = since {
            sql.push_str(" AND timestamp >= ?");
            params_vec.push(Box::new(s));
        }
        if let Some(u) = until {
            sql.push_str(" AND timestamp <= ?");
            params_vec.push(Box::new(u));
        }
        sql.push_str(" ORDER BY timestamp DESC LIMIT ?");
        params_vec.push(Box::new(limit as i64));

        let mut stmt = conn.prepare(&sql)?;
        let rows = stmt.query_map(rusqlite::params_from_iter(params_vec.iter().map(|p| p.as_ref())), |row| {
            Ok(EpisodicEvent {
                id: row.get(0)?,
                timestamp: row.get(1)?,
                user_input: row.get(2)?,
                intent: row.get(3)?,
                polarity: row.get(4)?,
                domain: row.get(5)?,
                fact_id: row.get(6)?,
                reply: row.get(7)?,
                access_count: row.get(8)?,
            })
        })?;

        let mut events = Vec::new();
        for event in rows {
            events.push(event?);
        }
        Ok(events)
    }

    pub fn list_all(&self, limit: usize) -> SqliteResult<Vec<EpisodicEvent>> {
        let conn = self.conn.lock().unwrap();
        let mut stmt = conn.prepare(
            "SELECT id, timestamp, user_input, intent, polarity, domain, fact_id, reply, access_count
            FROM events ORDER BY timestamp DESC LIMIT ?",
        )?;
        let rows = stmt.query_map(params![limit as i64], |row| {
            Ok(EpisodicEvent {
                id: row.get(0)?,
                timestamp: row.get(1)?,
                user_input: row.get(2)?,
                intent: row.get(3)?,
                polarity: row.get(4)?,
                domain: row.get(5)?,
                fact_id: row.get(6)?,
                reply: row.get(7)?,
                access_count: row.get(8)?,
            })
        })?;
        let mut events = Vec::new();
        for event in rows {
            events.push(event?);
        }
        Ok(events)
    }

    pub fn delete(&self, id: &str) -> SqliteResult<()> {
        let conn = self.conn.lock().unwrap();
        conn.execute("DELETE FROM events WHERE id = ?", params![id])?;
        Ok(())
    }

    pub fn count(&self) -> SqliteResult<usize> {
        let conn = self.conn.lock().unwrap();
        let mut stmt = conn.prepare("SELECT COUNT(*) FROM events")?;
        let count: i64 = stmt.query_row([], |row| row.get(0))?;
        Ok(count as usize)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::NamedTempFile;

    #[test]
    fn test_time_range_query() {
        let tmp = NamedTempFile::new().unwrap();
        let store = EventStore::new(tmp.path()).unwrap();

        let event1 = EpisodicEvent {
            id: "old".to_string(),
            timestamp: 1000,
            user_input: "old".to_string(),
            intent: "AskFact".to_string(),
            polarity: "Neutral".to_string(),
            domain: "InDomain".to_string(),
            fact_id: None,
            reply: "old reply".to_string(),
            access_count: 0,
        };
        let event2 = EpisodicEvent {
            id: "new".to_string(),
            timestamp: 2000,
            user_input: "new".to_string(),
            intent: "AskFact".to_string(),
            polarity: "Neutral".to_string(),
            domain: "InDomain".to_string(),
            fact_id: None,
            reply: "new reply".to_string(),
            access_count: 0,
        };
        store.insert(event1).unwrap();
        store.insert(event2).unwrap();

        let recent = store.query_by_time_range(Some(1500), None, 10).unwrap();
        assert_eq!(recent.len(), 1);
        assert_eq!(recent[0].id, "new");
    }
}