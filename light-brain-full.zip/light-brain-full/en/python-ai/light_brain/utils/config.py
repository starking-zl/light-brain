import json
import os
from typing import Dict, Any

class ConfigManager:
    def __init__(self, config_root: str):
        self.config_root = config_root

    def load_json(self, relative_path: str) -> Dict[str, Any]:
        full_path = os.path.join(self.config_root, relative_path)
        with open(full_path, 'r', encoding='utf-8') as f:
            return json.load(f)

    def load_amygdala_rules(self) -> Dict:
        return self.load_json("en/amygdala_rules.json")

    def load_prefrontal_decisions(self) -> Dict:
        return self.load_json("en/prefrontal_decisions.json")

    def load_broca_templates(self) -> Dict:
        return self.load_json("en/broca_templates.json")

    def load_creative_profiles(self) -> Dict:
        return self.load_json("en/creative_profiles.json")

    def load_thalamus_prototypes(self) -> Dict:
        return self.load_json("en/thalamus_prototypes.json")

def load_config(config_root: str, name: str) -> Dict:
    mgr = ConfigManager(config_root)
    return mgr.load_json(name)