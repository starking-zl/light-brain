import importlib
from typing import Optional

_RUST_BINDING = None

def get_rust_binding():
    global _RUST_BINDING
    if _RUST_BINDING is None:
        try:
            _RUST_BINDING = importlib.import_module("light_brain_binding")
        except ImportError:
            _RUST_BINDING = None
    return _RUST_BINDING