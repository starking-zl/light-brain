import json
import numpy as np
from typing import Dict

try:
    from light_brain_binding import PrototypeStore as RustPrototypeStore
except ImportError:
    RustPrototypeStore = None

class GroundingLayer:
    def __init__(self, prototype_store):
        self.store = prototype_store

    def classify_intent(self, vector: np.ndarray) -> Dict[str, float]:
        if RustPrototypeStore:
            results = rust_grounding(vector, self.store, "intent")
            return {r.label: r.probability for r in results}
        else:
            return self._python_classify(vector, "intent")

    def classify_polarity(self, vector: np.ndarray) -> Dict[str, float]:
        if RustPrototypeStore:
            results = rust_grounding(vector, self.store, "polarity")
            return {r.label: r.probability for r in results}
        else:
            return self._python_classify(vector, "polarity")

    def classify_domain(self, vector: np.ndarray) -> Dict[str, float]:
        if RustPrototypeStore:
            results = rust_grounding(vector, self.store, "domain")
            return {r.label: r.probability for r in results}
        else:
            return self._python_classify(vector, "domain")

    def _python_classify(self, vector, category):
        prototypes = self.store.get(category, [])
        sims = [self._cosine(vector, p["vector"]) for p in prototypes]
        probs = self._softmax(sims)
        return {p["label"]: prob for p, prob in zip(prototypes, probs)}

    @staticmethod
    def _cosine(a, b):
        return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-8)

    @staticmethod
    def _softmax(x):
        e_x = np.exp(x - np.max(x))
        return e_x / e_x.sum()