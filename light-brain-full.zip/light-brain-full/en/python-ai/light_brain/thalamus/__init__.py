from .encoder import IntentEncoder
from .grounding import GroundingLayer

class Thalamus:
    def __init__(self, encoder_model_path: str, prototype_store):
        self.encoder = IntentEncoder(encoder_model_path)
        self.grounding = GroundingLayer(prototype_store)

    def perceive(self, text: str) -> dict:
        vector = self.encoder.encode(text)
        intent_dist = self.grounding.classify_intent(vector)
        polarity_dist = self.grounding.classify_polarity(vector)
        domain_dist = self.grounding.classify_domain(vector)
        keywords = self._extract_keywords(text)
        return {
            "intent": max(intent_dist, key=intent_dist.get),
            "polarity": max(polarity_dist, key=polarity_dist.get),
            "domain": max(domain_dist, key=domain_dist.get),
            "keywords": keywords,
            "certainty": max(intent_dist.values())
        }

    def _extract_keywords(self, text: str) -> list:
        import jieba
        words = jieba.lcut(text)
        return list(set(words))[:5]