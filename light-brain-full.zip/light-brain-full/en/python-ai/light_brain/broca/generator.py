import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

class SLMGenerator:
    def __init__(self, model_path: str):
        self.tokenizer = AutoTokenizer.from_pretrained(model_path)
        self.model = AutoModelForCausalLM.from_pretrained(model_path)
        self.model.eval()

    def generate(self, skeleton: dict, style: str, num_candidates: int = 3) -> list:
        prompt = self._skeleton_to_prompt(skeleton, style)
        inputs = self.tokenizer(prompt, return_tensors="pt")
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=64,
                do_sample=True,
                temperature=0.8,
                num_return_sequences=num_candidates,
            )
        candidates = [self.tokenizer.decode(out, skip_special_tokens=True) for out in outputs]
        return candidates

    def _skeleton_to_prompt(self, skeleton, style):
        slots = skeleton["slots"]
        if slots["subject"]:
            return f"Explain {slots['subject']} {slots['attribute']}: {slots['description']}"
        return "Please respond appropriately."