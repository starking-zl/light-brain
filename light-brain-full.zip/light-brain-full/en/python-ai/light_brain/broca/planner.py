class SemanticPlanner:
    def plan(self, decision_package: dict) -> dict:
        intent = decision_package["intent"]
        fact = decision_package.get("fact")
        style = decision_package.get("style", "normal")
        skeleton = {
            "intent": intent,
            "slots": {
                "subject": fact.get("subject") if fact else None,
                "attribute": fact.get("attribute") if fact else None,
                "value": fact.get("value") if fact else None,
                "description": fact.get("description") if fact else None,
            },
            "style": style,
            "fallback": decision_package.get("fallback_action")
        }
        return skeleton