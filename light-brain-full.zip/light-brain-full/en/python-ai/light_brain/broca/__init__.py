from .planner import SemanticPlanner
from .generator import SLMGenerator
from .constraints import ConstraintGuider
import json

class Broca:
    def __init__(self, slm_model_path: str, templates_path: str):
        self.planner = SemanticPlanner()
        self.generator = SLMGenerator(slm_model_path)
        self.constraints = ConstraintGuider()
        with open(templates_path, 'r', encoding='utf-8') as f:
            self.templates = json.load(f)

    def generate(self, decision_package: dict) -> str:
        skeleton = self.planner.plan(decision_package)
        candidates = self.generator.generate(skeleton, decision_package.get("style", "normal"))
        best = self.constraints.guide(candidates, decision_package)
        if best is None:
            best = self._fallback_template(decision_package)
        return best

    def _fallback_template(self, decision_package):
        return "I'm not sure how to respond to that."