class ConstraintGuider:
    def guide(self, candidates: list, decision_package: dict) -> str:
        fact = decision_package.get("fact")
        if not fact:
            return candidates[0] if candidates else None
        subject = fact.get("subject", "")
        for cand in candidates:
            if subject in cand:
                return cand
        return candidates[0] if candidates else None