// 光脑方案 Rust 核心库
// 提供符号推理、知识存储、生长调度、记忆管理等核心功能

pub mod thalamus;
pub mod prefrontal;
pub mod amygdala;
pub mod cerebellum;
pub mod hippocampus;
pub mod growth;
pub mod memory;
pub mod utils;

// 重新导出常用类型，方便外部使用
pub use cerebellum::{GraphStore, KnowledgeEntry, MemoryTier, QueryOptions, DecayConfig};
pub use amygdala::{Amygdala, Style, Intent, Polarity};
pub use prefrontal::{DecisionTable, CreativeController, CreativeMode, WorkingMemory, FusionEngine};
pub use hippocampus::{EventStore, EpisodicEvent, RetrievalEngine, ConsolidationEngine};
pub use growth::{KnowledgeExtractor, GrowthScheduler, ConflictDetector};
pub use memory::{TierManager, GarbageCollector};
pub use thalamus::{PrototypeStore, grounding_layer};
pub use utils::time::{current_timestamp, days_between};