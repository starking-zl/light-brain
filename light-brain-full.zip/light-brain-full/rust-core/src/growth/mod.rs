// 生长机制模块 - 知识抽取、生长调度与冲突检测
// 实现从对话中自动抽取知识、全局生长调度、新旧知识冲突处理

pub mod extractor;
pub mod scheduler;
pub mod conflict;

pub use extractor::KnowledgeExtractor;
pub use scheduler::GrowthScheduler;
pub use conflict::ConflictDetector;