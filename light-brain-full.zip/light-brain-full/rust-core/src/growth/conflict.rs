// 冲突检测器
// 判断候选知识与小脑现有知识是否存在矛盾

use crate::cerebellum::{GraphStore, KnowledgeEntry, QueryOptions};

pub struct ConflictDetector;

impl ConflictDetector {
    pub fn new() -> Self {
        ConflictDetector
    }

    // 检测候选条目与现有知识的冲突
    // 返回冲突的现有条目ID列表
    pub fn detect(&self, candidate: &KnowledgeEntry, store: &GraphStore) -> Vec<String> {
        let mut conflicts = Vec::new();
        
        // 查询主体相同、属性相同的现有条目
        let mut options = QueryOptions::default();
        options.subject = Some(candidate.subject.clone());
        options.attribute = Some(candidate.attribute.clone());
        options.limit = 10;
        
        let existing = store.query(&options);
        for entry in existing {
            // 值不同即视为潜在冲突
            if entry.value != candidate.value {
                // 若现有条目确定性较高，标记冲突
                if entry.certainty > candidate.certainty {
                    conflicts.push(entry.id);
                }
            }
        }
        conflicts
    }
}

impl Default for ConflictDetector {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cerebellum::{GraphStore, KnowledgeEntry, MemoryTier};

    #[test]
    fn test_conflict_detection() {
        let store = GraphStore::new();
        let existing = KnowledgeEntry {
            id: "exist".to_string(),
            subject: "alpha".to_string(),
            attribute: "color".to_string(),
            value: "red".to_string(),
            description: "alpha is red".to_string(),
            tags: vec![],
            certainty: 0.9,
            created_at: 1000,
            last_accessed: 1000,
            access_count: 0,
            tier: MemoryTier::Active,
        };
        store.upsert(existing).unwrap();

        let candidate = KnowledgeEntry {
            id: "cand".to_string(),
            subject: "alpha".to_string(),
            attribute: "color".to_string(),
            value: "blue".to_string(),
            description: "alpha is blue".to_string(),
            tags: vec![],
            certainty: 0.6,
            created_at: 2000,
            last_accessed: 0,
            access_count: 0,
            tier: MemoryTier::Active,
        };

        let detector = ConflictDetector::new();
        let conflicts = detector.detect(&candidate, &store);
        assert_eq!(conflicts, vec!["exist"]);
    }
}