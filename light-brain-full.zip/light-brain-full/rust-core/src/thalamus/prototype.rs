// 原型向量存储
// 管理每个符号标签对应的原型向量

use std::collections::HashMap;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PrototypeEntry {
    pub label: String,          // 符号标签（如 "AskFact", "Positive"）
    pub vector: Vec<f32>,       // 原型向量
    pub certainty_threshold: f32, // 该标签的置信度阈值
}

pub struct PrototypeStore {
    prototypes: HashMap<String, PrototypeEntry>,
    default_threshold: f32,
}

impl PrototypeStore {
    pub fn new() -> Self {
        PrototypeStore {
            prototypes: HashMap::new(),
            default_threshold: 0.5,
        }
    }

    // 添加或更新原型
    pub fn upsert(&mut self, label: String, vector: Vec<f32>) {
        let entry = PrototypeEntry {
            label: label.clone(),
            vector,
            certainty_threshold: self.default_threshold,
        };
        self.prototypes.insert(label, entry);
    }

    // 获取所有原型
    pub fn get_all(&self) -> Vec<PrototypeEntry> {
        self.prototypes.values().cloned().collect()
    }

    // 根据标签获取原型向量
    pub fn get(&self, label: &str) -> Option<Vec<f32>> {
        self.prototypes.get(label).map(|e| e.vector.clone())
    }

    // 从 JSON 加载
    pub fn load_from_json(&mut self, json_str: &str) -> Result<(), serde_json::Error> {
        let entries: Vec<PrototypeEntry> = serde_json::from_str(json_str)?;
        for entry in entries {
            self.prototypes.insert(entry.label.clone(), entry);
        }
        Ok(())
    }

    // 导出为 JSON
    pub fn to_json(&self) -> Result<String, serde_json::Error> {
        let entries: Vec<_> = self.prototypes.values().collect();
        serde_json::to_string(&entries)
    }
}

impl Default for PrototypeStore {
    fn default() -> Self {
        Self::new()
    }
}