// 丘脑模块 - 符号接地层（Rust 核心部分）
// 提供原型向量的存储、相似度计算接口，供 Python 绑定调用

pub mod prototype;
pub mod grounding;

pub use prototype::PrototypeStore;
pub use grounding::grounding_layer;