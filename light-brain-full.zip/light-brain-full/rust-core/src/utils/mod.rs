// 工具模块 - 通用函数与辅助类型
// 提供跨模块共享的衰减计算、时间戳、指标记录等功能

pub mod decay;
pub mod metrics;
pub mod time;

pub use decay::{compute_decay, DecayParams};
pub use metrics::{MetricsCollector, MetricEvent};
pub use time::current_timestamp;
pub mod time_provider;
