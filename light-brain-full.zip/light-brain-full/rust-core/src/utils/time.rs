// 时间工具模块
// 提供统一的时间戳获取、时间差计算等基础功能

use std::time::{SystemTime, UNIX_EPOCH};

/// 获取当前 Unix 时间戳（秒）
pub fn current_timestamp() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

/// 获取当前 Unix 时间戳（毫秒）
pub fn current_timestamp_millis() -> u128 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis()
}

/// 计算两个时间戳之间的天数差值（绝对值）
pub fn days_between(t1: u64, t2: u64) -> f32 {
    (t1 as i64 - t2 as i64).abs() as f32 / 86400.0
}

/// 将时间戳转换为可读字符串（UTC）
pub fn timestamp_to_string(ts: u64) -> String {
    // 简化实现，仅用于调试
    format!("timestamp_{}", ts)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_current_timestamp() {
        let ts = current_timestamp();
        assert!(ts > 0);
    }

    #[test]
    fn test_days_between() {
        let t1 = 86400;
        let t2 = 0;
        assert!((days_between(t1, t2) - 1.0).abs() < 0.001);
    }
}