// 通用衰减公式
// 基于时间和访问频率计算权重衰减因子

#[derive(Debug, Clone, Copy)]
pub struct DecayParams {
    pub lambda: f32,   // 全局衰减系数
    pub epsilon: f32,  // 防零小量
}

impl Default for DecayParams {
    fn default() -> Self {
        DecayParams {
            lambda: 0.01,
            epsilon: 0.001,
        }
    }
}

// 计算衰减因子
// delta_t: 距离上次访问的天数
// frequency: 平均每日访问次数
// certainty: 条目本身的确定性
pub fn compute_decay(
    delta_t: f32,
    frequency: f32,
    certainty: f32,
    params: DecayParams,
) -> f32 {
    let effective_freq = frequency.max(params.epsilon);
    let decay_factor = (-params.lambda * delta_t / effective_freq).exp();
    certainty * decay_factor
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_compute_decay() {
        let params = DecayParams::default();
        // 最近访问，高频率，高确定性 → 高权重
        let weight1 = compute_decay(0.0, 10.0, 1.0, params);
        assert!(weight1 > 0.9);
        // 很久未访问，低频率，低确定性 → 低权重
        let weight2 = compute_decay(100.0, 0.1, 0.5, params);
        assert!(weight2 < 0.1);
    }
}