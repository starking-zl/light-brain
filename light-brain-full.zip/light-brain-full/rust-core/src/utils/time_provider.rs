// 时间提供者 trait 与全局单例
// 支持可插拔的外部日历接口，默认使用系统时间

use std::sync::OnceLock;
use std::time::{SystemTime, UNIX_EPOCH};

// 时间提供者 trait
pub trait TimeProvider: Send + Sync {
    // 获取当前 Unix 时间戳（秒）
    fn current_timestamp(&self) -> u64;
}

// 默认实现：系统时钟
pub struct SystemTimeProvider;

impl TimeProvider for SystemTimeProvider {
    fn current_timestamp(&self) -> u64 {
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs()
    }
}

// 全局单例
static TIME_PROVIDER: OnceLock<Box<dyn TimeProvider>> = OnceLock::new();

// 初始化（主程序启动时调用一次，可选）
pub fn init_time_provider(provider: Box<dyn TimeProvider>) {
    let _ = TIME_PROVIDER.set(provider);
}

// 获取当前时间戳（所有模块统一调用此函数）
pub fn current_timestamp() -> u64 {
    TIME_PROVIDER
        .get()
        .map(|p| p.current_timestamp())
        .unwrap_or_else(|| SystemTimeProvider.current_timestamp())
}