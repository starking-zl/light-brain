// 小脑模块 - 知识图谱存储封装
// 本文件提供对 OverGraph 图数据库的封装，实现知识条目的增删改查
// 字段名使用英文（Rust 标识符必须为 ASCII）

use std::collections::HashMap;
use std::path::Path;
use std::sync::Arc;
use parking_lot::RwLock;
use serde::{Deserialize, Serialize};

// 知识条目结构体
// 对应小脑知识库中的单条知识
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct KnowledgeEntry {
    pub id: String,           // 唯一标识
    pub subject: String,      // 主体
    pub attribute: String,    // 属性
    pub value: String,        // 值
    pub description: String,  // 自然语言描述
    pub tags: Vec<String>,    // 标签数组
    pub certainty: f32,       // 确定性 (0.0 ~ 1.0)
    pub created_at: u64,      // 创建时间戳
    pub last_accessed: u64,   // 最后访问时间戳
    pub access_count: u64,    // 访问次数
    pub tier: MemoryTier,     // 记忆层级 (活跃/沉寂/垃圾)
}

// 记忆层级枚举
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum MemoryTier {
    Active,    // 活跃库
    Dormant,   // 沉寂库
    Garbage,   // 垃圾库
}

impl Default for MemoryTier {
    fn default() -> Self {
        MemoryTier::Active
    }
}

// 查询条件
#[derive(Debug, Clone, Default)]
pub struct QueryOptions {
    pub subject: Option<String>,
    pub attribute: Option<String>,
    pub keywords: Vec<String>,
    pub tags: Vec<String>,
    pub tier: Option<MemoryTier>,
    pub min_certainty: Option<f32>,
    pub limit: usize,
}

// 图存储封装
pub struct GraphStore {
    // 内部使用 OverGraph 的 Rust 客户端
    // 初期为简化实现，使用内存中的 HashMap 模拟
    // 后期替换为真实的 OverGraph 连接
    entries: Arc<RwLock<HashMap<String, KnowledgeEntry>>>,
    // 索引：主体 -> 条目 ID 列表
    subject_index: Arc<RwLock<HashMap<String, Vec<String>>>>,
    // 索引：标签 -> 条目 ID 列表
    tag_index: Arc<RwLock<HashMap<String, Vec<String>>>>,
}

impl GraphStore {
    // 创建新的图存储实例
    pub fn new() -> Self {
        GraphStore {
            entries: Arc::new(RwLock::new(HashMap::new())),
            subject_index: Arc::new(RwLock::new(HashMap::new())),
            tag_index: Arc::new(RwLock::new(HashMap::new())),
        }
    }

    // 从持久化文件加载
    pub fn load_from_path<P: AsRef<Path>>(path: P) -> Result<Self, Box<dyn std::error::Error>> {
        // 初期实现：若文件存在则读取 JSON，否则返回空实例
        let path = path.as_ref();
        if path.exists() {
            let content = std::fs::read_to_string(path)?;
            let entries: HashMap<String, KnowledgeEntry> = serde_json::from_str(&content)?;
            let store = GraphStore::new();
            {
                let mut entries_guard = store.entries.write();
                *entries_guard = entries;
            }
            store.rebuild_indexes();
            Ok(store)
        } else {
            Ok(GraphStore::new())
        }
    }

    // 持久化到文件
    pub fn save_to_path<P: AsRef<Path>>(&self, path: P) -> Result<(), Box<dyn std::error::Error>> {
        let entries = self.entries.read();
        let content = serde_json::to_string_pretty(&*entries)?;
        std::fs::write(path, content)?;
        Ok(())
    }

    // 重建索引
    fn rebuild_indexes(&self) {
        let entries = self.entries.read();
        let mut subject_index = self.subject_index.write();
        let mut tag_index = self.tag_index.write();
        subject_index.clear();
        tag_index.clear();

        for (id, entry) in entries.iter() {
            // 主体索引
            subject_index
                .entry(entry.subject.clone())
                .or_insert_with(Vec::new)
                .push(id.clone());
            // 标签索引
            for tag in &entry.tags {
                tag_index
                    .entry(tag.clone())
                    .or_insert_with(Vec::new)
                    .push(id.clone());
            }
        }
    }

    // 插入或更新知识条目
    pub fn upsert(&self, entry: KnowledgeEntry) -> Result<(), String> {
        let id = entry.id.clone();
        let subject = entry.subject.clone();
        let tags = entry.tags.clone();

        // 更新条目存储
        {
            let mut entries = self.entries.write();
            entries.insert(id.clone(), entry);
        }

        // 更新索引
        {
            let mut subject_index = self.subject_index.write();
            subject_index
                .entry(subject)
                .or_insert_with(Vec::new)
                .push(id.clone());
        }
        {
            let mut tag_index = self.tag_index.write();
            for tag in tags {
                tag_index
                    .entry(tag)
                    .or_insert_with(Vec::new)
                    .push(id.clone());
            }
        }

        Ok(())
    }

    // 根据 ID 获取条目
    pub fn get_by_id(&self, id: &str) -> Option<KnowledgeEntry> {
        let entries = self.entries.read();
        entries.get(id).cloned()
    }

    // 根据查询条件检索条目
    pub fn query(&self, options: &QueryOptions) -> Vec<KnowledgeEntry> {
        let entries = self.entries.read();
        let mut results = Vec::new();

        for entry in entries.values() {
            // 过滤记忆层级
            if let Some(tier) = &options.tier {
                if entry.tier != *tier {
                    continue;
                }
            }

            // 过滤确定性
            if let Some(min_cert) = options.min_certainty {
                if entry.certainty < min_cert {
                    continue;
                }
            }

            // 精确匹配主体
            if let Some(subject) = &options.subject {
                if entry.subject != *subject {
                    continue;
                }
            }

            // 精确匹配属性
            if let Some(attribute) = &options.attribute {
                if entry.attribute != *attribute {
                    continue;
                }
            }

            // 关键词匹配（在描述、主体、属性、值中搜索）
            let mut keyword_match = options.keywords.is_empty();
            for kw in &options.keywords {
                if entry.description.contains(kw)
                    || entry.subject.contains(kw)
                    || entry.attribute.contains(kw)
                    || entry.value.contains(kw)
                {
                    keyword_match = true;
                    break;
                }
            }
            if !keyword_match {
                continue;
            }

            // 标签匹配（至少包含一个指定标签）
            let mut tag_match = options.tags.is_empty();
            for tag in &options.tags {
                if entry.tags.contains(tag) {
                    tag_match = true;
                    break;
                }
            }
            if !tag_match {
                continue;
            }

            results.push(entry.clone());

            if results.len() >= options.limit {
                break;
            }
        }

        // 更新访问计数和时间（实际应用中可异步处理）
        results
    }

    // 删除条目
    pub fn delete(&self, id: &str) -> bool {
        let mut entries = self.entries.write();
        if let Some(entry) = entries.remove(id) {
            let mut subject_index = self.subject_index.write();
            if let Some(list) = subject_index.get_mut(&entry.subject) {
                list.retain(|x| x != id);
            }
            let mut tag_index = self.tag_index.write();
            for tag in entry.tags {
                if let Some(list) = tag_index.get_mut(&tag) {
                    list.retain(|x| x != id);
                }
            }
            true
        } else {
            false
        }
    }

    // 获取所有条目数量
    pub fn count(&self) -> usize {
        self.entries.read().len()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_upsert_and_query() {
        let store = GraphStore::new();
        let entry = KnowledgeEntry {
            id: "test_001".to_string(),
            subject: "entity_alpha".to_string(),
            attribute: "property_beta".to_string(),
            value: "value_gamma".to_string(),
            description: "A generic description for testing purposes.".to_string(),
            tags: vec!["tag_one".to_string(), "tag_two".to_string()],
            certainty: 1.0,
            created_at: 1234567890,
            last_accessed: 1234567890,
            access_count: 0,
            tier: MemoryTier::Active,
        };
        store.upsert(entry).unwrap();

        let mut options = QueryOptions::default();
        options.keywords = vec!["entity_alpha".to_string()];
        options.limit = 10;
        let results = store.query(&options);
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].id, "test_001");
    }
}