// 小脑模块 - 结构化语义记忆
// 负责知识图谱的存储、检索、衰减与三层记忆流转

pub mod graph_store;
pub mod query;
pub mod decay;

// 导出核心类型，方便外部模块使用
pub use graph_store::{GraphStore, KnowledgeEntry, MemoryTier, QueryOptions};
pub use decay::DecayConfig;