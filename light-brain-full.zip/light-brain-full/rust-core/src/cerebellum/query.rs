// 小脑模块 - 多策略检索实现
// 提供对知识图谱的灵活查询能力

use super::graph_store::{GraphStore, KnowledgeEntry, MemoryTier, QueryOptions};
use std::collections::HashSet;

impl GraphStore {
    // 多策略检索入口
    // 根据查询选项按优先级执行检索：精确匹配 > 标签匹配 > 关键词匹配 > 向量检索
    pub fn search(&self, options: &QueryOptions) -> Vec<KnowledgeEntry> {
        let mut results = Vec::new();
        let mut seen_ids = HashSet::new();

        // 策略1：精确匹配（主体 + 属性）
        if options.subject.is_some() && options.attribute.is_some() {
            let exact_results = self.query_exact(
                options.subject.as_ref().unwrap(),
                options.attribute.as_ref().unwrap(),
                options.tier,
                options.min_certainty,
            );
            for entry in exact_results {
                if seen_ids.insert(entry.id.clone()) {
                    results.push(entry);
                }
            }
        }

        // 策略2：标签匹配
        if !options.tags.is_empty() && results.len() < options.limit {
            let tag_results = self.query_by_tags(
                &options.tags,
                options.tier,
                options.min_certainty,
            );
            for entry in tag_results {
                if seen_ids.insert(entry.id.clone()) {
                    results.push(entry);
                    if results.len() >= options.limit {
                        break;
                    }
                }
            }
        }

        // 策略3：关键词匹配
        if !options.keywords.is_empty() && results.len() < options.limit {
            let keyword_results = self.query_by_keywords(
                &options.keywords,
                options.tier,
                options.min_certainty,
            );
            for entry in keyword_results {
                if seen_ids.insert(entry.id.clone()) {
                    results.push(entry);
                    if results.len() >= options.limit {
                        break;
                    }
                }
            }
        }

        // 策略4：向量检索（后期接入 OverGraph 的 HNSW 索引）
        // 当以上策略均未达到 limit 时，尝试语义向量检索
        if results.len() < options.limit && !options.keywords.is_empty() {
            // 预留接口：调用 OverGraph 的 vector_search 方法
            // let vector_results = self.vector_search(&options.keywords, options.limit - results.len());
            // for entry in vector_results { ... }
        }

        results
    }

    // 精确匹配：主体和属性同时完全一致
    fn query_exact(
        &self,
        subject: &str,
        attribute: &str,
        tier: Option<MemoryTier>,
        min_certainty: Option<f32>,
    ) -> Vec<KnowledgeEntry> {
        let mut results = Vec::new();
        let entries = self.entries.read();

        for entry in entries.values() {
            if entry.subject == subject && entry.attribute == attribute {
                if let Some(t) = tier {
                    if entry.tier != t {
                        continue;
                    }
                }
                if let Some(min_cert) = min_certainty {
                    if entry.certainty < min_cert {
                        continue;
                    }
                }
                results.push(entry.clone());
            }
        }
        results
    }

    // 标签匹配：至少包含一个指定标签
    fn query_by_tags(
        &self,
        tags: &[String],
        tier: Option<MemoryTier>,
        min_certainty: Option<f32>,
    ) -> Vec<KnowledgeEntry> {
        let mut results = Vec::new();
        let tag_index = self.tag_index.read();

        for tag in tags {
            if let Some(ids) = tag_index.get(tag) {
                for id in ids {
                    if let Some(entry) = self.get_by_id(id) {
                        if let Some(t) = tier {
                            if entry.tier != t {
                                continue;
                            }
                        }
                        if let Some(min_cert) = min_certainty {
                            if entry.certainty < min_cert {
                                continue;
                            }
                        }
                        results.push(entry);
                    }
                }
            }
        }
        results
    }

    // 关键词匹配：在主体、属性、值、描述中搜索
    fn query_by_keywords(
        &self,
        keywords: &[String],
        tier: Option<MemoryTier>,
        min_certainty: Option<f32>,
    ) -> Vec<KnowledgeEntry> {
        let mut results = Vec::new();
        let entries = self.entries.read();

        for entry in entries.values() {
            if let Some(t) = tier {
                if entry.tier != t {
                    continue;
                }
            }
            if let Some(min_cert) = min_certainty {
                if entry.certainty < min_cert {
                    continue;
                }
            }

            let mut matched = false;
            for kw in keywords {
                if entry.subject.contains(kw)
                    || entry.attribute.contains(kw)
                    || entry.value.contains(kw)
                    || entry.description.contains(kw)
                {
                    matched = true;
                    break;
                }
            }
            if matched {
                results.push(entry.clone());
            }
        }
        results
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cerebellum::graph_store::{GraphStore, KnowledgeEntry, MemoryTier};

    #[test]
    fn test_search_strategies() {
        let store = GraphStore::new();
        
        // 插入测试数据（抽象占位符）
        let entry1 = KnowledgeEntry {
            id: "alpha".to_string(),
            subject: "subject_one".to_string(),
            attribute: "attr_one".to_string(),
            value: "val_one".to_string(),
            description: "Description containing keyword magic.".to_string(),
            tags: vec!["tag_a".to_string()],
            certainty: 0.9,
            created_at: 1000,
            last_accessed: 1000,
            access_count: 0,
            tier: MemoryTier::Active,
        };
        let entry2 = KnowledgeEntry {
            id: "beta".to_string(),
            subject: "subject_two".to_string(),
            attribute: "attr_two".to_string(),
            value: "val_two".to_string(),
            description: "Another generic description.".to_string(),
            tags: vec!["tag_b".to_string()],
            certainty: 0.8,
            created_at: 1000,
            last_accessed: 1000,
            access_count: 0,
            tier: MemoryTier::Active,
        };
        store.upsert(entry1).unwrap();
        store.upsert(entry2).unwrap();

        // 测试精确匹配
        let mut options = QueryOptions::default();
        options.subject = Some("subject_one".to_string());
        options.attribute = Some("attr_one".to_string());
        options.limit = 10;
        let results = store.search(&options);
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].id, "alpha");

        // 测试关键词匹配
        let mut options = QueryOptions::default();
        options.keywords = vec!["magic".to_string()];
        options.limit = 10;
        let results = store.search(&options);
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].id, "alpha");
    }
}