// 杏仁核模块 - 情感与风格评估
// 基于规则引擎，根据意图和情感输出语言风格修饰符

pub mod rule_engine;

pub use rule_engine::{Amygdala, Rule, StyleOutput};