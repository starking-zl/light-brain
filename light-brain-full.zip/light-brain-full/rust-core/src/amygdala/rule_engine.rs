// 杏仁核规则引擎
// 根据预设规则匹配意图和情感，输出对应的风格修饰符

use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs;
use std::path::Path;

// 意图类别枚举
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Intent {
    AskFact,
    ExpressOpinion,
    Chat,
    TestBoundary,
    Unknown,
}

// 情感极性枚举
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Polarity {
    Positive,
    Neutral,
    Negative,
    Playful,
    Aggressive,
    Any, // 特殊值，表示匹配任意情感
}

// 风格修饰符枚举
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Style {
    Normal,
    Enthusiastic,
    Cautious,
    Playful,
    Defensive,
    Confused,
}

// 单条规则定义
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Rule {
    pub condition: RuleCondition,
    pub output: StyleOutput,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RuleCondition {
    pub intent: Intent,
    pub polarity: Polarity,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StyleOutput {
    pub style: Style,
}

// 规则文件顶层结构
#[derive(Debug, Clone, Serialize, Deserialize)]
struct RulesFile {
    rules: Vec<Rule>,
    default: StyleOutput,
}

// 杏仁核规则引擎
pub struct Amygdala {
    rules: Vec<Rule>,
    default_style: Style,
}

impl Amygdala {
    // 从 JSON 文件加载规则
    pub fn from_file<P: AsRef<Path>>(path: P) -> Result<Self, Box<dyn std::error::Error>> {
        let content = fs::read_to_string(path)?;
        let rules_file: RulesFile = serde_json::from_str(&content)?;
        Ok(Amygdala {
            rules: rules_file.rules,
            default_style: rules_file.default.style,
        })
    }

    // 从内存中的规则数据构建（用于测试）
    pub fn new(rules: Vec<Rule>, default_style: Style) -> Self {
        Amygdala {
            rules,
            default_style,
        }
    }

    // 推理：根据意图和情感返回风格
    pub fn infer(&self, intent: Intent, polarity: Polarity) -> Style {
        for rule in &self.rules {
            if rule.condition.intent == intent {
                if rule.condition.polarity == polarity || rule.condition.polarity == Polarity::Any {
                    return rule.output.style;
                }
            }
        }
        self.default_style
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_rule_matching() {
        let rules = vec![
            Rule {
                condition: RuleCondition {
                    intent: Intent::AskFact,
                    polarity: Polarity::Positive,
                },
                output: StyleOutput { style: Style::Enthusiastic },
            },
            Rule {
                condition: RuleCondition {
                    intent: Intent::TestBoundary,
                    polarity: Polarity::Any,
                },
                output: StyleOutput { style: Style::Defensive },
            },
        ];
        let amygdala = Amygdala::new(rules, Style::Normal);

        // 精确匹配
        assert_eq!(amygdala.infer(Intent::AskFact, Polarity::Positive), Style::Enthusiastic);
        // 未命中规则，返回默认
        assert_eq!(amygdala.infer(Intent::AskFact, Polarity::Negative), Style::Normal);
        // Any 极性匹配
        assert_eq!(amygdala.infer(Intent::TestBoundary, Polarity::Aggressive), Style::Defensive);
        assert_eq!(amygdala.infer(Intent::TestBoundary, Polarity::Playful), Style::Defensive);
    }
}