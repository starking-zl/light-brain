// 三层记忆状态管理器
// 实现活跃、沉寂、垃圾状态之间的转换规则

use crate::cerebellum::{GraphStore, KnowledgeEntry, MemoryTier, QueryOptions};
use crate::utils::time::current_timestamp;
use std::sync::Arc;

pub struct TierManager {
    store: Arc<GraphStore>,
    dormant_threshold: f32,
    garbage_threshold: f32,
    max_dormant_ratio: f32,
}

impl TierManager {
    pub fn new(store: Arc<GraphStore>) -> Self {
        TierManager {
            store,
            dormant_threshold: 0.1,
            garbage_threshold: 0.01,
            max_dormant_ratio: 2.0,
        }
    }

    pub fn run_flow(&self) {
        let mut options = QueryOptions::default();
        options.tier = None;
        options.limit = 10000;
        let entries = self.store.query(&options);
        
        let now = current_timestamp();
        
        for mut entry in entries {
            if entry.tier == MemoryTier::Garbage {
                continue;
            }
            
            let days_since_access = (now - entry.last_accessed) as f32 / 86400.0;
            let decay = (-0.01 * days_since_access).exp();
            let activity = entry.certainty * decay;
            
            let new_tier = if activity < self.garbage_threshold {
                MemoryTier::Garbage
            } else if activity < self.dormant_threshold {
                MemoryTier::Dormant
            } else {
                MemoryTier::Active
            };
            
            if entry.tier != new_tier {
                entry.tier = new_tier;
                let _ = self.store.upsert(entry);
            }
        }
        
        self.enforce_dormant_limit();
    }
    
    fn enforce_dormant_limit(&self) {
        let active_count = self.count_by_tier(MemoryTier::Active);
        let max_dormant = (active_count as f32 * self.max_dormant_ratio) as usize;
        
        let mut options = QueryOptions::default();
        options.tier = Some(MemoryTier::Dormant);
        options.limit = 10000;
        let mut dormant_entries = self.store.query(&options);
        
        if dormant_entries.len() > max_dormant {
            dormant_entries.sort_by(|a, b| {
                let score_a = a.certainty * (1.0 / (a.last_accessed as f32 + 1.0));
                let score_b = b.certainty * (1.0 / (b.last_accessed as f32 + 1.0));
                score_a.partial_cmp(&score_b).unwrap()
            });
            
            let to_garbage = dormant_entries.len() - max_dormant;
            for entry in dormant_entries.iter().take(to_garbage) {
                let mut e = entry.clone();
                e.tier = MemoryTier::Garbage;
                let _ = self.store.upsert(e);
            }
        }
    }
    
    fn count_by_tier(&self, tier: MemoryTier) -> usize {
        let mut options = QueryOptions::default();
        options.tier = Some(tier);
        options.limit = 10000;
        self.store.query(&options).len()
    }
}