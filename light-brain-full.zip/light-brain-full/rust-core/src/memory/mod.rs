// 记忆管理子系统 - 三层记忆状态机与垃圾回收
// 管理活跃库、沉寂库、垃圾库之间的流转与用户交互

pub mod tier;
pub mod garbage;

pub use tier::TierManager;
pub use garbage::GarbageCollector;