// 海马体记忆巩固引擎
// 定时分析高频访问事件，提取知识点提交至小脑

use crate::cerebellum::{GraphStore, KnowledgeEntry, MemoryTier};
use super::event_store::EventStore;
use crate::utils::time::current_timestamp;

pub struct ConsolidationEngine {
    event_store: EventStore,
    graph_store: GraphStore,
    min_access_count: u32,
    min_confidence: f32,
}

impl ConsolidationEngine {
    pub fn new(event_store: EventStore, graph_store: GraphStore) -> Self {
        ConsolidationEngine {
            event_store,
            graph_store,
            min_access_count: 5,
            min_confidence: 0.8,
        }
    }

    pub fn run_consolidation(&self) -> usize {
        let mut consolidated = 0;
        let events = self.event_store.list_all(1000).unwrap_or_default();

        for event in events {
            if event.access_count >= self.min_access_count {
                if let Some(fact_id) = &event.fact_id {
                    if let Some(mut entry) = self.graph_store.get_by_id(fact_id) {
                        entry.certainty = (entry.certainty + 0.1).min(1.0);
                        entry.tier = MemoryTier::Active;
                        entry.last_accessed = current_timestamp();
                        let _ = self.graph_store.upsert(entry);
                        consolidated += 1;
                    }
                }
            }
        }
        consolidated
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cerebellum::{GraphStore, KnowledgeEntry, MemoryTier};
    use crate::hippocampus::event_store::{EpisodicEvent, EventStore};
    use tempfile::NamedTempFile;

    #[test]
    fn test_consolidation() {
        let tmp = NamedTempFile::new().unwrap();
        let store = EventStore::new(tmp.path()).unwrap();
        let graph = GraphStore::new();

        let entry = KnowledgeEntry {
            id: "fact_001".to_string(),
            subject: "widget".to_string(),
            attribute: "use".to_string(),
            value: "testing".to_string(),
            description: "used for testing".to_string(),
            tags: vec![],
            certainty: 0.7,
            created_at: 1000,
            last_accessed: 1000,
            access_count: 0,
            tier: MemoryTier::Active,
        };
        graph.upsert(entry).unwrap();

        let event = EpisodicEvent {
            id: "evt_001".to_string(),
            timestamp: 2000,
            user_input: "test".to_string(),
            intent: "AskFact".to_string(),
            polarity: "Neutral".to_string(),
            domain: "InDomain".to_string(),
            fact_id: Some("fact_001".to_string()),
            reply: "reply".to_string(),
            access_count: 10,
        };
        store.insert(event).unwrap();

        let engine = ConsolidationEngine::new(store, graph.clone());
        let count = engine.run_consolidation();
        assert_eq!(count, 1);

        let updated = graph.get_by_id("fact_001").unwrap();
        assert!(updated.certainty > 0.7);
    }
}