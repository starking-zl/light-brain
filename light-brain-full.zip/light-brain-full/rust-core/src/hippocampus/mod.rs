// 海马体模块 - 情景记忆与巩固
// 负责记录对话事件、检索历史、定时巩固至小脑

pub mod event_store;
pub mod retrieval;
pub mod consolidation;

pub use event_store::{EventStore, EpisodicEvent};
pub use retrieval::RetrievalEngine;
pub use consolidation::ConsolidationEngine;