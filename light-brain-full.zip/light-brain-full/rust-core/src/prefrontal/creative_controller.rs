// 创造性控制器 - 三旋钮联动回路
// 温度 τ、门控 γ、评估权重 ε

use serde::{Deserialize, Serialize};

// 创造性模式
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum CreativeMode {
    Rigorous,      // 严谨推理
    Daily,         // 日常对话
    Creative,      // 头脑风暴
    Counterfactual, // 反事实想象
}

// 三旋钮值
#[derive(Debug, Clone, Copy)]
pub struct KnobValues {
    pub temperature: f32,   // τ
    pub gate: f32,          // γ
    pub novelty_weight: f32, // ε
}

impl Default for KnobValues {
    fn default() -> Self {
        KnobValues {
            temperature: 0.8,
            gate: 0.6,
            novelty_weight: 0.2,
        }
    }
}

// 创造性控制器
pub struct CreativeController {
    mode: CreativeMode,
    baseline: KnobValues,
}

impl CreativeController {
    pub fn new(mode: CreativeMode) -> Self {
        let baseline = match mode {
            CreativeMode::Rigorous => KnobValues {
                temperature: 0.4,
                gate: 0.9,
                novelty_weight: 0.0,
            },
            CreativeMode::Daily => KnobValues {
                temperature: 0.8,
                gate: 0.6,
                novelty_weight: 0.2,
            },
            CreativeMode::Creative => KnobValues {
                temperature: 1.3,
                gate: 0.3,
                novelty_weight: 0.7,
            },
            CreativeMode::Counterfactual => KnobValues {
                temperature: 1.2,
                gate: 0.1,
                novelty_weight: 0.8,
            },
        };
        CreativeController { mode, baseline }
    }

    // 获取当前旋钮值
    pub fn get_knobs(&self) -> KnobValues {
        self.baseline
    }

    // 根据生成反馈动态微调（预留接口）
    pub fn adjust(&mut self, diversity: f32, conflict: f32) {
        // 动态微调逻辑：若多样性过低，适当提高温度
        if diversity < 0.3 {
            self.baseline.temperature = (self.baseline.temperature + 0.1).min(2.0);
        }
        if conflict > 0.7 {
            self.baseline.gate = (self.baseline.gate + 0.1).min(1.0);
        }
    }
}