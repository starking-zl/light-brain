// 前额叶融合引擎
// 将小脑返回的事实与杏仁核返回的风格组合为符号决策包

use crate::amygdala::Style;
use crate::cerebellum::KnowledgeEntry;
use super::decision_table::{FactSource, FallbackAction, Intent, StyleSource};

// 符号决策包
#[derive(Debug, Clone)]
pub struct DecisionPackage {
    pub intent: Intent,
    pub fact: Option<KnowledgeEntry>,
    pub style: Style,
    pub fallback_action: Option<FallbackAction>,
}

pub struct FusionEngine;

impl FusionEngine {
    // 融合事实与风格
    pub fn fuse(
        intent: Intent,
        fact_source: FactSource,
        style_source: StyleSource,
        fact: Option<KnowledgeEntry>,
        style: Style,
        fallback: FallbackAction,
    ) -> DecisionPackage {
        let final_fact = match fact_source {
            FactSource::Cerebellum => fact,
            FactSource::None => None,
        };

        let fallback_action = if final_fact.is_none() {
            Some(fallback)
        } else {
            None
        };

        DecisionPackage {
            intent,
            fact: final_fact,
            style,
            fallback_action,
        }
    }
}