// 工作记忆 - 临时缓冲区
// 存储当前推理过程中的中间符号、候选输出、冲突标记

use std::collections::VecDeque;
use crate::cerebellum::KnowledgeEntry;
use super::decision_table::Intent;

// 工作记忆槽位
#[derive(Debug, Clone)]
pub struct WorkingMemorySlot {
    pub intent: Intent,
    pub fact: Option<KnowledgeEntry>,
    pub style: String,
    pub certainty: f32,
}

// 工作记忆
pub struct WorkingMemory {
    slots: VecDeque<WorkingMemorySlot>,
    capacity: usize,
}

impl WorkingMemory {
    pub fn new(capacity: usize) -> Self {
        WorkingMemory {
            slots: VecDeque::new(),
            capacity,
        }
    }

    // 写入一个推理状态
    pub fn push(&mut self, slot: WorkingMemorySlot) {
        if self.slots.len() >= self.capacity {
            self.slots.pop_front();
        }
        self.slots.push_back(slot);
    }

    // 读取最近的状态（不弹出）
    pub fn peek_recent(&self) -> Option<&WorkingMemorySlot> {
        self.slots.back()
    }

    // 清空工作记忆
    pub fn clear(&mut self) {
        self.slots.clear();
    }

    // 获取所有槽位（用于多轮上下文）
    pub fn all_slots(&self) -> Vec<WorkingMemorySlot> {
        self.slots.iter().cloned().collect()
    }
}