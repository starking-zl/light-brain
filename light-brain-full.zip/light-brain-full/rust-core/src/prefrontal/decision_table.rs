// 前额叶决策表
// 根据丘脑输出的意图和领域，匹配预设的调度规则

use serde::{Deserialize, Serialize};
use std::fs;
use std::path::Path;

// 意图类别
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Intent {
    AskFact,
    ExpressOpinion,
    Chat,
    TestBoundary,
    Unknown,
}

// 话题领域
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Domain {
    InDomain,
    OutDomain,
    Meta,
    Daily,
    Any,
}

// 调度策略
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Schedule {
    pub call_cerebellum: bool,
    pub call_amygdala: bool,
    pub call_hippocampus: bool,
}

// 融合策略
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Fusion {
    pub fact_source: FactSource,
    pub style_source: StyleSource,
    pub fallback: FallbackAction,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum FactSource {
    Cerebellum,
    None,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum StyleSource {
    Amygdala,
    None,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum FallbackAction {
    UseFallback,
    UseConfused,
    UseDefensive,
    UseChat,
    OpinionOnly,
}

// 单条决策
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Decision {
    pub condition: DecisionCondition,
    pub schedule: Schedule,
    pub fusion: Fusion,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DecisionCondition {
    pub intent: Intent,
    pub domain: Domain,
}

// 决策表文件结构
#[derive(Debug, Clone, Serialize, Deserialize)]
struct DecisionTableFile {
    decisions: Vec<Decision>,
    default: Decision,
}

// 决策表
pub struct DecisionTable {
    decisions: Vec<Decision>,
    default: Decision,
}

impl DecisionTable {
    // 从 JSON 文件加载
    pub fn from_file<P: AsRef<Path>>(path: P) -> Result<Self, Box<dyn std::error::Error>> {
        let content = fs::read_to_string(path)?;
        let file: DecisionTableFile = serde_json::from_str(&content)?;
        Ok(DecisionTable {
            decisions: file.decisions,
            default: file.default,
        })
    }

    // 匹配决策
    pub fn match_decision(&self, intent: Intent, domain: Domain) -> (Schedule, Fusion) {
        for dec in &self.decisions {
            if dec.condition.intent == intent {
                if dec.condition.domain == domain || dec.condition.domain == Domain::Any {
                    return (dec.schedule.clone(), dec.fusion.clone());
                }
            }
        }
        (self.default.schedule.clone(), self.default.fusion.clone())
    }
}