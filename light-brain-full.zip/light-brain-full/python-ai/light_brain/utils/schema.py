# Schema 校验工具
# 验证各模块输入输出是否符合接口规范

from typing import Dict, List, Optional, Any
import json

# 有效枚举值
VALID_INTENTS = {"AskFact", "ExpressOpinion", "Chat", "TestBoundary", "Unknown"}
VALID_POLARITIES = {"Positive", "Neutral", "Negative", "Playful", "Aggressive"}
VALID_DOMAINS = {"InDomain", "OutDomain", "Meta", "Daily", "Any"}
VALID_STYLES = {"Normal", "Enthusiastic", "Cautious", "Playful", "Defensive", "Confused"}


def validate_intent(intent: str) -> bool:
    return intent in VALID_INTENTS


def validate_polarity(polarity: str) -> bool:
    return polarity in VALID_POLARITIES


def validate_domain(domain: str) -> bool:
    return domain in VALID_DOMAINS


def validate_style(style: str) -> bool:
    return style in VALID_STYLES


def validate_thalamus_output(data: Dict[str, Any]) -> bool:
    required = {"intent", "polarity", "domain", "keywords", "certainty"}
    if not all(k in data for k in required):
        return False
    if not validate_intent(data["intent"]):
        return False
    if not validate_polarity(data["polarity"]):
        return False
    if not validate_domain(data["domain"]):
        return False
    if not isinstance(data["keywords"], list):
        return False
    if not (0.0 <= data["certainty"] <= 1.0):
        return False
    return True


def validate_decision_package(data: Dict[str, Any]) -> bool:
    required = {"intent", "fact", "style"}
    if not all(k in data for k in required):
        return False
    if not validate_intent(data["intent"]):
        return False
    if not validate_style(data["style"]):
        return False
    return True