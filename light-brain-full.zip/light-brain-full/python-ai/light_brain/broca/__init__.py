from .planner import SemanticPlanner
from .generator import SLMGenerator
from .constraints import ConstraintGuider

class Broca:
    def __init__(self, slm_model_path: str, templates_path: str):
        self.planner = SemanticPlanner()
        self.generator = SLMGenerator(slm_model_path)
        self.constraints = ConstraintGuider()
        # 兜底模板
        with open(templates_path, 'r', encoding='utf-8') as f:
            self.templates = json.load(f)

    def generate(self, decision_package: dict) -> str:
        # 1. 语义规划：构建抽象骨架
        skeleton = self.planner.plan(decision_package)
        # 2. 神经生成：调用 SLM 生成候选文本
        candidates = self.generator.generate(skeleton, decision_package.get("style", "normal"))
        # 3. 约束引导：筛选并修正
        best = self.constraints.guide(candidates, decision_package)
        if best is None:
            best = self._fallback_template(decision_package)
        return best

    def _fallback_template(self, decision_package):
        # 模板兜底逻辑
        return "I'm not sure how to respond to that."