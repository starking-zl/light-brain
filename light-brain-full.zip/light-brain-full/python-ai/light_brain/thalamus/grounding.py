import json
import numpy as np
from typing import Dict
# 假设已通过 PyO3 导入 Rust 原型库
try:
    from light_brain_binding import PrototypeStore as RustPrototypeStore
except ImportError:
    RustPrototypeStore = None

class GroundingLayer:
    def __init__(self, prototype_store):
        self.store = prototype_store  # 若 Rust 绑定可用，则为 Rust 对象；否则为 Python 字典

    def classify_intent(self, vector: np.ndarray) -> Dict[str, float]:
        # 调用 Rust 层的 grounding_layer 或 Python fallback
        if RustPrototypeStore:
            # 使用 Rust 实现
            results = rust_grounding(vector, self.store, "intent")
            return {r.label: r.probability for r in results}
        else:
            # Python fallback: 余弦相似度 + softmax
            return self._python_classify(vector, "intent")

    def _python_classify(self, vector, category):
        prototypes = self.store.get(category, [])
        sims = [self._cosine(vector, p["vector"]) for p in prototypes]
        probs = self._softmax(sims)
        return {p["label"]: prob for p, prob in zip(prototypes, probs)}

    @staticmethod
    def _cosine(a, b):
        return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-8)

    @staticmethod
    def _softmax(x):
        e_x = np.exp(x - np.max(x))
        return e_x / e_x.sum()