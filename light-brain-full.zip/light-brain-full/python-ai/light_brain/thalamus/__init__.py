from .encoder import IntentEncoder
from .grounding import GroundingLayer

class Thalamus:
    def __init__(self, encoder_model_path: str, prototype_store):
        self.encoder = IntentEncoder(encoder_model_path)
        self.grounding = GroundingLayer(prototype_store)

    def perceive(self, text: str) -> dict:
        # 1. 编码器生成连续向量
        vector = self.encoder.encode(text)
        # 2. 符号接地层映射到标签概率分布
        intent_dist = self.grounding.classify_intent(vector)
        polarity_dist = self.grounding.classify_polarity(vector)
        domain_dist = self.grounding.classify_domain(vector)
        # 3. 提取关键词（简化：jieba分词取TF-IDF）
        keywords = self._extract_keywords(text)
        # 4. 组装输出
        return {
            "intent": max(intent_dist, key=intent_dist.get),
            "polarity": max(polarity_dist, key=polarity_dist.get),
            "domain": max(domain_dist, key=domain_dist.get),
            "keywords": keywords,
            "certainty": max(intent_dist.values())
        }

    def _extract_keywords(self, text: str) -> list:
        # 简化实现，后期可接入 KeyBERT
        import jieba
        words = jieba.lcut(text)
        # 停用词过滤略
        return list(set(words))[:5]