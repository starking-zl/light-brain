from abc import ABC, abstractmethod
from typing import List
from dataclasses import dataclass

@dataclass
class PublicKnowledgeEntry:
    id: str
    subject: str
    attribute: str
    value: str
    description: str
    tags: List[str]
    certainty: float
    source: str
    source_trust: float


class PublicKnowledgeSource(ABC):
    @abstractmethod
    def name(self) -> str:
        pass

    @abstractmethod
    def default_trust(self) -> float:
        pass

    @abstractmethod
    def query(self, keywords: List[str], limit: int) -> List[PublicKnowledgeEntry]:
        pass

    @abstractmethod
    def is_available(self) -> bool:
        pass