import os
import tomllib
from dataclasses import dataclass

@dataclass
class OfflineSourceConfig:
    enabled: bool = False
    data_path: str = ""
    source_name: str = "Offline"
    default_trust: float = 0.85

@dataclass
class MCPSourceConfig:
    enabled: bool = False
    server_url: str = ""
    timeout_seconds: int = 5

@dataclass
class RetrievalConfig:
    fallback_only: bool = True
    max_supplement_count: int = 3
    write_back_to_cerebellum: bool = True

@dataclass
class PublicKGConfig:
    enabled: bool = False
    offline: OfflineSourceConfig = OfflineSourceConfig()
    mcp: MCPSourceConfig = MCPSourceConfig()
    retrieval: RetrievalConfig = RetrievalConfig()

    @classmethod
    def from_file(cls, path: str) -> "PublicKGConfig":
        if not os.path.exists(path):
            return cls()
        try:
            with open(path, "rb") as f:
                data = tomllib.load(f)
            return cls(
                enabled=data.get("enabled", False),
                offline=OfflineSourceConfig(**data.get("offline", {})),
                mcp=MCPSourceConfig(**data.get("mcp", {})),
                retrieval=RetrievalConfig(**data.get("retrieval", {})),
            )
        except Exception:
            return cls()