from typing import List
from ..traits import PublicKnowledgeSource, PublicKnowledgeEntry

class OfflineSource(PublicKnowledgeSource):
    def name(self) -> str:
        return "Offline"

    def default_trust(self) -> float:
        return 0.85

    def query(self, keywords: List[str], limit: int) -> List[PublicKnowledgeEntry]:
        # 待贡献者实现：从本地文件加载知识图谱并检索
        return []

    def is_available(self) -> bool:
        return False