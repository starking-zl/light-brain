from typing import List
from ..traits import PublicKnowledgeSource, PublicKnowledgeEntry

class MCPSource(PublicKnowledgeSource):
    def name(self) -> str:
        return "MCP"

    def default_trust(self) -> float:
        return 0.9

    def query(self, keywords: List[str], limit: int) -> List[PublicKnowledgeEntry]:
        # 待贡献者实现：通过 MCP 协议查询远程公库
        return []

    def is_available(self) -> bool:
        return False