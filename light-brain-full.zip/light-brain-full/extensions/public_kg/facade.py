import json
from typing import List, Optional, Dict, Any
from .traits import PublicKnowledgeSource
from .config import PublicKGConfig

class PublicKnowledgeFacade:
    def __init__(self, config: PublicKGConfig):
        self.config = config
        self.sources: List[PublicKnowledgeSource] = []
        self._load_sources()

    def _load_sources(self):
        # 贡献者在此处根据配置初始化具体数据源
        pass

    def is_enabled(self) -> bool:
        return self.config.enabled and len(self.sources) > 0

    def query_one(self, keywords: List[str]) -> Optional[Dict[str, Any]]:
        if not self.is_enabled():
            return None
        for source in self.sources:
            if not source.is_available():
                continue
            entries = source.query(keywords, limit=1)
            if entries:
                entry = entries[0]
                return {
                    "id": entry.id,
                    "subject": entry.subject,
                    "attribute": entry.attribute,
                    "value": entry.value,
                    "description": entry.description,
                    "tags": entry.tags,
                    "certainty": entry.certainty * entry.source_trust * 0.95,
                    "created_at": int(__import__("time").time()),
                    "last_accessed": 0,
                    "access_count": 0,
                    "tier": "Active",
                    "source": entry.source,
                }
        return None