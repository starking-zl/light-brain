from typing import List, Dict, Any

def filter_and_prioritize(
    pub_entries: List[Dict[str, Any]],
    growth_entries: List[Dict[str, Any]],
    limit: int,
) -> List[Dict[str, Any]]:
    """
    过滤公库条目，移除与生长知识冲突的内容，返回不超过 limit 的补充条目。
    """
    growth_keys = {(e.get("subject"), e.get("attribute")) for e in growth_entries}
    filtered = []
    for entry in pub_entries:
        key = (entry.get("subject"), entry.get("attribute"))
        if key not in growth_keys:
            filtered.append(entry)
            if len(filtered) >= limit:
                break
    return filtered