# Model Download Guide

The Python AI layer of Light-Brain Scheme depends on two pretrained neural network models. Contributors must download and place them in the designated directories.

## 1. Thalamus Encoder Model

**Purpose**: Encode user input into continuous vectors for intent classification and symbol grounding.

**Recommended Models**:
- `distilbert-base-multilingual-cased` (supports both English and Chinese)
- Or `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2`

**Download**:
```bash
cd data/models
git lfs install
git clone https://huggingface.co/distilbert-base-multilingual-cased thalamus_encoder
```

Place at: data/models/thalamus_encoder/

2. Broca SLM Model

Purpose: Generate natural language replies based on semantic skeletons.

Recommended Models:

· Chinese: Qwen/Qwen2.5-0.5B or Qwen/Qwen2.5-1.5B
· English: HuggingFaceTB/SmolLM-135M or TinyLlama/TinyLlama-1.1B

Download:

```bash
cd data/models
git clone https://huggingface.co/Qwen/Qwen2.5-0.5B broca_slm
```

Place at: data/models/broca_slm/

3. Verification

Run the Light-Brain main entry. If no missing model errors occur, the download is successful.