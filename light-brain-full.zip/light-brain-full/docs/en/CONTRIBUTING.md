# Light-Brain Scheme Contributing Guide

Thank you for your interest in contributing to the Light-Brain Scheme! This document will guide you through the contribution process.

---

## I. Code of Conduct

This project follows the standard open source community code of conduct:
- Respect all contributors regardless of experience level, gender, sexual orientation, race, or religion.
- Keep discussions constructive and critique ideas rather than individuals.
- Maintain an open mind when receiving feedback.

---

## II. How to Contribute

### Ways to Contribute
| Method | Description |
| :--- | :--- |
| Report Bugs | Submit a Bug report in Issues with steps to reproduce and expected behavior. |
| Suggest Features | Start a discussion in Discussions for feature requests or architectural ideas. |
| Submit Code | Fork the repository, make changes, and open a Pull Request. |
| Improve Documentation | Fix typos, add examples, or translate documents. |
| Add Tests | Supplement unit tests or end-to-end test cases. |

### First Contribution Suggestions
1. Read MVP_README.md and the full architecture documentation to understand the project's goals and design.
2. Start with issues labeled good first issue.
3. Keep commits small and each Pull Request focused on a single feature or fix.

---

## III. Development Environment Setup

### Basic Requirements
- Python 3.9 or higher
- Git
- Recommended: use a virtual environment (venv or conda)

### Clone the Repository
git clone https://github.com/your-org/light-brain-scheme.git
cd light-brain-scheme

### Install Dependencies
The MVP phase has no third-party dependencies. Starting from Phase 2, use the following command:
pip install -r requirements.txt

### Run Tests
# Navigate to the project root
cd Light-Brain-Scheme-MVP
python main.py

---

## IV. Code Style Guidelines

### Python Code Style
- Follow PEP 8.
- Use 4 spaces for indentation, no tabs.
- Maximum line length 100 characters.
- Class names in CamelCase (e.g., Cerebellum), functions and variables in lowercase with underscores (e.g., query_knowledge).
- File encoding must be UTF-8.

### Comment Guidelines
- Each module, class, and public method should have a docstring.
- Use English comments for the English version of the codebase; consistency within a file is required.

### Example
class Cerebellum:
    """
    Cerebellum module: responsible for structured knowledge storage and retrieval.
    """
    
    def query(self, keywords):
        """
        Retrieve a knowledge entry based on keywords.
        
        Args:
            keywords (list): List of keyword strings.
        
        Returns:
            dict or None: Matching knowledge entry, or None if not found.
        """
        pass

---

## V. Commit Guidelines

### Commit Message Format
<type>: <short description>

<detailed description (optional)>

### Type Values
| Type | Description |
| :--- | :--- |
| feat | New feature |
| fix | Bug fix |
| docs | Documentation update |
| style | Code formatting (no logic change) |
| refactor | Refactoring (no functional change) |
| test | Test related |
| chore | Build or tooling updates |

### Example
feat: integrate DistilBERT intent classification in Thalamus

- Added Thalamus class with model loading and inference
- Outputs standardized intent, polarity, and domain labels
- Marks intent as unknown when certainty below 0.5

---

## VI. Pull Request Process

1. Fork the main repository to your personal account.
2. Create a feature branch from main (e.g., feat/thalamus-model).
3. Complete development on the feature branch and ensure local tests pass.
4. Push the feature branch to your personal remote repository.
5. Open a Pull Request on GitHub with a clear title and description.
6. Respond to reviewer feedback and push updates until merged.

### PR Title Format
- feat: integrate Thalamus intent classification model

### PR Description Template
### Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Documentation update
- [ ] Refactoring

### Changes Made
Briefly describe the main changes in this PR.

### Testing
- [ ] Unit tests pass
- [ ] End-to-end tests pass
- [ ] New tests added

### Related Issue
Closes #123

---

## VII. Testing Guidelines

### Unit Tests
- Place test files in the tests/ directory with naming format test_<module_name>.py.
- Use Python's standard unittest or pytest.
- Each module should cover at least the happy path and edge cases for core methods.

### End-to-End Tests
- Maintain a set of representative test inputs in main.py.
- After major changes, run python main.py and manually inspect output quality.

### Test Data
- Knowledge bases, rule files, and template files for testing should be placed in tests/fixtures/.
- Ensure test data contains no sensitive information.

---

## VIII. Documentation Contributions

### Document Types
| Document | Location | Description |
| :--- | :--- | :--- |
| MVP_README.md | MVP/ directory | Project overview, MVP scope, how to run |
| IMPLEMENTATION_ROADMAP.md | Root directory | Phased iteration plan |
| CONTRIBUTING.md | Root directory | This document |
| GLOSSARY_EN_ZH.md | Root directory | English-Chinese terminology reference |

### Documentation Standards
- Use American English for English documents.
- Maintain clear heading hierarchy with #, ##, ###.
- Specify language for code blocks (e.g., json, python, bash).
- Wrap file paths in backticks (e.g., data/knowledge.json).

---

## IX. Versioning

This project follows Semantic Versioning: MAJOR.MINOR.PATCH
- MAJOR: incompatible API changes.
- MINOR: backward-compatible new features.
- PATCH: backward-compatible bug fixes.

Current version: v0.1.0 (MVP phase).

---

## X. Contact and Discussion

- Technical Discussion: Start a topic in GitHub Discussions.
- Bug Reports: Submit via GitHub Issues with detailed reproduction steps.
- Security Vulnerabilities: Do not disclose publicly; contact maintainers directly (email to be added).

---

*Light-Brain Scheme Contributing Guide Version: v0.1.0*
*Last Updated: April 2026*