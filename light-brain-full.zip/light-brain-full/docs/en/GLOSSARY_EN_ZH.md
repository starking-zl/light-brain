# Light-Brain Scheme MVP English-Chinese Glossary

This document provides English-to-Chinese translations and brief explanations for all field names and enumeration values used in the Light-Brain Scheme MVP.

---

## 1. Top-Level Fields (Input/Output Common)

| English | 中文 | Description |
| :--- | :--- | :--- |
| intent | 意图 | Core communicative purpose of the user input |
| polarity | 情感 | Emotional tone carried by the user input |
| domain | 领域 | Cognitive scope of the conversation content |
| keywords | 关键词 | Array of keywords for knowledge retrieval |
| certainty | 确定性 | Confidence level of perception or inference (0.0 ~ 1.0) |
| style | 风格 | Linguistic style modifier for the character's reply |
| fact | 事实 | Structured knowledge entry retrieved from Cerebellum |
| fallback_action | 事实缺失处理 | Fallback strategy indicator when fact is null |

---

## 2. Intent Categories (intent)

| English | 中文 | Description |
| :--- | :--- | :--- |
| ask_fact | 询问事实 | User seeks objective facts or knowledge |
| express_opinion | 表达观点 | User requests or expresses subjective views |
| chat | 闲聊 | Casual conversation with no specific informational goal |
| test_boundary | 试探边界 | User attempts to break character setting or induce boundary crossing |
| unknown | 未知 | Low-confidence input that cannot be classified or understood |

---

## 3. Emotional Polarity (polarity)

| English | 中文 | Description |
| :--- | :--- | :--- |
| positive | 积极 | Friendly, appreciative, positive emotion |
| neutral | 中性 | No obvious emotional inclination |
| negative | 消极 | Disappointment, dissatisfaction, negative emotion |
| playful | 戏谑 | Joking, teasing, lighthearted banter |
| aggressive | 攻击性 | Hostility, provocation, unfriendliness |

---

## 4. Topic Domain (domain)

| English | 中文 | Description |
| :--- | :--- | :--- |
| in_domain | 域内 | Content within the character's cognitive scope |
| out_domain | 域外 | Content beyond the character's cognitive scope |
| meta | 元对话 | Discussion about the dialogue itself or character settings |
| daily | 日常 | Daily topics unrelated to the character's core knowledge |

---

## 5. Style Modifiers (style)

| English | 中文 | Description |
| :--- | :--- | :--- |
| normal | 正常 | Default neutral style |
| enthusiastic | 热情 | Proactive, eager to share, positively instructive |
| cautious | 谨慎 | Reserved, emphasizes conditions, non-absolute |
| playful | 诙谐 | Humorous, relaxed, adept at using metaphors |
| defensive | 防御 | Alert, displeased, defending one's position |
| confused | 困惑 | Puzzled, perplexed, needs clarification |

---

## 6. Knowledge Entry Fields (Cerebellum Knowledge Base)

| English | 中文 | Description |
| :--- | :--- | :--- |
| id | 标识 | Unique identifier of the knowledge entry |
| subject | 主体 | Main entity described by the knowledge |
| attribute | 属性 | Name of the knowledge attribute |
| value | 值 | Specific value of the attribute |
| description | 描述 | Complete natural language expression of the knowledge |
| tags | 标签 | Array of categorical tags for quick retrieval |

---

## 7. Scheduling and Fusion (Prefrontal Decision Table)

| English | 中文 | Description |
| :--- | :--- | :--- |
| decisions | 决策表 | Array of scheduling rules for Prefrontal |
| condition | 条件 | Condition object for rule matching |
| schedule | 调度 | Module invocation strategy |
| call_cerebellum | 调用小脑 | Whether to invoke Cerebellum for knowledge retrieval |
| call_amygdala | 调用杏仁核 | Whether to invoke Amygdala for style evaluation |
| fusion | 融合 | Strategy for merging fact and style |
| fact_source | 事实来源 | Source of fact data (cerebellum / none) |
| style_source | 风格来源 | Source of style data (amygdala) |
| fallback | 事实缺失处理 | Fallback action identifier when fact is null |

---

## 8. Broca Template Related

| English | 中文 | Description |
| :--- | :--- | :--- |
| templates | 模板 | Array of sentence pattern templates for language generation |
| prefixes | 语气前缀 | Array of optional prefix interjections |
| suffixes | 语气后缀 | Array of optional suffix interjections |

---

## 9. Amygdala Rules Related

| English | 中文 | Description |
| :--- | :--- | :--- |
| rules | 规则 | Array of emotion-to-style mapping rules for Amygdala |
| condition | 条件 | Trigger condition of the rule |
| output | 输出 | Output style when rule is matched |
| default | 默认 | Default output when no rule is matched |

---

*This glossary is maintained in sync with the Light-Brain Scheme version updates.*