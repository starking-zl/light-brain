# Light-Brain Scheme Seed Knowledge Base

The seed knowledge base is the abstract meta-knowledge injected into Cerebellum during cold start, defining the system's most fundamental ontology, temporal view, and logical rules. All entries use language-neutral identifiers. This document explains their meaning in English.

## Seed Knowledge Entries

| ID | Subject | Attribute | Value | Meaning |
| :--- | :--- | :--- | :--- | :--- |
| seed_001 | entity | exists | true | Entity existence: Any referable object is considered an entity and exists by default. |
| seed_002 | entity | has_property | property | Entity has property: An entity may have one or more properties. |
| seed_003 | relation | connects | entities | Relation connects entities: A relation connects two or more entities. |
| seed_004 | time | is_unidirectional | true | Time is unidirectional: Time flows from past to future and is irreversible. |
| seed_005 | causality | principle | cause_precedes_effect | Causality principle: A cause must precede its effect in time. |

## Design Intent

This meta-knowledge avoids any specific domain, providing only the foundational cognitive framework:
- **Ontology** (seed_001~003): Defines the three basic categories—entity, property, relation—as structural templates for future knowledge growth.
- **Temporal view** (seed_004): Establishes the directionality of time, supporting Hippocampus temporal reasoning.
- **Logical rule** (seed_005): Provides the most basic constraint for causal inference.

## Limitations of the Seed Base

This seed base contains only five fundamental abstract meta-knowledge entries. It does not include any domain-specific common sense, mathematical axioms, physical laws, or social norms. This is an intentional design choice to demonstrate that:

- The system can start from a minimal cognitive skeleton and autonomously expand knowledge through growth mechanisms during environmental interaction.
- The core architecture does not depend on large-scale handcrafted knowledge bases and is theoretically extensible.

If rapid answering capability in specific domains is desired, contributors may write additional initialization scripts to import domain knowledge graphs into Cerebellum. The seed base is merely the starting point for growth, not the endpoint of capability.

## Usage

The seed base data file is located at `data/knowledge/seed.json`. Run the following script to import it into Cerebellum:

```bash
cd scripts
python init_knowledge.py
```

After import, Cerebellum will contain the above five meta-knowledge entries, allowing the system to gradually expand knowledge through growth mechanisms.
