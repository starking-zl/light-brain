# Light-Brain Scheme Public Knowledge Base Integration Guide

The public knowledge base integration is an optional extension for the Light-Brain Scheme. It allows the system to acquire common sense knowledge from pre-filtered public knowledge bases during cold start, shortening the "childhood phase" from abstract meta-knowledge to usable common sense. This extension is designed with zero intrusion: when disabled, it has no impact on core system behavior.

## I. Design Goals

| Goal | Description |
| :--- | :--- |
| **Zero Intrusion** | No modifications to core modules; enabled dynamically via reserved interfaces. |
| **Optional Enablement** | Controlled by a configuration switch; system runs exactly as original when unconfigured. |
| **Growth Knowledge Priority** | Public knowledge only supplements when Cerebellum returns no results. Once written back to Cerebellum, it becomes growth knowledge and naturally gains subsequent priority. |
| **Extensible Data Sources** | Supports multiple data source types (offline import, MCP dynamic query, etc.) via a unified interface. |

## II. How It Works

1. The main entry script `scripts/run.py` attempts to load the public KG facade during initialization. If the configuration file is missing or `enabled = false`, the facade instance remains `None` and all related logic is skipped.
2. When processing user input, if Cerebellum retrieval yields no result and the facade is available, the public KG is queried as a supplement.
3. Any knowledge entry returned from the public KG is immediately written back to Cerebellum, becoming part of growth knowledge. Subsequent identical queries will be served directly from Cerebellum without further public KG calls.
4. Multiple data sources are queried in the order specified in the configuration. The first source to return a valid result wins.

## III. Directory Structure

```

extensions/public_kg/
├── init.py              # Exports facade class and interfaces
├── facade.py                # Facade class (coordinates sources, handles prioritization)
├── traits.py                # Abstract data source interface definitions
├── config.py                # Configuration loading logic
├── priority.py              # Growth-first filtering logic
├── config.toml.example      # Configuration file template
└── sources/
├── init.py          # Data source submodule entry
├── offline.py           # Offline data source skeleton (to be implemented)
└── mcp.py               # MCP data source skeleton (to be implemented)

```

## IV. Data Source Interface Specification

All public KG data sources must implement the `PublicKnowledgeSource` abstract base class:

```python
from abc import ABC, abstractmethod
from typing import List
from dataclasses import dataclass

@dataclass
class PublicKnowledgeEntry:
    id: str              # Unique identifier
    subject: str         # Subject
    attribute: str       # Attribute
    value: str           # Value
    description: str     # Natural language description
    tags: List[str]      # Tags
    certainty: float     # Internal confidence (0.0~1.0)
    source: str          # Source name
    source_trust: float  # Source trustworthiness (0.0~1.0)


class PublicKnowledgeSource(ABC):
    @abstractmethod
    def name(self) -> str:
        """Return the data source name"""
        pass

    @abstractmethod
    def default_trust(self) -> float:
        """Return the default trustworthiness score"""
        pass

    @abstractmethod
    def query(self, keywords: List[str], limit: int) -> List[PublicKnowledgeEntry]:
        """Retrieve knowledge entries by keywords"""
        pass

    @abstractmethod
    def is_available(self) -> bool:
        """Check if the data source is currently available"""
        pass
```

V. Configuration File

Copy config.toml.example to config.toml and modify as needed.

```toml
# Public KG extension configuration
enabled = false  # Set to true to enable

# Offline import data source configuration
[offline]
enabled = false
data_path = "extensions/public_kg/data/offline_kg.json"
source_name = "CN-DBpedia"
default_trust = 0.85

# MCP data source configuration (optional)
[mcp]
enabled = false
server_url = "http://localhost:8080/mcp"
timeout_seconds = 5

# Retrieval behavior
[retrieval]
fallback_only = true            # Only trigger when Cerebellum returns no results
max_supplement_count = 3        # Maximum number of entries to supplement
write_back_to_cerebellum = true # Whether to write public knowledge back to Cerebellum
```

VI. How to Enable the Public KG Extension

1. Navigate to the extensions/public_kg/ directory.
2. Copy config.toml.example to config.toml.
3. Set enabled = true.
4. Implement at least one data source (subclass PublicKnowledgeSource) and register it in the _load_sources method of facade.py.
5. Start the Light-Brain Scheme. Public KG supplemental retrieval will automatically take effect.

VII. Integration Point with Main Entry

The main entry script scripts/run.py has the following reserved interfaces:

```python
# During initialization
self.public_kg_facade = self._init_public_kg_facade()  # Returns None by default

# After Cerebellum retrieval
if fact is None and self.public_kg_facade is not None:
    pub_fact = self.public_kg_facade.query_one(keywords)
    if pub_fact:
        fact = pub_fact
        self.graph_store.upsert(json.dumps(fact))
```

Contributors only need to modify the _init_public_kg_facade method to return a valid PublicKnowledgeFacade instance.

VIII. FAQ

Q: Will public knowledge override growth knowledge?
A: No. Public knowledge only supplements when Cerebellum returns no results. Once written back to Cerebellum, it becomes growth knowledge and naturally gains subsequent priority.

Q: How to update imported public knowledge?
A: Offline imported public knowledge is a static snapshot. Updates require re-running the import script or designing an incremental sync mechanism. This is left for contributors to design based on deployment scenarios.

Q: Can multiple public KG data sources be used simultaneously?
A: Yes. The facade class supports loading multiple data sources, queried in the order specified in the configuration. The first source to return a valid result wins.

Q: How much does the public KG extension increase startup time?
A: Zero when disabled. When enabled, initialization overhead depends on the data source implementation (e.g., loading time of offline data), but it does not block the main process.