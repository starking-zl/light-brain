use pyo3::prelude::*;
use pyo3::types::PyDict;
use std::sync::Arc;
use parking_lot::RwLock;

// 引入光脑核心库
use light_brain_core::cerebellum::{GraphStore, KnowledgeEntry, MemoryTier, QueryOptions, DecayConfig};
use light_brain_core::amygdala::{Amygdala, Rule, StyleOutput};
use light_brain_core::prefrontal::{DecisionTable, CreativeController, CreativeMode, WorkingMemory, FusionEngine};
use light_brain_core::hippocampus::{EventStore, EpisodicEvent, RetrievalEngine, ConsolidationEngine};
use light_brain_core::growth::{KnowledgeExtractor, GrowthScheduler, ConflictDetector};
use light_brain_core::memory::{TierManager, GarbageCollector};
use light_brain_core::thalamus::{PrototypeStore, grounding_layer};

// ---------- 小脑模块绑定 ----------
#[pyclass]
struct PyGraphStore {
    inner: Arc<GraphStore>,
}

#[pymethods]
impl PyGraphStore {
    #[new]
    fn new() -> Self {
        PyGraphStore { inner: Arc::new(GraphStore::new()) }
    }

    fn upsert(&self, entry_json: &str) -> PyResult<()> {
        let entry: KnowledgeEntry = serde_json::from_str(entry_json).map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        self.inner.upsert(entry).map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e))?;
        Ok(())
    }

    fn query(&self, options_json: &str) -> PyResult<String> {
        let options: QueryOptions = serde_json::from_str(options_json).map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        let results = self.inner.query(&options);
        serde_json::to_string(&results).map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))
    }

    fn get_by_id(&self, id: &str) -> PyResult<Option<String>> {
        if let Some(entry) = self.inner.get_by_id(id) {
            Ok(Some(serde_json::to_string(&entry).unwrap()))
        } else {
            Ok(None)
        }
    }

    fn delete(&self, id: &str) -> bool {
        self.inner.delete(id)
    }

    fn apply_decay(&self, config_json: &str) -> PyResult<()> {
        let config: DecayConfig = serde_json::from_str(config_json).map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        self.inner.apply_decay_and_flow(&config);
        Ok(())
    }

    fn count(&self) -> usize {
        self.inner.count()
    }
}

// ---------- 杏仁核模块绑定 ----------
#[pyclass]
struct PyAmygdala {
    inner: Amygdala,
}

#[pymethods]
impl PyAmygdala {
    #[staticmethod]
    fn from_file(path: &str) -> PyResult<Self> {
        let inner = Amygdala::from_file(path).map_err(|e| PyErr::new::<pyo3::exceptions::PyIOError, _>(e.to_string()))?;
        Ok(PyAmygdala { inner })
    }

    fn infer(&self, intent: &str, polarity: &str) -> PyResult<String> {
        // 字符串转枚举（简化处理）
        let style = self.inner.infer(
            match intent {
                "AskFact" => light_brain_core::amygdala::Intent::AskFact,
                "ExpressOpinion" => light_brain_core::amygdala::Intent::ExpressOpinion,
                "Chat" => light_brain_core::amygdala::Intent::Chat,
                "TestBoundary" => light_brain_core::amygdala::Intent::TestBoundary,
                _ => light_brain_core::amygdala::Intent::Unknown,
            },
            match polarity {
                "Positive" => light_brain_core::amygdala::Polarity::Positive,
                "Neutral" => light_brain_core::amygdala::Polarity::Neutral,
                "Negative" => light_brain_core::amygdala::Polarity::Negative,
                "Playful" => light_brain_core::amygdala::Polarity::Playful,
                "Aggressive" => light_brain_core::amygdala::Polarity::Aggressive,
                _ => light_brain_core::amygdala::Polarity::Any,
            }
        );
        Ok(format!("{:?}", style))
    }
}

// ---------- 前额叶模块绑定 ----------
#[pyclass]
struct PyDecisionTable {
    inner: DecisionTable,
}

#[pymethods]
impl PyDecisionTable {
    #[staticmethod]
    fn from_file(path: &str) -> PyResult<Self> {
        let inner = DecisionTable::from_file(path).map_err(|e| PyErr::new::<pyo3::exceptions::PyIOError, _>(e.to_string()))?;
        Ok(PyDecisionTable { inner })
    }

    fn match_decision(&self, intent: &str, domain: &str) -> PyResult<String> {
        // 简化：返回 (schedule, fusion) 的 JSON
        let (schedule, fusion) = self.inner.match_decision(
            match intent {
                "AskFact" => light_brain_core::prefrontal::Intent::AskFact,
                "ExpressOpinion" => light_brain_core::prefrontal::Intent::ExpressOpinion,
                "Chat" => light_brain_core::prefrontal::Intent::Chat,
                "TestBoundary" => light_brain_core::prefrontal::Intent::TestBoundary,
                _ => light_brain_core::prefrontal::Intent::Unknown,
            },
            match domain {
                "InDomain" => light_brain_core::prefrontal::Domain::InDomain,
                "OutDomain" => light_brain_core::prefrontal::Domain::OutDomain,
                "Meta" => light_brain_core::prefrontal::Domain::Meta,
                "Daily" => light_brain_core::prefrontal::Domain::Daily,
                _ => light_brain_core::prefrontal::Domain::Any,
            }
        );
        serde_json::to_string(&(schedule, fusion)).map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))
    }
}

// ---------- 模块注册 ----------
#[pymodule]
fn light_brain_binding(_py: Python, m: &PyModule) -> PyResult<()> {
    m.add_class::<PyGraphStore>()?;
    m.add_class::<PyAmygdala>()?;
    m.add_class::<PyDecisionTable>()?;
    // 后续可继续添加海马体、生长、记忆等模块的绑定
    Ok(())
}