# -*- coding: utf-8 -*-
"""
布罗卡区模块：模板填充语言生成
"""

import random

class Broca:
    def __init__(self, templates_data):
        self.templates = templates_data
    
    def _fill_template(self, template, fact):
        """将事实填充到模板占位符"""
        if fact is None:
            return template
        return template.format(
            主体=fact.get("主体", ""),
            属性=fact.get("属性", ""),
            值=fact.get("值", ""),
            描述=fact.get("描述", "")
        )
    
    def _select_template_group(self, intent, style, missing_action):
        """选择合适的模板组"""
        # 优先根据缺失处理选择特定模板组
        if missing_action == "使用困惑模板":
            key = f"{intent}_困惑"
            if key in self.templates:
                return self.templates[key]
            return self.templates.get("未知_困惑", {"模板": ["我不明白。"], "语气前缀": [""], "语气后缀": [""]})
        
        if missing_action == "使用防御模板":
            key = f"{intent}_防御"
            if key in self.templates:
                return self.templates[key]
            return self.templates.get("试探边界_防御", {"模板": ["恕难从命。"], "语气前缀": [""], "语气后缀": [""]})
        
        if missing_action == "使用闲聊模板":
            key = f"闲聊_{style}"
            if key in self.templates:
                return self.templates[key]
            key = "闲聊_正常"
            if key in self.templates:
                return self.templates[key]
        
        if missing_action == "使用兜底模板" or missing_action == "仅以风格生成观点":
            # 无事实时，使用兜底模板
            return self.templates.get("无事实_兜底", {"模板": ["我不清楚。"], "语气前缀": [""], "语气后缀": [""]})
        
        # 正常情况：按意图_风格查找
        key = f"{intent}_{style}"
        if key in self.templates:
            return self.templates[key]
        
        # 降级：意图_正常
        key = f"{intent}_正常"
        if key in self.templates:
            return self.templates[key]
        
        # 最终兜底
        return self.templates.get("无事实_兜底", {"模板": ["我不清楚。"], "语气前缀": [""], "语气后缀": [""]})
    
    def generate(self, decision_package):
        """
        根据决策包生成自然语言回复
        """
        intent = decision_package["意图"]
        style = decision_package["风格"]
        fact = decision_package.get("事实")
        missing_action = decision_package.get("事实缺失处理")
        
        # 选择模板组
        template_group = self._select_template_group(intent, style, missing_action)
        
        # 随机选择模板、前缀、后缀
        templates = template_group.get("模板", [""])
        prefixes = template_group.get("语气前缀", [""])
        suffixes = template_group.get("语气后缀", [""])
        
        template = random.choice(templates)
        prefix = random.choice(prefixes)
        suffix = random.choice(suffixes)
        
        # 填充模板
        filled = self._fill_template(template, fact)
        
        # 拼接
        response = f"{prefix}{filled}{suffix}".strip()
        return response if response else "……"