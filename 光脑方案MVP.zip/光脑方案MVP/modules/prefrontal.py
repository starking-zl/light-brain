# -*- coding: utf-8 -*-
"""
前额叶模块：调度与融合
"""

class Prefrontal:
    def __init__(self, decisions_data, amygdala, cerebellum):
        self.decisions = decisions_data.get("决策表", [])
        self.default = decisions_data.get("默认决策", {})
        self.amygdala = amygdala
        self.cerebellum = cerebellum
    
    def _match_decision(self, intent, domain):
        """匹配决策表条目"""
        for dec in self.decisions:
            cond = dec["条件"]
            if cond["意图"] == intent:
                if cond["领域"] == domain or cond["领域"] == "任意":
                    return dec
        return self.default
    
    def process(self, input_label):
        """
        处理输入标签，返回决策包
        """
        intent = input_label["意图"]
        polarity = input_label["情感"]
        domain = input_label["领域"]
        keywords = input_label.get("关键词", [])
        
        # 匹配决策
        decision = self._match_decision(intent, domain)
        schedule = decision["调度"]
        fusion = decision["融合"]
        
        # 调用杏仁核获取风格
        style_output = self.amygdala.infer(intent, polarity)
        style = style_output["风格"]
        
        # 调用小脑获取事实
        fact = None
        if schedule["调用小脑"]:
            fact = self.cerebellum.query(keywords)
        
        # 处理事实缺失标记
        if fact is None:
            missing_action = fusion["事实缺失处理"]
            # 在决策包中附加缺失处理标记，供布罗卡区使用
        else:
            missing_action = None
        
        # 构建决策包
        decision_package = {
            "意图": intent,
            "事实": fact,
            "风格": style,
            "事实缺失处理": missing_action
        }
        
        return decision_package