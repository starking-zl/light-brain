# -*- coding: utf-8 -*-
"""
杏仁核模块：基于规则的情感风格输出
"""

class Amygdala:
    def __init__(self, rules_data):
        self.rules = rules_data.get("规则", [])
        self.default = rules_data.get("默认", {"风格": "正常"})
    
    def infer(self, intent, polarity):
        """
        根据意图和情感返回风格
        """
        for rule in self.rules:
            cond = rule["条件"]
            if cond["意图"] == intent:
                if cond["情感"] == polarity or cond["情感"] == "任意":
                    return rule["输出"]
        return self.default