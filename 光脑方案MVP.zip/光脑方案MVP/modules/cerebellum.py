# -*- coding: utf-8 -*-
"""
小脑模块：结构化知识检索
"""

class Cerebellum:
    def __init__(self, knowledge_data):
        """
        knowledge_data: dict，包含 "知识条目" 列表
        """
        self.entries = knowledge_data.get("知识条目", [])
    
    def query(self, keywords):
        """
        根据关键词检索知识，返回匹配的第一条
        """
        if not keywords:
            return None
        
        # 1. 精确匹配：主体或属性与任一关键词完全一致
        for kw in keywords:
            for entry in self.entries:
                if entry["主体"] == kw or entry["属性"] == kw:
                    return entry
        
        # 2. 标签匹配
        for kw in keywords:
            for entry in self.entries:
                if kw in entry.get("标签", []):
                    return entry
        
        # 3. 描述部分匹配
        for kw in keywords:
            for entry in self.entries:
                if kw in entry["描述"]:
                    return entry
        
        return None