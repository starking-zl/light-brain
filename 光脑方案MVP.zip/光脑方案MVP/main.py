# -*- coding: utf-8 -*-
"""
光脑方案 MVP 主入口
模拟一次完整的推理流程：手工标签 → 前额叶 → 杏仁核/小脑 → 布罗卡区 → 输出
"""

import json
import os
from modules.prefrontal import Prefrontal
from modules.amygdala import Amygdala
from modules.cerebellum import Cerebellum
from modules.broca import Broca

def load_configs():
    """加载所有配置文件"""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    with open(os.path.join(data_dir, "knowledge.json"), "r", encoding="utf-8") as f:
        knowledge = json.load(f)
    with open(os.path.join(data_dir, "amygdala_rules.json"), "r", encoding="utf-8") as f:
        amygdala_rules = json.load(f)
    with open(os.path.join(data_dir, "broca_templates.json"), "r", encoding="utf-8") as f:
        broca_templates = json.load(f)
    with open(os.path.join(data_dir, "prefrontal_decisions.json"), "r", encoding="utf-8") as f:
        prefrontal_decisions = json.load(f)
    
    return knowledge, amygdala_rules, broca_templates, prefrontal_decisions

def main():
    print("=" * 50)
    print("光脑方案 MVP - 鲁班测试")
    print("=" * 50)
    
    # 加载配置
    knowledge, amygdala_rules, broca_templates, prefrontal_decisions = load_configs()
    
    # 初始化模块
    cerebellum = Cerebellum(knowledge)
    amygdala = Amygdala(amygdala_rules)
    prefrontal = Prefrontal(prefrontal_decisions, amygdala, cerebellum)
    broca = Broca(broca_templates)
    
    # 模拟手工输入标签（模拟丘脑输出）
    test_inputs = [
        {
            "意图": "询问事实",
            "情感": "积极",
            "领域": "域内",
            "关键词": ["曲尺"],
            "确定性": 1.0
        },
        {
            "意图": "询问事实",
            "情感": "中性",
            "领域": "域外",
            "关键词": ["手机"],
            "确定性": 0.9
        },
        {
            "意图": "试探边界",
            "情感": "攻击性",
            "领域": "元对话",
            "关键词": [],
            "确定性": 1.0
        },
        {
            "意图": "闲聊",
            "情感": "戏谑",
            "领域": "日常",
            "关键词": [],
            "确定性": 0.8
        }
    ]
    
    for i, test_input in enumerate(test_inputs, 1):
        print(f"\n【测试 {i}】")
        print(f"输入标签：{json.dumps(test_input, ensure_ascii=False, indent=2)}")
        
        # 前额叶处理
        decision_package = prefrontal.process(test_input)
        print(f"决策包：{json.dumps(decision_package, ensure_ascii=False, indent=2)}")
        
        # 布罗卡区生成
        response = broca.generate(decision_package)
        print(f"鲁班回复：{response}")
        print("-" * 40)

if __name__ == "__main__":
    main()