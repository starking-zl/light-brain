# Light-Brain Scheme Implementation Roadmap

This document defines the phased iteration plan from MVP to the full version of the Light-Brain Scheme. Each phase includes goals, new content, involved files, and acceptance criteria.

---

## Phase 2: Integrate Real Thalamus

### Goal
Replace manually constructed input labels with a real lightweight intent classification model, enabling the system to directly perceive intent, polarity, and domain from raw text.

### New Content
1. Thalamus Module
   - File: modules/thalamus.py (new)
   - Function: Load a lightweight NLP model to perform intent classification, sentiment analysis, and domain recognition on user input.
   - Output: Standardized label (intent, polarity, domain, keywords, certainty).

2. Model Selection Recommendations
   - Option A: DistilBERT (66M parameters), fine-tuned for intent and sentiment.
   - Option B: ESFT-gate-intent-lite, optimized for mobile intent recognition.
   - Option C: Hybrid architecture with rule fallback and lightweight model.

3. Keyword Extraction
   - Initially: Use jieba tokenization + TF-IDF (for Chinese) or spaCy (for English).
   - Later: Upgrade to KeyBERT or similar models.

4. Interface Adjustment
   - Modify main.py to accept raw text input, call Thalamus to obtain labels, then pass to Prefrontal.

### Involved Files
- modules/thalamus.py (new)
- main.py (modified)
- requirements.txt (add dependencies: transformers, torch, jieba or spacy)

### Acceptance Criteria
- Given Chinese or English text input, outputs correct intent, polarity, and domain labels.
- Accuracy on standard intent classification test set is no less than 85%.
- End-to-end flow runs successfully: raw text -> Thalamus -> Prefrontal -> Cerebellum/Amygdala -> Broca -> reply.

## Phase 3: Upgrade Broca to Small Language Model (SLM)

### Goal
Replace template filling with a small language model (SLM) to improve fluency and richness of language generation, while maintaining logical fidelity through a constraint guiding layer.

### New Content
1. Broca Module Refactoring
   - File: modules/broca.py (rewrite)
   - Add three sub-layers:
     a. Semantic Planning Layer: Converts Prefrontal symbolic decision package into an abstract semantic skeleton.
     b. Neural Generation Layer: Loads a small language model and generates candidate text based on the skeleton.
     c. Constraint Guiding Layer: Uses Logit Bias or Ctrl-G framework to ensure generated content stays faithful to facts and style.

2. Model Selection Recommendations
   - Option A: SmolLM-135M, lightweight and balanced performance.
   - Option B: TinyLlama-1.1B, higher fluency, requires more resources.
   - Option C: Qwen2.5-0.5B (for Chinese) or GPT-2 Small (for English).

3. Constraint Mechanisms
   - Logit Bias: Force increased probability for key entities returned by Cerebellum; suppress out-of-domain vocabulary.
   - Hard Guardrails: Maintain a list of absolute forbidden words (e.g., modern terms the character cannot know), setting their probability to negative infinity.

4. Template Fallback
   - If SLM generation fails or certainty is too low, fall back to the original template filling.

### Involved Files
- modules/broca.py (rewritten)
- data/broca_templates.json (retained for fallback)
- requirements.txt (add dependencies: transformers, torch, accelerate)

### Acceptance Criteria
- Generated language is fluent and natural, with significantly better readability than the template version.
- Factual accuracy is no less than 95%, with no fact distortion or hallucination.
- Style consistency: enthusiastic, defensive, confused, and other styles are recognizable in generated text.

## Phase 4: Implement Hippocampus Episodic Memory

### Goal
Introduce the Hippocampus module to record conversational event history, support cross-turn context retrieval and memory consolidation, enabling multi-turn dialogue capability.

### New Content
1. Hippocampus Module
   - File: modules/hippocampus.py (new)
   - Functions:
     a. Store structured event records for each dialogue turn (input label, decision package, reply, timestamp).
     b. Retrieve relevant historical events based on current input (via keyword or vector similarity).
     c. Trigger memory consolidation periodically: convert high-frequency or important events into Cerebellum knowledge entries.

2. Storage Solution
   - Initially: Use JSON file or SQLite for local persistence.
   - Later: Migrate to vector database (e.g., FAISS or Chroma) for semantic retrieval.

3. Prefrontal Scheduling Extension
   - Add "call_hippocampus" option to the decision table.
   - When topic requires historical context, Prefrontal retrieves relevant events from Hippocampus and injects them into working memory.

4. Memory Consolidation Mechanism
   - Background scheduled task: count event access frequency; knowledge points exceeding threshold are submitted to Cerebellum knowledge base.
   - Consolidated events are marked as "consolidated" and retained in Hippocampus for episodic indexing.

### Involved Files
- modules/hippocampus.py (new)
- modules/prefrontal.py (modified, adding Hippocampus call logic)
- data/conversation_history.db or history.json (new)
- requirements.txt (if vector retrieval needed, add faiss-cpu or chromadb)

### Acceptance Criteria
- Correctly records and retrieves multi-turn conversation history.
- Responds appropriately to questions like "What did we talk about earlier?"
- Character persona and facts remain consistent across consecutive dialogues.
- Memory consolidation process executes correctly without data corruption.

## Phase 5: Introduce Growth Mechanisms

### Goal
Enable dynamic growth of the Cerebellum knowledge base: automatically extract new knowledge from dialogues, add as structured entries after review, allowing the system's knowledge capacity to expand continuously through interaction.

### New Content
1. Knowledge Extractor
   - File: modules/growth/extractor.py (new)
   - Function: Identify new entities, attributes, and relationships from dialogue text; generate candidate knowledge entries.
   - Implementation approaches:
     a. Rule-based pattern matching (e.g., "X is Y", "X's Z is W").
     b. Or call a lightweight information extraction model (e.g., UIE or DeepKE).

2. Knowledge Review and Growth Scheduler
   - File: modules/growth/scheduler.py (new)
   - Functions:
     a. Receive candidate knowledge and evaluate conflict level with existing knowledge.
     b. Automatically admit knowledge with high certainty and no conflict.
     c. Submit conflicting or low-certainty knowledge to manual review queue (precursor to garbage library mechanism).

3. Cerebellum Knowledge Base Upgrade
   - File: modules/cerebellum.py (modified)
   - New methods: add_entry(entry), update_entry(id, new_data), mark_dormant(id).
   - Storage migration: from static JSON to SQLite or lightweight database supporting CRUD operations.

4. Dormant Library and Garbage Library (Foundation of Three-Tier Memory)
   - Implement "active / dormant / garbage" status flags for knowledge entries within Cerebellum.
   - Growth scheduler manages state transitions: long-unaccessed entries marked dormant; when exceeding limit, moved to garbage library.

### Involved Files
- modules/growth/extractor.py (new)
- modules/growth/scheduler.py (new)
- modules/cerebellum.py (modified)
- data/knowledge.db (replaces knowledge.json)
- requirements.txt (add dependencies for information extraction models if used)

### Acceptance Criteria
- System can extract simple knowledge triples (subject, attribute, value) from single-turn dialogues.
- New knowledge successfully added to knowledge base and retrievable in subsequent conversations.
- Conflict detection works: new knowledge conflicting with existing entries is intercepted or flagged.
- Knowledge base persists correctly; data not lost after restart.

## Phase 6: Integrate Three-Knob Creative Control Loop

### Goal
Implement the coordinated mechanism of three creative control knobs—temperature, gate, and evaluation—enabling the system to smoothly adjust between rigorous reasoning and free creativity.

### New Content
1. Creative Controller
   - File: modules/prefrontal/creative_controller.py (new)
   - Functions:
     a. Receive mode set by metacognition (rigorous, daily, creative, counterfactual).
     b. Output baseline values for three knobs: temperature τ, gate γ, evaluation weight ε.
     c. Dynamically fine-tune knob values based on real-time feedback during generation.

2. Temperature Modulation
   - Acts on the Softmax temperature coefficient in Broca's neural generation layer.
   - Higher temperature yields more random sampling; lower temperature yields more deterministic output.

3. Gate Modulation
   - Acts on Cerebellum retrieval and Amygdala inhibition strength.
   - Lower gate allows dormant library knowledge to be retrieved and conflicting concepts to be simultaneously activated.

4. Evaluation Modulation
   - Acts on scoring weights for candidate outputs.
   - In high-creativity mode, increase novelty weight and decrease plausibility weight.

5. Metacognition Mode Selection
   - Initially: Manually set mode in main.py for testing.
   - Later: Train a lightweight classifier to automatically select mode based on dialogue context (one of the extension points).

### Involved Files
- modules/prefrontal/creative_controller.py (new)
- modules/prefrontal.py (modified, integrating controller)
- modules/broca.py (modified, accepting temperature parameter)
- modules/amygdala.py (modified, accepting gate parameter)
- data/creative_profiles.json (new, storing default knob configurations for each mode)

### Acceptance Criteria
- Replies generated under different modes show significant differences in diversity and rigor.
- High-temperature creative mode produces cross-domain analogies or associations.
- Low-temperature rigorous mode prioritizes factual accuracy and logical consistency.
- Knob linkage follows design formulas (temperature and gate positively correlated; evaluation and gate inversely correlated).

---

## Future Extension Points

After completing Phase 6, the Light-Brain Scheme will possess a complete core intelligence architecture. The following extension points may be selectively implemented as needed:

1. Automatic Metacognition Mode Switching: Train a lightweight classifier to automatically select creative mode based on task context.
2. Creative Fatigue Mechanism: Actively lower temperature and raise gate after prolonged high-creativity mode, simulating cognitive fatigue.
3. Sudden Inspiration Simulation: Randomly trigger brief high-temperature pulses during rigorous mode to produce insight-like associations.
4. Multimodal Expansion: Extend Thalamus to support image and audio input; extend Cerebellum to store multimodal knowledge.
5. Social Interaction: Enable multiple Light-Brain instances to exchange knowledge, debate, and collaborate.

---

*Light-Brain Scheme Implementation Roadmap Version: v0.1.0*
*Last Updated: April 2026*
