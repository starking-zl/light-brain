# -*- coding: utf-8 -*-
"""
Light-Brain Scheme MVP - English Version
Simulates a complete inference flow: manual label -> Prefrontal -> Amygdala/Cerebellum -> Broca -> output
"""

import json
import os
from modules.prefrontal import Prefrontal
from modules.amygdala import Amygdala
from modules.cerebellum import Cerebellum
from modules.broca import Broca

def load_configs():
    """Load all configuration files"""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    with open(os.path.join(data_dir, "knowledge.json"), "r", encoding="utf-8") as f:
        knowledge = json.load(f)
    with open(os.path.join(data_dir, "amygdala_rules.json"), "r", encoding="utf-8") as f:
        amygdala_rules = json.load(f)
    with open(os.path.join(data_dir, "broca_templates.json"), "r", encoding="utf-8") as f:
        broca_templates = json.load(f)
    with open(os.path.join(data_dir, "prefrontal_decisions.json"), "r", encoding="utf-8") as f:
        prefrontal_decisions = json.load(f)
    
    return knowledge, amygdala_rules, broca_templates, prefrontal_decisions

def main():
    print("=" * 50)
    print("Light-Brain Scheme MVP - Lu Ban Test")
    print("=" * 50)
    
    knowledge, amygdala_rules, broca_templates, prefrontal_decisions = load_configs()
    
    cerebellum = Cerebellum(knowledge)
    amygdala = Amygdala(amygdala_rules)
    prefrontal = Prefrontal(prefrontal_decisions, amygdala, cerebellum)
    broca = Broca(broca_templates)
    
    test_inputs = [
        {
            "intent": "ask_fact",
            "polarity": "positive",
            "domain": "in_domain",
            "keywords": ["carpenter's square"],
            "certainty": 1.0
        },
        {
            "intent": "ask_fact",
            "polarity": "neutral",
            "domain": "out_domain",
            "keywords": ["smartphone"],
            "certainty": 0.9
        },
        {
            "intent": "test_boundary",
            "polarity": "aggressive",
            "domain": "meta",
            "keywords": [],
            "certainty": 1.0
        },
        {
            "intent": "chat",
            "polarity": "playful",
            "domain": "daily",
            "keywords": [],
            "certainty": 0.8
        }
    ]
    
    for i, test_input in enumerate(test_inputs, 1):
        print(f"\n[Test {i}]")
        print(f"Input label: {json.dumps(test_input, ensure_ascii=False, indent=2)}")
        
        decision_package = prefrontal.process(test_input)
        print(f"Decision package: {json.dumps(decision_package, ensure_ascii=False, indent=2)}")
        
        response = broca.generate(decision_package)
        print(f"Lu Ban's reply: {response}")
        print("-" * 40)

if __name__ == "__main__":
    main()