# -*- coding: utf-8 -*-
"""
Prefrontal module: scheduling and fusion
"""

class Prefrontal:
    def __init__(self, decisions_data, amygdala, cerebellum):
        self.decisions = decisions_data.get("decisions", [])
        self.default = decisions_data.get("default", {})
        self.amygdala = amygdala
        self.cerebellum = cerebellum
    
    def _match_decision(self, intent, domain):
        for dec in self.decisions:
            cond = dec["condition"]
            if cond["intent"] == intent:
                if cond["domain"] == domain or cond["domain"] == "any":
                    return dec
        return self.default
    
    def process(self, input_label):
        intent = input_label["intent"]
        polarity = input_label["polarity"]
        domain = input_label["domain"]
        keywords = input_label.get("keywords", [])
        
        decision = self._match_decision(intent, domain)
        schedule = decision["schedule"]
        fusion = decision["fusion"]
        
        style_output = self.amygdala.infer(intent, polarity)
        style = style_output["style"]
        
        fact = None
        if schedule["call_cerebellum"]:
            fact = self.cerebellum.query(keywords)
        
        fallback_action = None
        if fact is None:
            fallback_action = fusion["fallback"]
        
        decision_package = {
            "intent": intent,
            "fact": fact,
            "style": style,
            "fallback_action": fallback_action
        }
        
        return decision_package