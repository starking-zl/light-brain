# -*- coding: utf-8 -*-
"""
Amygdala module: rule-based emotional style output
"""

class Amygdala:
    def __init__(self, rules_data):
        self.rules = rules_data.get("rules", [])
        self.default = rules_data.get("default", {"style": "normal"})
    
    def infer(self, intent, polarity):
        for rule in self.rules:
            cond = rule["condition"]
            if cond["intent"] == intent:
                if cond["polarity"] == polarity or cond["polarity"] == "any":
                    return rule["output"]
        return self.default