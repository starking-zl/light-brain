# -*- coding: utf-8 -*-
from .cerebellum import Cerebellum
from .amygdala import Amygdala
from .prefrontal import Prefrontal
from .broca import Broca