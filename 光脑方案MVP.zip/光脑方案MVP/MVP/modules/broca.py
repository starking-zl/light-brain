# -*- coding: utf-8 -*-
"""
Broca module: template-based language generation
"""

import random

class Broca:
    def __init__(self, templates_data):
        self.templates = templates_data
    
    def _fill_template(self, template, fact):
        if fact is None:
            return template
        return template.format(
            subject=fact.get("subject", ""),
            attribute=fact.get("attribute", ""),
            value=fact.get("value", ""),
            description=fact.get("description", "")
        )
    
    def _select_template_group(self, intent, style, fallback_action):
        if fallback_action == "use_confused":
            key = f"{intent}_confused"
            if key in self.templates:
                return self.templates[key]
            return self.templates.get("unknown_confused", {"templates": ["I don't understand."], "prefixes": [""], "suffixes": [""]})
        
        if fallback_action == "use_defensive":
            key = f"{intent}_defensive"
            if key in self.templates:
                return self.templates[key]
            return self.templates.get("test_boundary_defensive", {"templates": ["I cannot comply."], "prefixes": [""], "suffixes": [""]})
        
        if fallback_action == "use_chat":
            key = f"chat_{style}"
            if key in self.templates:
                return self.templates[key]
            key = "chat_normal"
            if key in self.templates:
                return self.templates[key]
        
        if fallback_action in ("use_fallback", "opinion_only"):
            return self.templates.get("fallback_no_fact", {"templates": ["I don't know."], "prefixes": [""], "suffixes": [""]})
        
        key = f"{intent}_{style}"
        if key in self.templates:
            return self.templates[key]
        
        key = f"{intent}_normal"
        if key in self.templates:
            return self.templates[key]
        
        return self.templates.get("fallback_no_fact", {"templates": ["I don't know."], "prefixes": [""], "suffixes": [""]})
    
    def generate(self, decision_package):
        intent = decision_package["intent"]
        style = decision_package["style"]
        fact = decision_package.get("fact")
        fallback_action = decision_package.get("fallback_action")
        
        template_group = self._select_template_group(intent, style, fallback_action)
        
        templates = template_group.get("templates", [""])
        prefixes = template_group.get("prefixes", [""])
        suffixes = template_group.get("suffixes", [""])
        
        template = random.choice(templates)
        prefix = random.choice(prefixes)
        suffix = random.choice(suffixes)
        
        filled = self._fill_template(template, fact)
        
        response = f"{prefix}{filled}{suffix}".strip()
        return response if response else "……"