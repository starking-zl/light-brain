# -*- coding: utf-8 -*-
"""
Cerebellum module: structured knowledge retrieval
"""

class Cerebellum:
    def __init__(self, knowledge_data):
        self.entries = knowledge_data.get("entries", [])
    
    def query(self, keywords):
        if not keywords:
            return None
        
        for kw in keywords:
            for entry in self.entries:
                if entry["subject"] == kw or entry["attribute"] == kw:
                    return entry
        
        for kw in keywords:
            for entry in self.entries:
                if kw in entry.get("tags", []):
                    return entry
        
        for kw in keywords:
            for entry in self.entries:
                if kw in entry["description"]:
                    return entry
        
        return None