# Light-Brain Scheme Complete Architecture Documentation

This document provides a detailed description of the Light-Brain Scheme's module responsibilities, data flow, core mechanisms, and design principles. It is intended for contributors who wish to deeply understand the system or participate in development.

---

## I. Architecture Overview

The Light-Brain Scheme consists of six core modules, one memory management subsystem, and one global growth scheduler.

### Module List
| Module | Brain Region Analogy | Core Responsibility |
| :--- | :--- | :--- |
| Thalamus | Thalamus | Perception: convert raw text into structured symbolic labels. |
| Prefrontal | Prefrontal Cortex | Central executive: schedule modules, fuse outputs, creative control, global growth coordination. |
| Amygdala | Amygdala | Emotional evaluation: output style modifier based on intent and polarity. |
| Cerebellum | Cerebellum/Cortex | Structured semantic memory: store and retrieve knowledge entries. |
| Hippocampus | Hippocampus | Episodic memory: record conversational events, support memory retrieval and consolidation. |
| Broca | Broca's Area | Language generation: convert symbolic decisions into natural language. |
| Memory Management Subsystem | (Cross-cutting) | Manage three-tier memory flow (active -> dormant -> garbage). |
| Global Growth Scheduler | (Prefrontal subcomponent) | Coordinate growth requests across modules, allocate resources, maintain growth logs. |

### Data Flow Overview
Raw input -> Thalamus (perception labels) -> Prefrontal (scheduling) -> Amygdala (style) / Cerebellum (fact) / Hippocampus (episodic) -> Prefrontal (fusion) -> Broca (language generation) -> final reply.

---

## II. Module Details

### 1. Thalamus — Perception and Symbol Grounding

**Responsibility**
Convert raw user input (text) into standardized symbolic labels for Prefrontal scheduling.

**Input**
- Raw user input: string (Chinese or English).

**Output**
{
  intent: ask_fact | express_opinion | chat | test_boundary | unknown,
  polarity: positive | neutral | negative | playful | aggressive,
  domain: in_domain | out_domain | meta | daily,
  keywords: [array of strings],
  certainty: 0.0 ~ 1.0
}

**Core Mechanisms**
- Neural Encoder: A lightweight Transformer model (e.g., DistilBERT) encodes text into continuous vectors.
- Symbol Grounding Layer: Maps continuous vectors to discrete symbolic labels via learnable prototype vectors.
- Low-Certainty Handling: When maximum probability falls below threshold, intent is marked as unknown and passed to Prefrontal for conservative handling.

**Growth Capabilities**
- Supports adding new intent categories, polarity types, and domain labels. Prototype vectors expand dynamically with labeled data.

---

### 2. Prefrontal — Central Execution and Scheduling

**Responsibility**
Receive Thalamus labels, schedule Amygdala, Cerebellum, and Hippocampus based on decision table, fuse module outputs, and generate a symbolic decision package.

**Input**
- Standardized label from Thalamus.

**Output (Symbolic Decision Package)**
{
  intent: string,
  fact: { id, subject, attribute, value, description } or null,
  style: normal | enthusiastic | cautious | playful | defensive | confused,
  fallback_action: use_fallback | use_confused | use_defensive | ...
}

**Core Mechanisms**
- Decision Table Matching: Match preset scheduling rules based on intent and domain.
- Module Scheduling: Decide whether to call Cerebellum for knowledge retrieval, Amygdala for style evaluation, and Hippocampus for episodic context.
- Fusion Strategy: Combine fact content with style modifier; handle missing facts with fallback actions.
- Working Memory: Temporarily store intermediate reasoning states.

**Subcomponents**
- Metacognition Controller: Set task mode (rigorous/daily/creative) and output baseline values for three knobs.
- Three-Knob Creative Loop: Control the linkage of temperature τ, gate γ, and evaluation weight ε.
- Global Growth Scheduler (GGS): Centrally manage growth requests from all modules.

---

### 3. Amygdala — Emotion and Style Evaluation

**Responsibility**
Output a language style modifier for the character's reply based on intent and polarity.

**Input**
{
  intent: ask_fact | express_opinion | chat | test_boundary | unknown,
  polarity: positive | neutral | negative | playful | aggressive
}

**Output**
{
  style: normal | enthusiastic | cautious | playful | defensive | confused
}

**Core Mechanisms**
- Rule Engine: Match style based on a preset intent-by-polarity mapping table.
- Special Handling: Playful polarity automatically converts to normal style for solemn characters like Lu Ban; test_boundary always outputs defensive style.
- Default Fallback: Output normal style when no rule matches.

**Configurability**
- Rule file (amygdala_rules.json) can be edited independently and swapped when changing characters.

---

### 4. Cerebellum — Structured Semantic Memory

**Responsibility**
Store and retrieve the character's immutable common sense (worldview, facts, rules), providing a high-certainty knowledge query interface.

**Input**
{
  keywords: [array of strings]
}

**Output (when match found)**
{
  id: unique identifier,
  subject: main entity described,
  attribute: attribute name,
  value: attribute value,
  description: complete natural language expression,
  tags: [array of categorical tags]
}
Returns null when no match is found.

**Core Mechanisms**
- Layered Storage: Fact layer (key-value), relation layer (triples), rule layer (production rules).
- Retrieval Priority: Exact match (subject/attribute) > tag match > partial match in description.
- Dormant and Garbage Libraries: Long-unaccessed knowledge automatically becomes dormant; when exceeding limit, moved to garbage library awaiting user cleanup.

**Growth Capabilities**
- Supports automatic addition of new knowledge entries via Knowledge Extractor from dialogues.
- Supports dynamic expansion of knowledge graph and relational reasoning.

---

### 5. Hippocampus — Episodic Memory and Consolidation

**Responsibility**
Record event sequences for each dialogue turn, support historical retrieval based on keywords or semantics, and consolidate high-frequency or important events into Cerebellum.

**Input (when storing)**
{
  turn_id: unique ID,
  timestamp: ISO 8601 format,
  user_input: raw text,
  thalamus_label: { ... },
  decision_package: { ... },
  final_reply: string
}

**Input (when retrieving)**
{
  query_keywords: [array of strings],
  max_results: 5
}

**Output (when retrieving)**
{
  relevant_events: [
    {
      turn_id: ...,
      timestamp: ...,
      user_input: ...,
      final_reply: ...
    }
  ]
}

**Core Mechanisms**
- Event Storage: Persist key information of each dialogue turn to local database (SQLite / JSON).
- Retrieval Interface: Return most relevant historical events based on keyword or vector similarity.
- Memory Consolidation: Background scheduled task counts event access frequency; knowledge points exceeding threshold are automatically submitted to Cerebellum knowledge base.

---

### 6. Broca — Language Generation

**Responsibility**
Receive the symbolic decision package from Prefrontal and generate a natural language reply consistent with intent, fact, and style.

**Input**
{
  intent: ask_fact | express_opinion | chat | test_boundary | unknown,
  fact: { ... } or null,
  style: normal | enthusiastic | cautious | playful | defensive | confused,
  fallback_action: use_fallback | use_confused | ...
}

**Output**
- Natural language string.

**Core Mechanisms**
- Template Mode (MVP): Select a preset template based on intent_style and fill placeholders with fact content.
- SLM Mode (Phase 3+): Semantic Planning Layer builds abstract skeleton -> Neural Generation Layer (small language model) generates candidate text -> Constraint Guiding Layer (Logit Bias) ensures factual accuracy and style consistency.
- Fallback Strategy: When fact is missing or generation fails, use corresponding fallback templates (confused, defensive, chat, etc.).

**Configurability**
- Template library (broca_templates.json) can be edited independently and supports multiple languages and characters.

---

## III. Memory Management Subsystem

The memory management subsystem spans Cerebellum and Hippocampus, responsible for knowledge entry lifecycle management and three-tier memory flow.

### Three-Tier Memory Structure
| Tier | Name | Function | Access Condition |
| :--- | :--- | :--- | :--- |
| L1 | Active Library | Current high-frequency, high-certainty knowledge; prioritized for retrieval. | Always accessible. |
| L2 | Dormant Library | Overwritten old knowledge, long-term low-frequency knowledge. | Not retrieved in normal mode; retrievable in high-temperature creative mode. |
| L3 | Garbage Library | Knowledge eliminated from Dormant Library, marked as discardable by system. | Not automatically accessible by system; user may view and decide deletion. |

### Knowledge Flow Rules
1. New knowledge enters Active Library after review.
2. Knowledge in Active Library that remains unaccessed for long periods or is overwritten decays and moves to Dormant Library.
3. When Dormant Library exceeds capacity limit, entries are sorted by residual_weight * time_decay_factor; lowest scoring entries move to Garbage Library.
4. Knowledge in Garbage Library is never automatically deleted; manual user confirmation is required for physical removal.

### Decay Formula
new_weight = original_weight * exp( -λ * Δt / (access_frequency + ε) ) * certainty_factor

Where:
- λ is global decay coefficient (recommended 0.01).
- Δt is days since last access.
- access_frequency is average daily accesses over the last 30 days.
- certainty_factor is the knowledge entry's own certainty value.

### Creative Recall Mechanism
When system is in high creative mode (temperature τ > 1.2, gate γ < 0.3):
- Knowledge weights in Dormant Library are temporarily amplified with gain factor G(τ) = exp(τ - 1).
- Dormant knowledge may be retrieved and injected into current reasoning, producing distant associations or inspiration.

---

## IV. Global Growth Scheduler

The Global Growth Scheduler (GGS) is a Prefrontal subcomponent that centrally coordinates growth requests from all modules.

### Responsibilities
- Receive growth requests from modules (new perception labels for Thalamus, new knowledge nodes for Cerebellum, capacity expansion for Hippocampus, etc.).
- Evaluate growth request priority and resource cost.
- Allocate growth quotas (parameter increments, storage space).
- Maintain growth logs and support selective rollback.

### Growth Request Priority Formula
priority = accumulated_prediction_error * task_importance_weight / estimated_resource_cost

- accumulated_prediction_error: Integral of module's recent prediction error.
- task_importance_weight: Set by Metacognition based on current task type (core tasks have higher weight).
- estimated_resource_cost: Number of new parameters or storage bytes required for growth.

### Growth Strategies
| Growth Type | Trigger Condition | Action |
| :--- | :--- | :--- |
| Thalamus Prototype Addition | Unknown intent appears in multiple consecutive turns and is confirmed by manual labeling. | Add new prototype vector in Symbol Grounding Layer. |
| Cerebellum Knowledge Addition | Knowledge Extractor produces candidate entry and passes conflict detection. | Insert new knowledge into Active Library. |
| Hippocampus Capacity Expansion | Historical event storage exceeds 80% of current capacity. | Allocate additional storage space and migrate old data. |
| Broca Vocabulary Expansion | Uncovered vocabulary repeatedly appears in style contexts. | Add new words to corresponding style's vocabulary cluster. |

### Rollback Mechanism
- Growth logs record detailed information of each growth operation (time, module, increment content, trigger reason).
- If system performance degrades significantly after growth (e.g., inference accuracy drops below threshold), an administrator may trigger rollback to restore the pre-growth checkpoint.

---

## V. Core Mechanism Principles

### 1. Growth-Based Neural Network
Knowledge growth in Light-Brain Scheme manifests as physical structural growth rather than parameter adjustment of fixed weights.
- Hebbian Synaptogenesis: New connections form between frequently co-activated neurons; connection weight is proportional to activation consistency.
- Neurogenesis: When a region experiences sustained high prediction error, new neurons are inserted into that layer with initial weights interpolated from neighboring neurons.
- Elastic Weight Consolidation: Important connection weights are marked as consolidated and their learning rate is reduced during growth to prevent catastrophic forgetting.

### 2. Neuro-Symbolic Fusion
The symbolic layer (Cerebellum knowledge graph, Amygdala rules) ensures logical rigor and knowledge precision, while the neural layer (Thalamus encoder, Broca SLM) handles fuzzy perception and fluent generation. Both collaborate through standardized symbolic interfaces (JSON labels) without mutual intrusion.

### 3. Three-Knob Creative Control Loop
| Knob | Controlled Variable | Effect |
| :--- | :--- | :--- |
| Temperature τ | Softmax temperature coefficient | Regulates output randomness. Higher τ increases diversity; lower τ increases determinism. |
| Gate γ | Inhibition mask strength | Regulates knowledge retrieval scope. Lower γ allows Dormant Library and conflicting concepts to activate. |
| Evaluation ε | Novelty vs. plausibility weight | Regulates candidate output screening tendency. High-creativity mode increases novelty weight. |

Linkage Formulas:
γ = max(γ_min, γ₀ - α * (τ - τ₀))
ε_novelty_weight = ε_novelty₀ + β * (γ₀ - γ)

### 4. Symbol Grounding
Core algorithm for Thalamus to map continuous neural representations to discrete symbolic labels:
- Maintain learnable prototype vectors for each symbolic label.
- Compute cosine similarity between input vector and all prototype vectors; obtain label probability distribution via Softmax.
- During training, jointly optimize encoder and prototype vectors using cross-entropy loss.

### 5. Memory Decay and Consolidation
- Decay: Knowledge weight decays exponentially over time; higher access frequency slows decay.
- Consolidation: Hippocampus periodically replays high-frequency events, extracting knowledge points and consolidating them into Cerebellum Active Library.
- Forgetting: Knowledge that decays to extremely low weight enters Dormant Library; when exceeding limit, moves to Garbage Library awaiting user cleanup.

---

## VI. Interface Specification Index

For complete JSON Schema definitions of each module's inputs and outputs, refer to the following documents:

| Document | Content |
| :--- | :--- |
| MODULE_INTERFACES.md | Precise schemas for Thalamus, Prefrontal, Amygdala, Cerebellum, Hippocampus, and Broca. |
| GLOSSARY_EN_ZH.md | English-Chinese translations and descriptions of all fields and enumeration values. |

MVP phase core configuration files (under data/ directory) follow the above schemas and may be used directly as implementation references.

---

## VII. Architecture Diagram

User Input
│
▼
┌─────────────────────────────────────────────────────────┐
│                    Thalamus (Perception)                 │
│   Transformer Encoder -> Prototype Mapping -> Symbolic   │
└─────────────────────────────────────────────────────────┘
│
▼
┌─────────────────────────────────────────────────────────┐
│                Prefrontal (Central Executive)            │
│  ┌─────────────────────────────────────────────────┐    │
│  │ Metacognition -> Three-Knob Loop -> GGS -> WM    │    │
│  └─────────────────────────────────────────────────┘    │
│  Scheduling: match decision table, call submodules       │
└─────────────────────────────────────────────────────────┘
│         │         │
▼         ▼         ▼
┌────────┐ ┌────────┐ ┌────────────┐
│Amygdala│ │Cerebel-│ │Hippocampus │
│ Style  │ │  lum   │ │ Episodic   │
└────────┘ └────────┘ └────────────┘
│         │         │
└─────────┼─────────┘
▼
┌─────────────────────────────────────────────────────────┐
│                  Broca (Language Generation)             │
│   Semantic Planning -> Neural Gen -> Constraints -> NL   │
└─────────────────────────────────────────────────────────┘
│
▼
Final Reply


---

*Light-Brain Scheme Architecture Documentation Version: v0.1.0*
*Last Updated: April 2026*