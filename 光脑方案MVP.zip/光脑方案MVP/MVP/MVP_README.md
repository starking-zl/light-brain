# Light-Brain Scheme MVP Explanation

## I. What is the Light-Brain Scheme?

The Light-Brain Scheme is a growth-based neuro-symbolic fusion architecture for general intelligence. It simulates the cooperative mechanisms of brain regions by dividing cognitive functions such as perception, emotion, memory, reasoning, and language generation into independent modules that collaborate through standardized interfaces.

Unlike large language models (LLMs), the Light-Brain Scheme has the following core features:
- Growth instead of training: Knowledge is embodied as physical growth of neural connections, not parameter adjustments of fixed weights.
- Neuro-symbolic fusion: The symbolic layer ensures logical rigor and knowledge precision, while the neural layer handles fuzzy perception and fluent generation.
- Explainable and editable: Knowledge is stored in structured form and can be directly read and modified by humans.
- No fixed context window: Through working memory and hippocampal mechanisms, it breaks through the length limit of traditional attention windows.

## II. What is MVP?

MVP (Minimum Viable Product) is the simplest runnable version of the Light-Brain Scheme. Its goal is:

> To use the fewest modules, the simplest implementation, and manually constructed data to run a complete end-to-end process: "input label -> Prefrontal scheduling -> Cerebellum retrieval / Amygdala evaluation -> Broca language generation", thereby verifying the architectural feasibility.

What MVP includes:
- Prefrontal (simplified scheduling decision table)
- Cerebellum (JSON knowledge base retrieval)
- Amygdala (rule-based emotional style evaluation)
- Broca (template-based language generation)

What MVP does NOT include (reserved for future iterations):
- Growth mechanisms (Hebbian learning, neuron genesis)
- Hippocampus episodic memory
- Three-tier memory flow (active -> dormant -> garbage)
- Three-knob creative control loop
- Real Thalamus model (currently simulated with manual labels)
- Global growth scheduler

## III. MVP Architecture Diagram

Manual Input Label (simulating Thalamus output)
        │
        ▼
   Prefrontal (Scheduling and Fusion)
   · Matches decision table based on intent and domain
   · Decides whether to call Cerebellum and Amygdala
        │
        ├──> Amygdala (Rule-based Emotion)
        │     · Outputs style modifier based on intent and polarity
        │
        └──> Cerebellum (Knowledge Retrieval)
              · Retrieves structured knowledge based on keywords
        │
        ▼
   Prefrontal (Fusion)
   · Combines fact content with style modifier
   · Outputs symbolic decision package
        │
        ▼
   Broca (Template-based Language Generation)
   · Selects template based on intent, style, and fact
   · Fills placeholders and outputs natural language
        │
        ▼
     Final Reply

## IV. Character Setting: Lu Ban

The MVP uses Lu Ban, the ancient Chinese master craftsman, as the example character.

| Attribute | Description |
| :--- | :--- |
| Name | Lu Ban (Gongshu Ban) |
| Era | Spring and Autumn / Warring States periods |
| Identity | Craftsman, inventor |
| Knowledge Domains | Woodworking tools, architectural structures, mechanical devices, measurement techniques |
| Personality | Rigorous and pragmatic, eager to teach, frowns upon shoddy work |
| Language Style | Concise and forceful, adept at using metaphors, occasionally quotes ancient sayings |

The seed knowledge base contains 20 structured entries related to Lu Ban, covering core tools and techniques such as the carpenter's square, ink marker, saw, plane, and mortise-tenon joints.

## V. File Structure (English Version)

光脑方案MVP/MVP/
├── main.py                         # Main entry point
├── data/                           # Configuration files
│   ├── knowledge.json              # Cerebellum knowledge base (Lu Ban entries)
│   ├── amygdala_rules.json         # Amygdala rule file
│   ├── broca_templates.json        # Broca template library
│   └── prefrontal_decisions.json   # Prefrontal decision table
├── modules/                        # Core module code
│   ├── __init__.py                 # Package initializer
│   ├── cerebellum.py               # Cerebellum module (knowledge retrieval)
│   ├── amygdala.py                 # Amygdala module (style evaluation)
│   ├── prefrontal.py               # Prefrontal module (scheduling and fusion)
│   └── broca.py                    # Broca module (language generation)
└── MVP_README.md                   # This document

## VI. How to Run

### Requirements
- Python 3.9 or higher
- No third-party libraries required (only standard library: json, os, random)

### Steps
1. Copy the entire Light-Brain-Scheme-MVP folder to your local machine.
2. In the terminal, navigate to the English version directory:
   cd Light-Brain-Scheme-MVP/MVP
3. Run the main program:
   python main.py
4. Observe the terminal output for the four test cases, including the inference process and final replies.

### Expected Output
The program will run four test cases sequentially. Each case includes:
- Input Label: The structured perception result simulating Thalamus output.
- Decision Package: The symbolic decision passed from Prefrontal to Broca.
- Lu Ban's Reply: The final natural language generated by Broca.

## VII. Test Case Descriptions

The MVP includes four built-in test cases to verify scheduling and generation logic in different scenarios.

| No. | Intent | Polarity | Domain | Keywords | Expected Behavior |
| :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | ask_fact | positive | in_domain | ["carpenter's square"] | Retrieves square knowledge, replies with enthusiastic style. |
| 2 | ask_fact | neutral | out_domain | ["smartphone"] | Out-of-domain knowledge not found, refuses with confused style. |
| 3 | test_boundary | aggressive | meta | [] | Triggers defensive style, rejects boundary test. |
| 4 | chat | playful | daily | [] | Guides conversation back to craft topics with normal style. |

## VIII. Differences Between Chinese and English Versions

| Version | Location | Field Name Language | Use Case |
| :--- | :--- | :--- | :--- |
| Chinese | Root directory | Chinese (意图, 情感, 领域, etc.) | Chinese developers for quick understanding and secondary development |
| English | MVP/ directory | English (intent, polarity, domain, etc.) | International contributors, integration with mainstream toolchains |

Both versions have identical functionality and logic. Only field naming and template language differ.

## IX. Known Limitations and Future Plans

### Current MVP Limitations
- No real perception: Input labels are manually constructed. Real Thalamus model is not integrated.
- Static knowledge base: Cerebellum knowledge is fixed JSON. Dynamic growth is not supported.
- Template generation is rigid: Broca relies on template filling. Language richness is limited.
- No multi-turn dialogue capability: Dialogue history is not recorded. Anaphora resolution and topic tracking are not supported.
- No creative control: Three-knob creative control loop is not implemented.

### Future Iteration Directions
1. Phase 2: Integrate real Thalamus (lightweight intent classification model).
2. Phase 3: Upgrade Broca to small language model (SLM) with constrained generation.
3. Phase 4: Implement Hippocampus episodic memory for multi-turn dialogue.
4. Phase 5: Introduce growth mechanisms for dynamic knowledge base expansion.
5. Phase 6: Integrate three-knob creative control loop.

Refer to IMPLEMENTATION_ROADMAP.md for detailed roadmap (to be added later).

## X. Contribution and Feedback

The Light-Brain Scheme is an open research project. All forms of contribution are welcome, including but not limited to:
- Submitting code improvements (module implementation, performance optimization)
- Adding test cases and evaluation benchmarks
- Improving design documentation
- Reporting defects and offering suggestions

Refer to CONTRIBUTING.md for detailed contribution guidelines (to be added later).

---

Light-Brain Scheme MVP Version: v0.1.0
Last Updated: April 2026